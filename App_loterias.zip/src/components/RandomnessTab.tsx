import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import { ModelResult } from '../utils/models';

interface Props {
  data: any[];
  models: ModelResult[];
  randomnessTest: {
    z: number;
    pValue: number;
    isRandom: boolean;
  };
}

export const RandomnessTab: React.FC<Props> = ({ data, models, randomnessTest }) => {
  if (!data || !models || !randomnessTest) return null;

  const bestModel = models[0];

  const monteCarloData = useMemo(() => {
    // Generate 10000 random samples based on uniform distribution (0-9999)
    // To visualize, we group them into bins of 1000
    const bins = new Array(10).fill(0);
    for (let i = 0; i < 10000; i++) {
      const val = Math.floor(Math.random() * 10000);
      bins[Math.floor(val / 1000)]++;
    }

    // Generate model distribution
    const modelBins = new Array(10).fill(0);
    // Since we only have one actual prediction point, we will visualize the model's test predictions
    const preds = bestModel._testPreds || [];
    preds.forEach(p => {
      const val = Math.max(0, Math.min(9999, Math.round(p)));
      modelBins[Math.floor(val / 1000)]++;
    });
    
    // Normalize to comparable scales
    const scaleFactor = 10000 / (preds.length || 1);

    return bins.map((v, i) => ({
      rango: `${i * 1000}-${(i + 1) * 1000 - 1}`,
      monteCarlo: v,
      modelo: Math.round(modelBins[i] * scaleFactor)
    }));
  }, [bestModel]);

  return (
    <div className="space-y-6">
      <div className="bg-rose-900/30 p-6 rounded-xl border border-rose-800 shadow-lg text-center">
        <h2 className="text-2xl font-bold text-rose-400 mb-2">⚠ Advertencia de Aleatoriedad y Azar</h2>
        <p className="text-gray-300 max-w-3xl mx-auto">
          Esta herramienta es solo para fines académicos y analíticos. Los sistemas de lotería son inherentemente impredecibles y estocásticos. 
          A pesar del uso de redes neuronales (LSTM) y algoritmos avanzados (XGBoost, Random Forest), <strong>ningún modelo puede garantizar ganancias o vencer el azar puro a largo plazo.</strong>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-6 rounded-xl shadow-md border border-gray-700">
          <h3 className="text-xl font-bold mb-4 text-white">Prueba de Aleatoriedad (Runs Test)</h3>
          <p className="text-gray-400 text-sm mb-4">Verificamos si la serie histórica se comporta como ruido blanco aleatorio.</p>
          
          <div className="bg-gray-900 p-4 rounded-lg flex flex-col justify-center items-center">
            <div className="text-center mb-4">
              <span className="text-gray-500 text-xs uppercase tracking-wider block mb-1">Resultado de la Serie</span>
              <span className={`text-3xl font-bold ${randomnessTest.isRandom ? 'text-emerald-400' : 'text-rose-400'}`}>
                {randomnessTest.isRandom ? 'Aleatorio' : 'No Aleatorio'}
              </span>
            </div>
            
            <div className="w-full flex justify-between text-sm px-4">
              <div>
                <span className="text-gray-500 block">Valor Z</span>
                <span className="text-white font-mono">{randomnessTest.z.toFixed(4)}</span>
              </div>
              <div className="text-right">
                <span className="text-gray-500 block">Valor P</span>
                <span className="text-white font-mono">{randomnessTest.pValue.toFixed(4)}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 text-xs text-gray-500 text-justify">
            <p>
              * <strong>Interpretación:</strong> Si el Valor P &gt; 0.05, no hay evidencia suficiente para rechazar la hipótesis nula, concluyendo que la serie es aleatoria. 
              En loterías justas, se espera que la serie sea puramente estocástica.
            </p>
          </div>
        </div>

        <div className="bg-gray-800 p-6 rounded-xl shadow-md border border-gray-700">
          <h3 className="text-xl font-bold mb-4 text-blue-400">¿Se diferencian las predicciones del modelo del azar puro?</h3>
          <p className="text-gray-400 text-sm mb-4">Simulación de Monte Carlo (10,000 iteraciones) vs Distribución del Modelo.</p>
          
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monteCarloData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="rango" stroke="#9ca3af" tick={{ fontSize: 10 }} />
                <RechartsTooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                <Area type="monotone" dataKey="monteCarlo" name="Azar (Monte Carlo)" stroke="#fb7185" fill="#fb7185" fillOpacity={0.2} />
                <Area type="monotone" dataKey="modelo" name="Predicciones Modelo" stroke="#34d399" fill="#34d399" fillOpacity={0.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 text-xs text-gray-400 italic text-center">
            * El modelo tiende a ajustarse a tendencias subyacentes, mientras que Monte Carlo muestra una distribución uniforme. 
            El sesgo estadístico entre ambas revela los patrones "aprendidos" por la IA.
          </div>
        </div>
      </div>
    </div>
  );
};
