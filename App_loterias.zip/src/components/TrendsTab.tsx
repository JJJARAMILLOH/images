import React from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
  ReferenceDot, ReferenceArea
} from 'recharts';
import { ModelResult } from '../utils/models';

interface Props {
  data: any[];
  models: ModelResult[];
}

export const TrendsTab: React.FC<Props> = ({ data, models }) => {
  if (!data || data.length === 0 || !models || models.length === 0) return null;

  const last300 = data.slice(-300);
  const bestModel = models[0];
  const predNum = parseInt(bestModel.prediction, 10);

  // Calculate moving average for trend
  const windowSize = 10;
  const chartData = last300.map((d, i) => {
    let ma = null;
    if (i >= windowSize - 1) {
      const window = last300.slice(i - windowSize + 1, i + 1);
      ma = window.reduce((sum, item) => sum + item.resultNum, 0) / windowSize;
    }
    return {
      index: i,
      date: d.dateStr,
      value: d.resultNum,
      trend: ma
    };
  });

  // Add prediction point
  chartData.push({
    index: chartData.length,
    date: 'Predicción',
    value: null as any,
    trend: predNum
  });

  return (
    <div className="space-y-6">
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-2 text-white flex items-center justify-between">
          <span>Últimos 300 Resultados vs Predicción del Mejor Modelo</span>
          <span className="text-sm font-normal text-emerald-400 border border-emerald-400/30 px-3 py-1 rounded bg-emerald-900/20">
            Próximo Sorteo: {bestModel.prediction}
          </span>
        </h3>
        <p className="text-gray-400 text-sm mb-6">Gráfico temporal con media móvil (ventana de 10 días) y estimación futura.</p>
        
        <div className="h-[500px] w-full bg-gray-900/50 rounded-lg p-4 border border-gray-700/50">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
              <XAxis dataKey="date" stroke="#9ca3af" tick={{ fontSize: 12 }} minTickGap={30} />
              <YAxis stroke="#9ca3af" domain={[0, 9999]} tickFormatter={(val) => String(val).padStart(4, '0')} />
              <RechartsTooltip 
                contentStyle={{ backgroundColor: '#1f2937', borderColor: '#4b5563', borderRadius: '0.5rem', color: '#f3f4f6' }}
                labelStyle={{ color: '#9ca3af', marginBottom: '0.25rem' }}
                itemStyle={{ fontWeight: 'bold' }}
              />
              <Legend verticalAlign="top" height={36} iconType="circle" />
              
              <ReferenceArea x1={chartData.length - 2} x2={chartData.length - 1} fillOpacity={0.1} fill="#3b82f6" />
              
              <Line 
                type="monotone" 
                dataKey="value" 
                name="Resultado Real" 
                stroke="#60a5fa" 
                strokeWidth={1} 
                dot={{ r: 1, fill: '#60a5fa' }} 
                activeDot={{ r: 5, fill: '#3b82f6', stroke: '#fff' }}
              />
              <Line 
                type="monotone" 
                dataKey="trend" 
                name="Tendencia (Media Móvil 10)" 
                stroke="#f59e0b" 
                strokeWidth={2} 
                dot={false}
                activeDot={false}
              />
              
              <ReferenceDot 
                x={chartData.length - 1} 
                y={predNum} 
                r={6} 
                fill="#10b981" 
                stroke="#047857" 
                strokeWidth={2}
                label={{ position: 'top', value: `¡Predicción: ${bestModel.prediction}!`, fill: '#34d399', fontSize: 14, fontWeight: 'bold' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
