import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer
} from 'recharts';

interface Props {
  stats: any;
  data: any[];
}

export const DashboardTab: React.FC<Props> = ({ stats }) => {
  if (!stats) return null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Media" value={stats.mean.toFixed(2)} />
        <StatCard title="Mediana" value={stats.median.toFixed(2)} />
        <StatCard title="Desv. Estándar" value={stats.stdDev.toFixed(2)} />
        <StatCard title="Asimetría" value={stats.skewness.toFixed(3)} />
        <StatCard title="Curtosis" value={stats.kurtosis.toFixed(3)} />
        <StatCard title="Mínimo" value={stats.min.toString().padStart(4, '0')} />
        <StatCard title="Máximo" value={stats.max.toString().padStart(4, '0')} />
        <StatCard title="N Sorteos" value={stats.n} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-700">
          <h3 className="text-xl font-bold mb-4 text-emerald-400">Top 10 Números Frecuentes</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.top10}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="num" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <RechartsTooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                <Bar dataKey="count" fill="#34d399" name="Frecuencia" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-700">
          <h3 className="text-xl font-bold mb-4 text-rose-400">Top 10 Números Infrecuentes</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.bottom10}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="num" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <RechartsTooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} />
                <Bar dataKey="count" fill="#fb7185" name="Frecuencia" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 p-4 rounded-xl shadow-lg border border-gray-700">
        <h3 className="text-xl font-bold mb-4 text-blue-400">Distribución por Posición (0-9)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {[stats.d1Freq, stats.d2Freq, stats.d3Freq, stats.d4Freq].map((freq, idx) => (
            <div key={idx} className="h-48">
              <h4 className="text-center text-sm text-gray-400 mb-2">Dígito {idx + 1}</h4>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={freq.map((v: number, i: number) => ({ digit: i, count: v }))}>
                  <XAxis dataKey="digit" stroke="#9ca3af" tick={{ fontSize: 12 }} />
                  <RechartsTooltip contentStyle={{ backgroundColor: '#1f2937', border: 'none' }} cursor={{fill: '#374151'}} />
                  <Bar dataKey="count" fill="#60a5fa" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value }: { title: string; value: string | number }) => (
  <div className="bg-gray-800 p-4 rounded-xl shadow-md border border-gray-700 flex flex-col justify-center items-center">
    <span className="text-gray-400 text-sm font-medium">{title}</span>
    <span className="text-2xl font-bold text-white mt-1">{value}</span>
  </div>
);
