import React from 'react';
import { ModelResult } from '../utils/models';
import { Trophy, Info, AlertTriangle, Cpu } from 'lucide-react';

interface Props {
  models: ModelResult[];
  loading: boolean;
}

export const ModelsTab: React.FC<Props> = ({ models, loading }) => {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-4">
        <Cpu className="w-12 h-12 text-blue-500 animate-spin" />
        <p className="text-gray-400 font-medium">Entrenando Modelos de Machine Learning...</p>
        <p className="text-sm text-gray-500 max-w-md text-center">Esto puede tomar un momento. LSTM (TensorFlow.js) y las regresiones clásicas están procesando el dataset histórico.</p>
      </div>
    );
  }

  if (models.length === 0) return null;

  const bestModel = models[0];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-900/50 to-indigo-900/50 p-6 rounded-xl border border-blue-800 shadow-xl">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-blue-500 rounded-full bg-opacity-20">
              <Trophy className="w-8 h-8 text-blue-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Mejor Modelo: {bestModel.name}</h2>
              <p className="text-blue-300 flex items-center mt-1">
                <Info className="w-4 h-4 mr-1" />
                RMSE más bajo en testeo: {bestModel.rmse.toFixed(2)}
              </p>
            </div>
          </div>
          <div className="mt-6 md:mt-0 text-center md:text-right">
            <p className="text-sm text-gray-400 mb-1">PREDICCIÓN PRÓXIMO SORTEO</p>
            <div className="text-5xl font-extrabold tracking-widest text-emerald-400 font-mono drop-shadow-[0_0_10px_rgba(52,211,153,0.5)]">
              {bestModel.prediction}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-xl overflow-hidden border border-gray-700 shadow-lg">
        <div className="p-4 bg-gray-900 border-b border-gray-700 flex justify-between items-center">
          <h3 className="text-xl font-bold text-white">Comparativa de Modelos (Validación Cruzada)</h3>
          <span className="text-xs text-gray-400 italic">Ordenado por RMSE</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-800 text-gray-400 uppercase">
              <tr>
                <th className="px-6 py-4">Ranking</th>
                <th className="px-6 py-4">Modelo</th>
                <th className="px-6 py-4">Tipo</th>
                <th className="px-6 py-4">Predicción</th>
                <th className="px-6 py-4">MAE</th>
                <th className="px-6 py-4">RMSE</th>
                <th className="px-6 py-4">Precisión (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {models.map((m, i) => (
                <tr key={m.name} className={`hover:bg-gray-700/50 transition-colors ${i === 0 ? 'bg-blue-900/20' : ''}`}>
                  <td className="px-6 py-4 font-bold">#{i + 1}</td>
                  <td className="px-6 py-4 font-medium text-white flex items-center">
                    {m.name}
                    {!m.realPrediction && (
                      <div className="group relative ml-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500 cursor-help" />
                        <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 hidden group-hover:block w-48 bg-gray-900 text-xs text-gray-300 p-2 rounded shadow-lg border border-gray-700 z-10 text-center">
                          Simulación adaptada para navegador web
                        </div>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${m.type === 'advanced' ? 'bg-purple-900/50 text-purple-300' : 'bg-slate-700 text-slate-300'}`}>
                      {m.type === 'advanced' ? 'Avanzado' : 'Clásico'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-lg font-mono text-emerald-400">{m.prediction}</td>
                  <td className="px-6 py-4 text-gray-300">{m.mae.toFixed(2)}</td>
                  <td className={`px-6 py-4 font-semibold ${i === 0 ? 'text-blue-400' : 'text-gray-300'}`}>{m.rmse.toFixed(2)}</td>
                  <td className="px-6 py-4 text-gray-300">{m.accuracy.toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
