import React, { useState, useEffect } from 'react';
import { fetchAndProcessData, calculateStatistics, runsTest, LotteryRecord } from './utils/dataProcessor';
import { runModels, ModelResult } from './utils/models';
import { DashboardTab } from './components/DashboardTab';
import { ModelsTab } from './components/ModelsTab';
import { TrendsTab } from './components/TrendsTab';
import { RandomnessTab } from './components/RandomnessTab';
import { BarChart3, BrainCircuit, TrendingUp, Dices, RefreshCw } from 'lucide-react';
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Data sources
const SOURCES = [
  { name: 'Astroluna', url: 'https://raw.githubusercontent.com/JJJARAMILLOH/Information/master/astroluna.csv' },
  { name: 'Medellín', url: 'https://raw.githubusercontent.com/JJJARAMILLOH/Information/master/medellin.csv' },
  { name: 'Bogotá', url: 'https://raw.githubusercontent.com/JJJARAMILLOH/Information/master/bogota.csv' }
];

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sourceUrl, setSourceUrl] = useState(SOURCES[0].url);
  const [data, setData] = useState<LotteryRecord[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [randomness, setRandomness] = useState<any>(null);
  const [models, setModels] = useState<ModelResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingModels, setLoadingModels] = useState(false);
  const [error, setError] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      setError('');
      setData([]);
      setStats(null);
      setModels([]);
      
      const parsedData = await fetchAndProcessData(sourceUrl);
      if (parsedData.length === 0) {
        throw new Error('No se encontraron datos válidos');
      }
      
      setData(parsedData);
      
      const calcStats = calculateStatistics(parsedData);
      setStats(calcStats);
      
      const nums = parsedData.map(d => d.resultNum);
      setRandomness(runsTest(nums));
      
      setLoading(false);
      
      // Load models async
      setLoadingModels(true);
      // Give UI time to update before blocking with models
      setTimeout(async () => {
        const results = await runModels(parsedData);
        setModels(results);
        setLoadingModels(false);
      }, 100);

    } catch (err: any) {
      setError(err.message || 'Error al cargar los datos');
      setLoading(false);
      setLoadingModels(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [sourceUrl]);

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans">
      <header className="bg-gray-900 border-b border-gray-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3">
              <Dices className="w-8 h-8 text-emerald-400" />
              <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-500">
                Analizador Profesional Lotería
              </h1>
            </div>
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              <label className="text-sm text-gray-400 font-medium">Dataset:</label>
              <select 
                className="bg-gray-800 border border-gray-700 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                disabled={loading || loadingModels}
              >
                {SOURCES.map(s => (
                  <option key={s.name} value={s.url}>{s.name}</option>
                ))}
              </select>
              <button 
                onClick={loadData}
                disabled={loading || loadingModels}
                className="p-2 bg-gray-800 hover:bg-gray-700 rounded-md border border-gray-700 transition-colors"
                title="Recargar datos"
              >
                <RefreshCw className={cn("w-5 h-5 text-gray-400", (loading || loadingModels) && "animate-spin")} />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="bg-red-900/50 border border-red-500 text-red-200 px-4 py-3 rounded relative mb-6">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}

        {loading ? (
          <div className="flex flex-col justify-center items-center h-64">
            <RefreshCw className="w-12 h-12 text-emerald-500 animate-spin mb-4" />
            <p className="text-xl text-gray-300">Cargando y procesando dataset...</p>
          </div>
        ) : (
          <>
            <div className="flex space-x-1 bg-gray-900 p-1 rounded-xl mb-8 overflow-x-auto">
              <TabButton 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')}
                icon={<BarChart3 className="w-5 h-5 mr-2" />}
                label="Dashboard Global"
              />
              <TabButton 
                active={activeTab === 'models'} 
                onClick={() => setActiveTab('models')}
                icon={<BrainCircuit className="w-5 h-5 mr-2" />}
                label="Modelos Predictivos"
              />
              <TabButton 
                active={activeTab === 'trends'} 
                onClick={() => setActiveTab('trends')}
                icon={<TrendingUp className="w-5 h-5 mr-2" />}
                label="Últimos 300 + Tendencia"
              />
              <TabButton 
                active={activeTab === 'randomness'} 
                onClick={() => setActiveTab('randomness')}
                icon={<Dices className="w-5 h-5 mr-2" />}
                label="Aleatoriedad vs Modelos"
              />
            </div>

            <div className="animate-in fade-in duration-500">
              {activeTab === 'dashboard' && <DashboardTab stats={stats} data={data} />}
              {activeTab === 'models' && <ModelsTab models={models} loading={loadingModels} />}
              {activeTab === 'trends' && <TrendsTab data={data} models={models} />}
              {activeTab === 'randomness' && <RandomnessTab data={data} models={models} randomnessTest={randomness} />}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

const TabButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center px-4 py-3 text-sm font-medium rounded-lg whitespace-nowrap transition-all",
      active 
        ? "bg-gray-800 text-emerald-400 shadow-sm" 
        : "text-gray-400 hover:text-gray-200 hover:bg-gray-800/50"
    )}
  >
    {icon}
    {label}
  </button>
);

export default App;
