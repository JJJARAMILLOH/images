import Papa from 'papaparse';
import * as ss from 'simple-statistics';

export interface LotteryRecord {
  date: Date;
  dateStr: string;
  resultStr: string;
  resultNum: number;
  d1: number;
  d2: number;
  d3: number;
  d4: number;
  dayOfWeek: number;
  month: number;
  year: number;
}

export async function fetchAndProcessData(url: string): Promise<LotteryRecord[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(url, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data: LotteryRecord[] = [];
        for (const row of results.data as any[]) {
          if (!row.Fecha || !row.Resultados) continue;
          
          let resStr = row.Resultados.toString().trim();
          if (resStr === '' || isNaN(Number(resStr))) continue;
          
          // Zero pad to 4 digits
          resStr = resStr.padStart(4, '0');
          if (resStr.length > 4) resStr = resStr.substring(0, 4); // basic sanity
          
          const date = new Date(row.Fecha);
          if (isNaN(date.getTime())) continue;

          data.push({
            date,
            dateStr: row.Fecha,
            resultStr: resStr,
            resultNum: parseInt(resStr, 10),
            d1: parseInt(resStr[0], 10),
            d2: parseInt(resStr[1], 10),
            d3: parseInt(resStr[2], 10),
            d4: parseInt(resStr[3], 10),
            dayOfWeek: date.getDay(),
            month: date.getMonth(),
            year: date.getFullYear()
          });
        }
        
        data.sort((a, b) => a.date.getTime() - b.date.getTime());
        resolve(data);
      },
      error: (error) => {
        reject(error);
      }
    });
  });
}

export function calculateStatistics(data: LotteryRecord[]) {
  const numbers = data.map(d => d.resultNum);
  const n = numbers.length;
  
  if (n === 0) return null;

  const mean = ss.mean(numbers);
  const median = ss.median(numbers);
  const mode = ss.mode(numbers);
  const stdDev = ss.standardDeviation(numbers);
  const min = ss.min(numbers);
  const max = ss.max(numbers);
  
  // Calculate skewness and kurtosis
  let skewness = 0;
  let kurtosis = 0;
  for (let num of numbers) {
    skewness += Math.pow(num - mean, 3);
    kurtosis += Math.pow(num - mean, 4);
  }
  skewness = skewness / (n * Math.pow(stdDev, 3));
  kurtosis = (kurtosis / (n * Math.pow(stdDev, 4))) - 3; // Excess kurtosis

  // Frequencies
  const freqMap = new Map<string, number>();
  data.forEach(d => {
    freqMap.set(d.resultStr, (freqMap.get(d.resultStr) || 0) + 1);
  });
  
  const frequencies = Array.from(freqMap.entries()).map(([num, count]) => ({ num, count }));
  frequencies.sort((a, b) => b.count - a.count);
  
  const top10 = frequencies.slice(0, 10);
  const bottom10 = frequencies.slice(-10).reverse();

  // Digit frequencies
  const d1Freq = new Array(10).fill(0);
  const d2Freq = new Array(10).fill(0);
  const d3Freq = new Array(10).fill(0);
  const d4Freq = new Array(10).fill(0);

  data.forEach(d => {
    d1Freq[d.d1]++;
    d2Freq[d.d2]++;
    d3Freq[d.d3]++;
    d4Freq[d.d4]++;
  });

  return {
    mean, median, mode, stdDev, skewness, kurtosis, min, max, n,
    top10, bottom10,
    d1Freq, d2Freq, d3Freq, d4Freq
  };
}

export function runsTest(data: number[]): { z: number, pValue: number, isRandom: boolean } {
  const median = ss.median(data);
  let runs = 1;
  let n1 = 0;
  let n2 = 0;
  
  // Calculate n1 and n2
  for (let i = 0; i < data.length; i++) {
    if (data[i] >= median) n1++;
    else n2++;
  }

  // Count runs
  let prev = data[0] >= median;
  for (let i = 1; i < data.length; i++) {
    const current = data[i] >= median;
    if (current !== prev) {
      runs++;
      prev = current;
    }
  }

  // Expected runs
  const expectedRuns = ((2 * n1 * n2) / (n1 + n2)) + 1;
  const variance = (2 * n1 * n2 * (2 * n1 * n2 - n1 - n2)) / (Math.pow(n1 + n2, 2) * (n1 + n2 - 1));
  const z = (runs - expectedRuns) / Math.sqrt(variance || 1);
  
  // Basic p-value approximation from z-score
  const pValue = 2 * (1 - normalCDF(Math.abs(z)));
  
  return {
    z,
    pValue,
    isRandom: pValue > 0.05 // Null hypothesis: sequence is random
  };
}

function normalCDF(x: number) {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp(-x * x / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - p : p;
}
