import fs from 'fs';
import https from 'https';
import AdmZip from 'adm-zip';
import path from 'path';

const url = 'https://raw.githubusercontent.com/JJJARAMILLOH/images/main/Loterias_2026_v2.zip';
const zipPath = path.join(process.cwd(), 'Loterias_2026_v2.zip');

https.get(url, (res) => {
  if (res.statusCode !== 200) {
    console.error('Failed to download: ' + res.statusCode);
    process.exit(1);
  }
  const file = fs.createWriteStream(zipPath);
  res.pipe(file);
  file.on('finish', () => {
    file.close();
    console.log('Downloaded zip.');
    try {
      const zip = new AdmZip(zipPath);
      const zipEntries = zip.getEntries();
      console.log('Zip entries:');
      zipEntries.forEach(entry => console.log(entry.entryName));
      // Extract src folder
      zip.extractAllTo(process.cwd(), true);
      console.log('Extracted successfully.');
    } catch (e) {
      console.error('Extraction error:', e);
    }
  });
}).on('error', (err) => {
  console.error('Error:', err);
});
