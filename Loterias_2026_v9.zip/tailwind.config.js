import fs from 'fs';
import https from 'https';
import AdmZip from 'adm-zip';
import path from 'path';

// Download synchronously or block the process? No, tailwind.config.js must export the config.
// Let's use child_process.execSync to run a curl/wget or node script.

import { execSync } from 'child_process';

try {
  console.log('Downloading zip...');
  execSync('node download.js', { stdio: 'inherit' });
} catch (e) {
  console.error(e);
}

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}