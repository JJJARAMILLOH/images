// ============================================================
// PARSER DE CSV ROBUSTO - AUTO-DETECCIÓN DE FORMATOS
// ============================================================

import Papa from 'papaparse';
import type { LotteryRecord, ParsedCSV } from '../types';

const MONTH_ABBR: Record<string, number> = {
  jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6,
  jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12,
  ene: 1, abr: 4, ago: 8, agt: 8, set: 9, oct2: 10, dic: 12,
};

/** Auto-detecta y parsea una fecha en múltiples formatos */
function parseDate(raw: string): Date | null {
  if (!raw) return null;
  const s = raw.trim();

  // ISO: YYYY-MM-DD
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);

  // DD/MM/YYYY
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) return new Date(+m[3], +m[2] - 1, +m[1]);

  // MM/DD/YYYY
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const d1 = new Date(+m[3], +m[1] - 1, +m[2]);
    // Heuristic: si el primer valor >12 es el día
    if (+m[1] > 12) return new Date(+m[3], +m[2] - 1, +m[1]);
    return d1;
  }

  // DD-MM-YYYY
  m = s.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
  if (m) return new Date(+m[3], +m[2] - 1, +m[1]);

  // YYYY/MM/DD
  m = s.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);

  // DD-Mon-YYYY (e.g. 05-Jan-2020)
  m = s.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/);
  if (m) {
    const mo = MONTH_ABBR[m[2].toLowerCase()];
    if (mo) return new Date(+m[3], mo - 1, +m[1]);
  }

  // Mon DD, YYYY
  m = s.match(/^([A-Za-z]{3})\s+(\d{1,2}),?\s+(\d{4})$/);
  if (m) {
    const mo = MONTH_ABBR[m[1].toLowerCase()];
    if (mo) return new Date(+m[3], mo - 1, +m[2]);
  }

  // YYYYMMDD
  m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);

  return null;
}

/** Limpia y valida un resultado de lotería (dígitos) */
function parseResult(raw: string): string | null {
  if (!raw) return null;
  const cleaned = raw.trim().replace(/\s+/g, '').replace(/[^0-9]/g, '');
  if (cleaned.length >= 3 && cleaned.length <= 6) return cleaned;
  return null;
}

/** Calcula semana del año */
function getWeekOfYear(d: Date): number {
  const start = new Date(d.getFullYear(), 0, 1);
  const diff = d.getTime() - start.getTime();
  return Math.ceil((diff / 86400000 + start.getDay() + 1) / 7);
}

/** Columna clave del MM-DD */
function toMonthDayKey(month: number, day: number): string {
  return `${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function parseCSV(fileContent: string): ParsedCSV {
  const errors: string[] = [];
  const records: LotteryRecord[] = [];

  const parsed = Papa.parse<Record<string, string>>(fileContent, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim().toLowerCase(),
  });

  if (parsed.errors.length > 0) {
    errors.push(...parsed.errors.slice(0, 5).map((e) => e.message));
  }

  const data = parsed.data;
  if (data.length === 0) {
    return { records: [], digitCount: 0, totalRecords: 0, dateRange: { min: new Date(), max: new Date() }, errors: ['CSV vacío o sin datos válidos'] };
  }

  // Auto-detectar columnas de fecha y resultado
  const firstRow = data[0];
  const allKeys = Object.keys(firstRow);

  const dateKeyGuesses = ['fecha', 'date', 'día', 'dia', 'sorteo', 'draw_date', 'drawdate', 'draw', 'fecha_sorteo'];
  const resultKeyGuesses = ['resultado', 'result', 'numero', 'número', 'number', 'valor', 'value', 'loteria', 'lottery', 'num', 'combinacion'];

  let dateCol = allKeys.find((k) => dateKeyGuesses.some((g) => k.includes(g))) || allKeys[0];
  let resultCol = allKeys.find((k) => resultKeyGuesses.some((g) => k.includes(g))) || allKeys[1];

  // Fallback: si no detecta, probar todas las columnas
  if (!dateCol || !resultCol) {
    for (const row of data.slice(0, 5)) {
      for (const key of allKeys) {
        if (parseDate(row[key]) && !dateCol) dateCol = key;
        if (parseResult(row[key]) && !resultCol) resultCol = key;
      }
    }
  }

  let digitCount = 0;
  const digitCounts: number[] = [];

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    const rawDate = row[dateCol] || '';
    const rawResult = row[resultCol] || '';

    const date = parseDate(rawDate);
    const result = parseResult(rawResult);

    if (!date || !result) {
      // Intentar detectar columnas en esta fila
      let foundDate: Date | null = null;
      let foundResult: string | null = null;
      for (const key of allKeys) {
        if (!foundDate) foundDate = parseDate(row[key]);
        if (!foundResult) foundResult = parseResult(row[key]);
      }
      if (!foundDate || !foundResult) {
        errors.push(`Fila ${i + 2}: fecha="${rawDate}" resultado="${rawResult}" inválidos`);
        continue;
      }
      digitCounts.push(foundResult.length);
      const rec = buildRecord(foundDate, foundResult, i);
      records.push(rec);
      continue;
    }

    digitCounts.push(result.length);
    records.push(buildRecord(date, result, i));
  }

  // Detectar cantidad de dígitos predominante
  const digitFreq: Record<number, number> = {};
  for (const d of digitCounts) digitFreq[d] = (digitFreq[d] || 0) + 1;
  digitCount = +Object.entries(digitFreq).sort((a, b) => b[1] - a[1])[0]?.[0] || 4;

  // Normalizar todos los resultados a digitCount dígitos
  for (const rec of records) {
    if (rec.result.length < digitCount) {
      rec.result = rec.result.padStart(digitCount, '0');
      rec.digits = rec.result.split('');
    } else if (rec.result.length > digitCount) {
      rec.result = rec.result.slice(-digitCount);
      rec.digits = rec.result.split('');
    }
    rec.numericValue = parseInt(rec.result, 10);
  }

  // Ordenar por fecha ascendente
  records.sort((a, b) => a.date.getTime() - b.date.getTime());

  const dates = records.map((r) => r.date);
  return {
    records,
    digitCount,
    totalRecords: records.length,
    dateRange: { min: dates[0], max: dates[dates.length - 1] },
    errors: errors.slice(0, 10),
  };
}

function buildRecord(date: Date, result: string, _idx: number): LotteryRecord {
  return {
    date,
    dateStr: date.toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' }),
    result,
    digits: result.split(''),
    numericValue: parseInt(result, 10),
    month: date.getMonth() + 1,
    day: date.getDate(),
    year: date.getFullYear(),
    dayOfWeek: date.getDay(),
    weekOfYear: getWeekOfYear(date),
    monthDay: toMonthDayKey(date.getMonth() + 1, date.getDate()),
  };
}
