// ============================================================
// UTILIDADES ESTADÍSTICAS AVANZADAS
// ============================================================

import type { LotteryRecord, PositionFrequencyMap, GlobalStatistics } from '../types';

/** Calcula frecuencia por posición */
export function calcPositionFrequency(records: LotteryRecord[], digitCount: number): PositionFrequencyMap {
  const freq: PositionFrequencyMap = {};
  for (let p = 0; p < digitCount; p++) {
    freq[p] = {};
    for (let d = 0; d <= 9; d++) freq[p][String(d)] = 0;
  }
  for (const rec of records) {
    for (let p = 0; p < digitCount; p++) {
      const digit = rec.digits[p];
      if (digit !== undefined) {
        freq[p][digit] = (freq[p][digit] || 0) + 1;
      }
    }
  }
  return freq;
}

/** Media */
export function mean(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

/** Mediana */
export function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

/** Desviación estándar */
export function stdDev(values: number[]): number {
  if (values.length < 2) return 0;
  const avg = mean(values);
  const sq = values.map((v) => (v - avg) ** 2);
  return Math.sqrt(mean(sq));
}

/** Moda */
export function mode(values: number[]): number {
  const freq: Record<number, number> = {};
  let maxCount = 0;
  let modeVal = values[0] || 0;
  for (const v of values) {
    freq[v] = (freq[v] || 0) + 1;
    if (freq[v] > maxCount) { maxCount = freq[v]; modeVal = v; }
  }
  return modeVal;
}

/** Distancia entre fechas en días */
export function daysBetween(a: Date, b: Date): number {
  return Math.round(Math.abs(b.getTime() - a.getTime()) / 86400000);
}

/** Calcula gaps (días desde la última aparición de cada número) */
export function calcGaps(records: LotteryRecord[]): Record<string, number> {
  const lastSeen: Record<string, Date> = {};
  const gaps: Record<string, number> = {};
  const latest = records[records.length - 1]?.date || new Date();

  for (const rec of records) {
    lastSeen[rec.result] = rec.date;
  }

  for (const [num, date] of Object.entries(lastSeen)) {
    gaps[num] = daysBetween(date, latest);
  }
  return gaps;
}

/** Calcula rachas (consecutivos de un mismo número o dígito) */
export function calcStreaks(records: LotteryRecord[]): Record<string, number> {
  const streaks: Record<string, number> = {};
  let prevResult = '';
  let currentStreak = 0;

  for (const rec of records) {
    if (rec.result === prevResult) {
      currentStreak++;
    } else {
      currentStreak = 1;
      prevResult = rec.result;
    }
    if (currentStreak > (streaks[rec.result] || 0)) {
      streaks[rec.result] = currentStreak;
    }
  }
  return streaks;
}

/** Estadísticas globales completas */
export function buildGlobalStatistics(
  allRecords: LotteryRecord[],
  dateRecords: LotteryRecord[],
  digitCount: number,
): GlobalStatistics {
  const totalDraws = allRecords.length;
  const matchingDateDraws = dateRecords.length;

  const globalFrequency = calcPositionFrequency(allRecords, digitCount);
  const dateFrequency = calcPositionFrequency(dateRecords.length > 0 ? dateRecords : allRecords, digitCount);

  // Hot/Cold numbers globales
  const numFreq: Record<string, number> = {};
  for (const rec of allRecords) {
    numFreq[rec.result] = (numFreq[rec.result] || 0) + 1;
  }
  const sorted = Object.entries(numFreq).sort((a, b) => b[1] - a[1]);
  const hotNumbers = sorted.slice(0, 10).map(([n]) => n);
  const coldNumbers = sorted.slice(-10).map(([n]) => n);

  // Top dígitos globales
  const digitFreqGlobal: Record<string, number> = {};
  for (const rec of allRecords) {
    for (const d of rec.digits) {
      digitFreqGlobal[d] = (digitFreqGlobal[d] || 0) + 1;
    }
  }
  const totalDigits = allRecords.length * digitCount;
  const overallHotDigits = Object.entries(digitFreqGlobal)
    .map(([digit, count]) => ({ digit, count, percentage: (count / totalDigits) * 100 }))
    .sort((a, b) => b.count - a.count);

  // Estadísticas por posición
  const positionStats = Array.from({ length: digitCount }, (_, p) => {
    const posFreq = globalFrequency[p];
    const total = Object.values(posFreq).reduce((a, b) => a + b, 0);
    const topDigits = Object.entries(posFreq)
      .map(([digit, count]) => ({ digit, count, percentage: total > 0 ? (count / total) * 100 : 0 }))
      .sort((a, b) => b.count - a.count);
    return { position: p, topDigits };
  });

  // Balance par/impar
  let even = 0; let odd = 0;
  for (const rec of allRecords) {
    for (const d of rec.digits) {
      if (+d % 2 === 0) even++; else odd++;
    }
  }

  // Estadísticas de suma
  const sums = allRecords.map((r) => r.digits.reduce((a, d) => a + +d, 0));
  const sumStats = {
    mean: mean(sums),
    median: median(sums),
    stdDev: stdDev(sums),
    mode: mode(sums),
  };

  // Ciclos (autocorrelación simple)
  const numValues = allRecords.map((r) => r.numericValue);
  const cycles: number[] = [];
  for (let lag = 1; lag <= Math.min(30, numValues.length / 3); lag++) {
    let corr = 0;
    for (let i = lag; i < numValues.length; i++) {
      if (numValues[i] === numValues[i - lag]) corr++;
    }
    if (corr > 1) cycles.push(lag);
  }

  return {
    totalDraws,
    matchingDateDraws,
    globalFrequency,
    dateFrequency,
    hotNumbers,
    coldNumbers,
    overallHotDigits,
    positionStats,
    gaps: calcGaps(allRecords),
    streaks: calcStreaks(allRecords),
    cycles: cycles.slice(0, 5),
    evenOddBalance: { even, odd },
    sumStats,
  };
}
