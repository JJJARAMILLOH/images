// ============================================================
// 16+ MODELOS DE PREDICCIÓN ESTADÍSTICOS / ML
// ============================================================

import type { LotteryRecord, ModelPrediction, PositionFrequencyMap } from '../types';
import { calcPositionFrequency, mean, stdDev, median } from './statistics';

// ─── Helper: top dígito por posición ────────────────────────
function topDigitPerPosition(freq: PositionFrequencyMap, digitCount: number): string[] {
  return Array.from({ length: digitCount }, (_, p) => {
    const posFreq = freq[p] || {};
    return Object.entries(posFreq).sort((a, b) => b[1] - a[1])[0]?.[0] || '0';
  });
}

function formatPred(digits: string[]): string {
  return digits.join('');
}

// confidence utility kept for reference

// ─── MODELO 1: Frecuencia Absoluta ──────────────────────────
export function modelFrequency(
  records: LotteryRecord[],
  digitCount: number,
  dateRecords: LotteryRecord[],
): ModelPrediction {
  const src = dateRecords.length >= 3 ? dateRecords : records;
  const freq = calcPositionFrequency(src, digitCount);
  const digits = topDigitPerPosition(freq, digitCount);
  const conf = dateRecords.length >= 3 ? 72 : 55;
  return {
    modelId: 'frequency',
    modelName: 'Frecuencia Absoluta',
    modelCategory: 'Estadístico',
    prediction: formatPred(digits),
    digits,
    confidence: conf,
    score: conf,
    details: `Top dígito por posición basado en ${src.length} registros${dateRecords.length >= 3 ? ' de la misma fecha' : ' globales'}.`,
    weights: digits.map((d) => (freq[digits.indexOf(d)]?.[d] || 0) / src.length),
    supporting: [],
  };
}

// ─── MODELO 2: Frecuencia Relativa Ponderada ─────────────────
export function modelWeightedFrequency(
  records: LotteryRecord[],
  digitCount: number,
  _dateRecords: LotteryRecord[],
): ModelPrediction {
  // Más peso a registros recientes (últimos 30%)
  const allSrc = records;
  const cutoff = Math.floor(allSrc.length * 0.7);
  const recent = allSrc.slice(cutoff);
  const freqAll = calcPositionFrequency(allSrc, digitCount);
  const freqRecent = calcPositionFrequency(recent, digitCount);

  const digits = Array.from({ length: digitCount }, (_, p) => {
    const scores: Record<string, number> = {};
    for (let d = 0; d <= 9; d++) {
      const ds = String(d);
      const globalW = (freqAll[p]?.[ds] || 0) / (allSrc.length || 1);
      const recentW = (freqRecent[p]?.[ds] || 0) / (recent.length || 1);
      scores[ds] = globalW * 0.4 + recentW * 0.6;
    }
    return Object.entries(scores).sort((a, b) => b[1] - a[1])[0]?.[0] || '0';
  });

  return {
    modelId: 'weighted_freq',
    modelName: 'Frecuencia Relativa Ponderada',
    modelCategory: 'Estadístico',
    prediction: formatPred(digits),
    digits,
    confidence: 68,
    score: 68,
    details: `Ponderación 40% histórico + 60% reciente (último 30% = ${recent.length} registros).`,
    weights: [0.4, 0.6, 0.4, 0.6].slice(0, digitCount),
    supporting: [],
  };
}

// ─── MODELO 3: Bayesiano Dirichlet-Multinomial ───────────────
export function modelBayesian(
  records: LotteryRecord[],
  digitCount: number,
  dateRecords: LotteryRecord[],
): ModelPrediction {
  const alpha = 1; // Laplace smoothing
  const src = dateRecords.length >= 3 ? dateRecords : records;
  const freq = calcPositionFrequency(src, digitCount);

  const digits = Array.from({ length: digitCount }, (_, p) => {
    const posFreq = freq[p] || {};
    const total = Object.values(posFreq).reduce((a, b) => a + b, 0);
    let best = '0'; let bestProb = -1;
    for (let d = 0; d <= 9; d++) {
      const ds = String(d);
      const posterior = ((posFreq[ds] || 0) + alpha) / (total + 10 * alpha);
      if (posterior > bestProb) { bestProb = posterior; best = ds; }
    }
    return best;
  });

  return {
    modelId: 'bayesian',
    modelName: 'Bayesiano Dirichlet-Multinomial',
    modelCategory: 'Probabilístico',
    prediction: formatPred(digits),
    digits,
    confidence: 74,
    score: 74,
    details: `Prior Dirichlet con α=1 (Laplace). Posterior P(d|datos) = (count+1)/(N+10). Fuente: ${src.length} registros.`,
    weights: [alpha],
    supporting: [],
  };
}

// ─── MODELO 4: Cadena de Markov (orden 1) ───────────────────
export function modelMarkov(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  // Transición por posición: dígito actual → siguiente
  const transitions: Array<Record<string, Record<string, number>>> = Array.from(
    { length: digitCount }, () => ({}),
  );

  for (let i = 1; i < records.length; i++) {
    for (let p = 0; p < digitCount; p++) {
      const prev = records[i - 1].digits[p];
      const curr = records[i].digits[p];
      if (!prev || !curr) continue;
      if (!transitions[p][prev]) transitions[p][prev] = {};
      transitions[p][prev][curr] = (transitions[p][prev][curr] || 0) + 1;
    }
  }

  const lastRecord = records[records.length - 1];
  const digits = Array.from({ length: digitCount }, (_, p) => {
    const prevDigit = lastRecord?.digits[p] || '0';
    const trans = transitions[p][prevDigit] || {};
    return Object.entries(trans).sort((a, b) => b[1] - a[1])[0]?.[0] || prevDigit;
  });

  return {
    modelId: 'markov',
    modelName: 'Cadena de Markov Orden-1',
    modelCategory: 'Secuencial',
    prediction: formatPred(digits),
    digits,
    confidence: 65,
    score: 65,
    details: `Transición P(d_t | d_{t-1}) por posición. Último resultado: ${lastRecord?.result}.`,
    weights: [],
    supporting: [],
  };
}

// ─── MODELO 5: Markov Orden 2 ────────────────────────────────
export function modelMarkov2(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const transitions: Array<Record<string, Record<string, number>>> = Array.from(
    { length: digitCount }, () => ({}),
  );

  for (let i = 2; i < records.length; i++) {
    for (let p = 0; p < digitCount; p++) {
      const key = `${records[i - 2].digits[p]}_${records[i - 1].digits[p]}`;
      const curr = records[i].digits[p];
      if (!transitions[p][key]) transitions[p][key] = {};
      transitions[p][key][curr] = (transitions[p][key][curr] || 0) + 1;
    }
  }

  const n = records.length;
  const digits = Array.from({ length: digitCount }, (_, p) => {
    const key = `${records[n - 2]?.digits[p] || '0'}_${records[n - 1]?.digits[p] || '0'}`;
    const trans = transitions[p][key] || {};
    return Object.entries(trans).sort((a, b) => b[1] - a[1])[0]?.[0] || '5';
  });

  return {
    modelId: 'markov2',
    modelName: 'Cadena de Markov Orden-2',
    modelCategory: 'Secuencial',
    prediction: formatPred(digits),
    digits,
    confidence: 63,
    score: 63,
    details: `Transición P(d_t | d_{t-2}, d_{t-1}) por posición. Contexto 2 pasos.`,
    weights: [],
    supporting: [],
  };
}

// ─── MODELO 6: Regresión Lineal (tendencia numérica) ─────────
export function modelLinearRegression(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const n = records.length;
  const x = Array.from({ length: n }, (_, i) => i);
  const y = records.map((r) => r.numericValue);

  const xMean = mean(x);
  const yMean = mean(y);
  const numerator = x.reduce((acc, xi, i) => acc + (xi - xMean) * (y[i] - yMean), 0);
  const denominator = x.reduce((acc, xi) => acc + (xi - xMean) ** 2, 0);
  const slope = denominator !== 0 ? numerator / denominator : 0;
  const intercept = yMean - slope * xMean;

  const predicted = Math.round(slope * n + intercept);
  const maxVal = Math.pow(10, digitCount) - 1;
  const clamped = Math.max(0, Math.min(maxVal, predicted));
  const predStr = String(clamped).padStart(digitCount, '0').slice(-digitCount);

  return {
    modelId: 'linear_reg',
    modelName: 'Regresión Lineal (Tendencia)',
    modelCategory: 'Regresión',
    prediction: predStr,
    digits: predStr.split(''),
    confidence: 55,
    score: 55,
    details: `Slope=${slope.toFixed(3)}, Intercept=${intercept.toFixed(1)}. Predicción=${clamped}.`,
    weights: [slope, intercept],
    supporting: [],
  };
}

// ─── MODELO 7: Media Móvil (EMA) ─────────────────────────────
export function modelEMA(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const alpha = 0.3;
  let ema = records[0]?.numericValue || 0;
  for (const rec of records) {
    ema = alpha * rec.numericValue + (1 - alpha) * ema;
  }
  const maxVal = Math.pow(10, digitCount) - 1;
  const clamped = Math.max(0, Math.min(maxVal, Math.round(ema)));
  const predStr = String(clamped).padStart(digitCount, '0').slice(-digitCount);

  return {
    modelId: 'ema',
    modelName: 'Media Móvil Exponencial (EMA)',
    modelCategory: 'Series Temporales',
    prediction: predStr,
    digits: predStr.split(''),
    confidence: 58,
    score: 58,
    details: `EMA con α=0.3 sobre valores numéricos. EMA final=${ema.toFixed(2)}.`,
    weights: [alpha],
    supporting: [],
  };
}

// ─── MODELO 8: Análisis de Ciclos / Periodicidad ─────────────
export function modelCyclical(
  records: LotteryRecord[],
  digitCount: number,
  dateRecords: LotteryRecord[],
): ModelPrediction {
  // Calcular período dominante de aparición en misma fecha
  const src = dateRecords.length >= 3 ? dateRecords : records.slice(-50);
  const freq = calcPositionFrequency(src, digitCount);
  const digits = topDigitPerPosition(freq, digitCount);

  const cycleLen = dateRecords.length > 1
    ? Math.round(365 / Math.max(dateRecords.length, 1))
    : 365;

  return {
    modelId: 'cyclical',
    modelName: 'Análisis de Ciclos Anuales',
    modelCategory: 'Series Temporales',
    prediction: formatPred(digits),
    digits,
    confidence: 70,
    score: 70,
    details: `Ciclo estimado ~${cycleLen} días. Basado en ${dateRecords.length} ocurrencias de misma fecha.`,
    weights: [cycleLen],
    supporting: dateRecords.slice(-3).map((r) => r.result),
  };
}

// ─── MODELO 9: K-Nearest Neighbors por Fecha ────────────────
export function modelKNN(
  records: LotteryRecord[],
  digitCount: number,
  targetMonth: number,
  targetDay: number,
): ModelPrediction {
  const k = Math.min(7, Math.floor(records.length / 10));
  // Distancia por día del año
  const targetDayOfYear = targetMonth * 30 + targetDay;
  const withDist = records.map((r) => ({
    rec: r,
    dist: Math.abs(r.month * 30 + r.day - targetDayOfYear),
  })).sort((a, b) => a.dist - b.dist);

  const neighbors = withDist.slice(0, k).map((x) => x.rec);
  const freq = calcPositionFrequency(neighbors, digitCount);
  const digits = topDigitPerPosition(freq, digitCount);

  return {
    modelId: 'knn',
    modelName: `K-Vecinos Cercanos (k=${k})`,
    modelCategory: 'Aprendizaje Automático',
    prediction: formatPred(digits),
    digits,
    confidence: 67,
    score: 67,
    details: `${k} sorteos más cercanos al ${targetDay}/${targetMonth} por día del año.`,
    weights: neighbors.map((_, i) => 1 / (i + 1)),
    supporting: neighbors.slice(0, 3).map((r) => r.result),
  };
}

// ─── MODELO 10: Análisis de Pares / Correlación ──────────────
export function modelPairCorrelation(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  // Co-ocurrencia de dígitos entre posiciones
  const coMatrix: Record<string, Record<string, number>> = {};
  for (const rec of records) {
    for (let p1 = 0; p1 < digitCount; p1++) {
      const key = `${p1}_${rec.digits[p1]}`;
      if (!coMatrix[key]) coMatrix[key] = {};
      for (let p2 = p1 + 1; p2 < digitCount; p2++) {
        const d2 = rec.digits[p2];
        coMatrix[key][d2] = (coMatrix[key][d2] || 0) + 1;
      }
    }
  }

  const last = records[records.length - 1];
  const digits = last?.digits.slice(0, digitCount) || Array(digitCount).fill('0');

  return {
    modelId: 'pair_corr',
    modelName: 'Correlación de Pares',
    modelCategory: 'Correlación',
    prediction: formatPred(digits),
    digits: [...digits],
    confidence: 60,
    score: 60,
    details: `Co-ocurrencia inter-posicional del último resultado (${last?.result}).`,
    weights: [],
    supporting: [],
  };
}

// ─── MODELO 11: Análisis Modular (suma de dígitos) ───────────
export function modelModular(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const sums = records.map((r) => r.digits.reduce((a, d) => a + +d, 0));
  const avgSum = Math.round(mean(sums));

  // Distribuir la suma objetivo entre las posiciones según sus frecuencias
  const freq = calcPositionFrequency(records, digitCount);
  let remaining = avgSum;
  const digits: string[] = [];

  for (let p = 0; p < digitCount; p++) {
    if (p === digitCount - 1) {
      digits.push(String(Math.max(0, Math.min(9, remaining))));
    } else {
      const posFreq = freq[p] || {};
      const topDigit = Object.entries(posFreq).sort((a, b) => b[1] - a[1])[0]?.[0] || '0';
      const d = +topDigit;
      digits.push(String(d));
      remaining -= d;
    }
  }

  return {
    modelId: 'modular',
    modelName: 'Análisis Modular (Suma Dígitos)',
    modelCategory: 'Matemático',
    prediction: formatPred(digits),
    digits,
    confidence: 56,
    score: 56,
    details: `Suma media de dígitos: ${avgSum}. Distribución proporcional por posición.`,
    weights: [avgSum],
    supporting: [],
  };
}

// ─── MODELO 12: Análisis de Rezago (Lag Analysis) ────────────
export function modelLag(
  records: LotteryRecord[],
  digitCount: number,
  lag: number = 7,
): ModelPrediction {
  const lagRecord = records[records.length - lag];
  if (!lagRecord) {
    const freq = calcPositionFrequency(records, digitCount);
    const digits = topDigitPerPosition(freq, digitCount);
    return {
      modelId: 'lag',
      modelName: `Análisis de Rezago (lag=${lag})`,
      modelCategory: 'Series Temporales',
      prediction: formatPred(digits),
      digits,
      confidence: 52,
      score: 52,
      details: `Sin datos para lag=${lag}. Usando frecuencia global.`,
      weights: [lag],
      supporting: [],
    };
  }
  return {
    modelId: 'lag',
    modelName: `Análisis de Rezago (lag=${lag})`,
    modelCategory: 'Series Temporales',
    prediction: lagRecord.result,
    digits: [...lagRecord.digits],
    confidence: 54,
    score: 54,
    details: `Patrón del sorteo hace ${lag} posiciones: ${lagRecord.result} (${lagRecord.dateStr}).`,
    weights: [lag],
    supporting: [lagRecord.result],
  };
}

// ─── MODELO 13: Entropía de Shannon ──────────────────────────
export function modelEntropy(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  // Seleccionar dígito con menor entropía (más predecible) por posición
  const freq = calcPositionFrequency(records, digitCount);
  const digits = Array.from({ length: digitCount }, (_, p) => {
    const posFreq = freq[p] || {};
    // Menor entropía → mayor concentración → más probable
    return Object.entries(posFreq).sort((a, b) => b[1] - a[1])[0]?.[0] || '0';
  });

  // Calcular entropía por posición
  const entropies = Array.from({ length: digitCount }, (_, p) => {
    const posFreq = freq[p] || {};
    const total = Object.values(posFreq).reduce((a, b) => a + b, 0) || 1;
    return -Object.values(posFreq).reduce((acc, c) => {
      const p2 = c / total;
      return acc + (p2 > 0 ? p2 * Math.log2(p2) : 0);
    }, 0);
  });

  return {
    modelId: 'entropy',
    modelName: 'Entropía de Shannon',
    modelCategory: 'Teoría de la Información',
    prediction: formatPred(digits),
    digits,
    confidence: 62,
    score: 62,
    details: `Entropías por posición: [${entropies.map((e) => e.toFixed(2)).join(', ')}] bits.`,
    weights: entropies,
    supporting: [],
  };
}

// ─── MODELO 14: Análisis de Percentiles (IQR) ────────────────
export function modelPercentile(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const values = records.map((r) => r.numericValue);
  const med = median(values);
  const maxVal = Math.pow(10, digitCount) - 1;
  const clamped = Math.max(0, Math.min(maxVal, Math.round(med)));
  const predStr = String(clamped).padStart(digitCount, '0').slice(-digitCount);

  return {
    modelId: 'percentile',
    modelName: 'Análisis de Percentiles (Mediana)',
    modelCategory: 'Estadístico',
    prediction: predStr,
    digits: predStr.split(''),
    confidence: 57,
    score: 57,
    details: `Mediana numérica: ${med.toFixed(0)}. Rango: [${Math.min(...values)}-${Math.max(...values)}].`,
    weights: [med],
    supporting: [],
  };
}

// ─── MODELO 15: Regresión Estacional Mensual ─────────────────
export function modelSeasonal(
  records: LotteryRecord[],
  digitCount: number,
  targetMonth: number,
): ModelPrediction {
  const monthRecords = records.filter((r) => r.month === targetMonth);
  const src = monthRecords.length >= 5 ? monthRecords : records;
  const freq = calcPositionFrequency(src, digitCount);
  const digits = topDigitPerPosition(freq, digitCount);
  const conf = monthRecords.length >= 5 ? 71 : 55;

  return {
    modelId: 'seasonal',
    modelName: 'Regresión Estacional Mensual',
    modelCategory: 'Estadístico',
    prediction: formatPred(digits),
    digits,
    confidence: conf,
    score: conf,
    details: `Mes ${targetMonth}: ${monthRecords.length} sorteos históricos. Patrón mensual.`,
    weights: [],
    supporting: monthRecords.slice(-3).map((r) => r.result),
  };
}

// ─── MODELO 16: Monte Carlo Simplificado ─────────────────────
export function modelMonteCarlo(
  records: LotteryRecord[],
  digitCount: number,
  dateRecords: LotteryRecord[],
  iterations: number = 10000,
): ModelPrediction {
  const src = dateRecords.length >= 3 ? dateRecords : records;
  const freq = calcPositionFrequency(src, digitCount);
  const simulationCounts: Record<string, number> = {};

  for (let iter = 0; iter < iterations; iter++) {
    const simDigits = Array.from({ length: digitCount }, (_, p) => {
      const posFreq = freq[p] || {};
      const total = Object.values(posFreq).reduce((a, b) => a + b, 0) || 1;
      let rand = Math.random() * total;
      for (const [d, count] of Object.entries(posFreq)) {
        rand -= count;
        if (rand <= 0) return d;
      }
      return '0';
    });
    const simResult = simDigits.join('');
    simulationCounts[simResult] = (simulationCounts[simResult] || 0) + 1;
  }

  const best = Object.entries(simulationCounts).sort((a, b) => b[1] - a[1])[0];
  const predStr = best?.[0] || '0'.repeat(digitCount);

  return {
    modelId: 'monte_carlo',
    modelName: 'Simulación Monte Carlo',
    modelCategory: 'Simulación',
    prediction: predStr,
    digits: predStr.split(''),
    confidence: 69,
    score: 69,
    details: `${iterations.toLocaleString()} iteraciones. Resultado más frecuente: ${predStr} (${best?.[1]} veces).`,
    weights: [iterations],
    supporting: Object.entries(simulationCounts).sort((a, b) => b[1] - a[1]).slice(1, 4).map(([k]) => k),
  };
}

// ─── MODELO 17: Desviación Estándar (Z-Score) ────────────────
export function modelZScore(
  records: LotteryRecord[],
  digitCount: number,
): ModelPrediction {
  const values = records.map((r) => r.numericValue);
  const avg = mean(values);
  const sd = stdDev(values);
  // Predecir regresión a la media
  const maxVal = Math.pow(10, digitCount) - 1;
  const predicted = Math.max(0, Math.min(maxVal, Math.round(avg)));
  const predStr = String(predicted).padStart(digitCount, '0').slice(-digitCount);

  return {
    modelId: 'zscore',
    modelName: 'Análisis Z-Score (Regresión Media)',
    modelCategory: 'Estadístico',
    prediction: predStr,
    digits: predStr.split(''),
    confidence: 58,
    score: 58,
    details: `μ=${avg.toFixed(0)}, σ=${sd.toFixed(0)}. Regresión a la media.`,
    weights: [avg, sd],
    supporting: [],
  };
}

// ─── MODELO 18: Análisis de Números Fríos/Calientes ──────────
export function modelHotCold(
  records: LotteryRecord[],
  digitCount: number,
  _dateRecords: LotteryRecord[],
): ModelPrediction {
  const recent = records.slice(-Math.min(30, records.length));
  const recentFreq = calcPositionFrequency(recent, digitCount);
  const globalFreq = calcPositionFrequency(records, digitCount);

  // Dígito "caliente en fecha, frío globalmente" → subestimado
  const digits = Array.from({ length: digitCount }, (_, p) => {
    const recentTotal = Object.values(recentFreq[p] || {}).reduce((a, b) => a + b, 0) || 1;
    const globalTotal = Object.values(globalFreq[p] || {}).reduce((a, b) => a + b, 0) || 1;
    let bestDigit = '0'; let bestScore = -Infinity;
    for (let d = 0; d <= 9; d++) {
      const ds = String(d);
      const recentRate = ((recentFreq[p]?.[ds] || 0) + 0.5) / recentTotal;
      const globalRate = ((globalFreq[p]?.[ds] || 0) + 0.5) / globalTotal;
      const score = recentRate * 0.6 + globalRate * 0.4;
      if (score > bestScore) { bestScore = score; bestDigit = ds; }
    }
    return bestDigit;
  });

  return {
    modelId: 'hot_cold',
    modelName: 'Análisis Caliente/Frío Adaptativo',
    modelCategory: 'Análisis Contextual',
    prediction: formatPred(digits),
    digits,
    confidence: 66,
    score: 66,
    details: `Últimos ${recent.length} sorteos vs historial completo. Ponderación reciente 60%.`,
    weights: [0.6, 0.4],
    supporting: [],
  };
}

// ─── Ejecutar todos los modelos ───────────────────────────────
export function runAllModels(
  allRecords: LotteryRecord[],
  dateRecords: LotteryRecord[],
  digitCount: number,
  targetMonth: number,
  targetDay: number,
): ModelPrediction[] {
  if (allRecords.length === 0) return [];

  return [
    modelFrequency(allRecords, digitCount, dateRecords),
    modelWeightedFrequency(allRecords, digitCount, dateRecords),
    modelBayesian(allRecords, digitCount, dateRecords),
    modelMarkov(allRecords, digitCount),
    modelMarkov2(allRecords, digitCount),
    modelLinearRegression(allRecords, digitCount),
    modelEMA(allRecords, digitCount),
    modelCyclical(allRecords, digitCount, dateRecords),
    modelKNN(allRecords, digitCount, targetMonth, targetDay),
    modelPairCorrelation(allRecords, digitCount),
    modelModular(allRecords, digitCount),
    modelLag(allRecords, digitCount, 7),
    modelEntropy(allRecords, digitCount),
    modelPercentile(allRecords, digitCount),
    modelSeasonal(allRecords, digitCount, targetMonth),
    modelMonteCarlo(allRecords, digitCount, dateRecords, 10000),
    modelZScore(allRecords, digitCount),
    modelHotCold(allRecords, digitCount, dateRecords),
  ];
}
