// ============================================================
// TIPOS CENTRALES DEL SISTEMA LOTOPRO 2026
// ============================================================

export interface LotteryRecord {
  date: Date;
  dateStr: string;
  result: string;
  digits: string[];
  numericValue: number;
  month: number;
  day: number;
  year: number;
  dayOfWeek: number;
  weekOfYear: number;
  monthDay: string; // "MM-DD" key
}

export interface ParsedCSV {
  records: LotteryRecord[];
  digitCount: number;
  totalRecords: number;
  dateRange: { min: Date; max: Date };
  errors: string[];
}

export interface FrequencyMap {
  [digit: string]: number;
}

export interface PositionFrequencyMap {
  [position: number]: FrequencyMap;
}

export interface ModelPrediction {
  modelId: string;
  modelName: string;
  modelCategory: string;
  prediction: string;
  digits: string[];
  confidence: number;       // 0-100
  score: number;            // weighted score
  details: string;
  weights: number[];        // per-digit weights
  supporting: string[];     // supporting numbers
}

export interface CrossReferenceResult {
  finalPrediction: string;
  finalDigits: string[];
  overallConfidence: number;
  consensusScore: number;
  modelVotes: Record<string, number>;
  digitScores: Record<string, Record<string, number>>;
  positionScores: Array<Record<string, number>>;
  topCandidates: Array<{ number: string; score: number; votes: number; models: string[] }>;
  methodology: string;
  breakdown: CrossRefBreakdown;
}

export interface CrossRefBreakdown {
  frequencyWeight: number;
  recencyWeight: number;
  consensusWeight: number;
  patternWeight: number;
  dateContextWeight: number;
}

export interface AnalysisResult {
  targetDate: { month: number; day: number };
  dateKey: string;
  historicalMatches: LotteryRecord[];
  allRecords: LotteryRecord[];
  models: ModelPrediction[];
  crossReference: CrossReferenceResult;
  statistics: GlobalStatistics;
  digitCount: number;
}

export interface GlobalStatistics {
  totalDraws: number;
  matchingDateDraws: number;
  globalFrequency: PositionFrequencyMap;
  dateFrequency: PositionFrequencyMap;
  hotNumbers: string[];
  coldNumbers: string[];
  overallHotDigits: Array<{ digit: string; count: number; percentage: number }>;
  positionStats: Array<{
    position: number;
    topDigits: Array<{ digit: string; count: number; percentage: number }>;
  }>;
  gaps: Record<string, number>;
  streaks: Record<string, number>;
  cycles: number[];
  evenOddBalance: { even: number; odd: number };
  sumStats: { mean: number; median: number; stdDev: number; mode: number };
}

export type TabId = 'upload' | 'date-analysis' | 'predictions' | 'cross-reference' | 'statistics' | 'charts';

export interface AppState {
  csvData: ParsedCSV | null;
  analysisResult: AnalysisResult | null;
  selectedMonth: number;
  selectedDay: number;
  activeTab: TabId;
  isAnalyzing: boolean;
  error: string | null;
}
