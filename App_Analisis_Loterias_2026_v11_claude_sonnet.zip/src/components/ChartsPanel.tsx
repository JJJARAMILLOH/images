import React, { useMemo, useState } from 'react';
import type { AnalysisResult } from '../types';
import { Card, CardHeader, CardBody } from './ui/Card';
import {
  ComposedChart, Area, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, Cell, BarChart, ScatterChart, Scatter, ZAxis,
} from 'recharts';

interface ChartsPanelProps {
  result: AnalysisResult;
}

const COLORS = ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#f97316', '#84cc16', '#a78bfa', '#67e8f9'];

export const ChartsPanel: React.FC<ChartsPanelProps> = ({ result }) => {
  const [chartPeriod, setChartPeriod] = useState<'all' | 'last100' | 'last50'>('last100');

  const { allRecords, digitCount, historicalMatches } = result;

  // Datos para gráfico de tendencia numérica
  const trendData = useMemo(() => {
    const src = chartPeriod === 'all' ? allRecords :
                chartPeriod === 'last100' ? allRecords.slice(-100) : allRecords.slice(-50);
    return src.map((r, i) => ({
      idx: i + 1,
      value: r.numericValue,
      date: r.dateStr,
      result: r.result,
    }));
  }, [allRecords, chartPeriod]);

  // Frecuencia de dígitos por posición
  const positionFreqData = useMemo(() => {
    return Array.from({ length: 10 }, (_, d) => {
      const row: Record<string, number | string> = { digit: String(d) };
      for (let p = 0; p < digitCount; p++) {
        row[`Pos${p + 1}`] = allRecords.filter((r) => r.digits[p] === String(d)).length;
      }
      return row;
    });
  }, [allRecords, digitCount]);

  // Distribución por mes
  const monthData = useMemo(() => {
    const months = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
    return months.map((name, idx) => ({
      name,
      count: allRecords.filter((r) => r.month === idx + 1).length,
    }));
  }, [allRecords]);

  // Distribución día de semana
  const weekData = useMemo(() => {
    const days = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
    return days.map((name, idx) => ({
      name,
      count: allRecords.filter((r) => r.dayOfWeek === idx).length,
    }));
  }, [allRecords]);

  // Histograma de valores numéricos
  const histogramData = useMemo(() => {
    const max = Math.pow(10, digitCount) - 1;
    const bins = 20;
    const binSize = Math.ceil(max / bins);
    return Array.from({ length: bins }, (_, i) => {
      const lo = i * binSize;
      const hi = Math.min((i + 1) * binSize - 1, max);
      return {
        range: `${lo}-${hi}`,
        count: allRecords.filter((r) => r.numericValue >= lo && r.numericValue <= hi).length,
      };
    });
  }, [allRecords, digitCount]);

  // Scatter: día del mes vs resultado
  const scatterData = useMemo(() => {
    return allRecords.slice(-200).map((r) => ({
      x: r.day,
      y: r.numericValue,
      z: 1,
    }));
  }, [allRecords]);

  // Histórico de misma fecha por año
  const dateHistoryData = useMemo(() => {
    return historicalMatches.map((r) => ({
      year: r.year,
      value: r.numericValue,
      result: r.result,
    }));
  }, [historicalMatches]);

  return (
    <div className="space-y-6">
      {/* Controles */}
      <div className="flex gap-2">
        {[
          { key: 'last50', label: 'Últimos 50' },
          { key: 'last100', label: 'Últimos 100' },
          { key: 'all', label: 'Todo' },
        ].map((opt) => (
          <button
            key={opt.key}
            onClick={() => setChartPeriod(opt.key as typeof chartPeriod)}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              chartPeriod === opt.key ? 'bg-blue-600 text-white' : 'bg-slate-700/50 text-slate-400 hover:text-white'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {/* Tendencia de valores */}
      <Card glow="blue">
        <CardHeader>
          <h3 className="font-semibold text-white">📈 Tendencia de Resultados Numéricos</h3>
        </CardHeader>
        <CardBody>
          <ResponsiveContainer width="100%" height={260}>
            <ComposedChart data={trendData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="idx" tick={{ fill: '#94a3b8', fontSize: 11 }} label={{ value: 'Sorteo #', position: 'insideBottom', fill: '#64748b', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                labelStyle={{ color: '#e2e8f0' }}
                itemStyle={{ color: '#94a3b8' }}
                formatter={(val, _name, props) => [props.payload?.result || val, 'Resultado']}
              />
              <Area type="monotone" dataKey="value" stroke="#3b82f6" fill="url(#areaGrad)" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={1} dot={false} strokeDasharray="3 3" />
            </ComposedChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      {/* Frecuencia por posición */}
      <Card glow="purple">
        <CardHeader>
          <h3 className="font-semibold text-white">🎯 Frecuencia de Dígitos por Posición</h3>
        </CardHeader>
        <CardBody>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={positionFreqData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="digit" tick={{ fill: '#94a3b8', fontSize: 12, fontFamily: 'monospace' }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                labelStyle={{ color: '#e2e8f0', fontFamily: 'monospace' }}
                itemStyle={{ color: '#94a3b8' }}
              />
              <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 12 }} />
              {Array.from({ length: digitCount }, (_, p) => (
                <Bar key={p} dataKey={`Pos${p + 1}`} fill={COLORS[p]} radius={[2, 2, 0, 0]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      {/* Distribución mensual + semanal */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white text-sm">📅 Distribución Mensual</h3>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={monthData} margin={{ top: 0, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 6 }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                  {monthData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white text-sm">📆 Distribución Semanal</h3>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weekData} margin={{ top: 0, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 6 }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                  {weekData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>
      </div>

      {/* Histograma numérico + Scatter */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white text-sm">📊 Histograma de Resultados</h3>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={histogramData} margin={{ top: 0, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="range" tick={false} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 6 }}
                  labelStyle={{ color: '#e2e8f0', fontFamily: 'monospace', fontSize: 11 }}
                />
                <Bar dataKey="count" fill="#6366f1" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardBody>
        </Card>

        {/* Histórico misma fecha */}
        <Card glow="cyan">
          <CardHeader>
            <h3 className="font-semibold text-white text-sm">🗓️ Resultados por Año (Misma Fecha)</h3>
          </CardHeader>
          <CardBody>
            {dateHistoryData.length < 2 ? (
              <div className="flex items-center justify-center h-40 text-slate-500 text-sm">
                No hay suficientes datos para esta fecha
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <ComposedChart data={dateHistoryData} margin={{ top: 0, right: 5, left: -15, bottom: 0 }}>
                  <defs>
                    <linearGradient id="dateGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="year" tick={{ fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 6 }}
                    labelStyle={{ color: '#e2e8f0' }}
                    formatter={(val, _, props) => [props.payload?.result || val, 'Resultado']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#06b6d4" fill="url(#dateGrad)" strokeWidth={2} />
                  <Line type="monotone" dataKey="value" stroke="#06b6d4" strokeWidth={2} dot={{ fill: '#06b6d4', r: 4 }} />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </CardBody>
        </Card>
      </div>

      {/* Scatter día vs resultado */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-white text-sm">🔵 Dispersión: Día del Mes vs Resultado (últimos 200)</h3>
        </CardHeader>
        <CardBody>
          <ResponsiveContainer width="100%" height={220}>
            <ScatterChart margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="x" type="number" name="Día" tick={{ fill: '#94a3b8', fontSize: 11 }} label={{ value: 'Día del mes', position: 'insideBottom', fill: '#64748b', fontSize: 11 }} domain={[1, 31]} />
              <YAxis dataKey="y" type="number" name="Resultado" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <ZAxis range={[20, 20]} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                labelStyle={{ color: '#e2e8f0' }}
                cursor={{ strokeDasharray: '3 3' }}
              />
              <Scatter data={scatterData} fill="#8b5cf6" fillOpacity={0.5} />
            </ScatterChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>
    </div>
  );
};
