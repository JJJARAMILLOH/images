import React from 'react';
import type { AnalysisResult } from '../types';
import { Card, CardHeader, CardBody } from './ui/Card';
import { Badge } from './ui/Badge';
import { ProgressBar } from './ui/ProgressBar';

interface DateAnalysisProps {
  result: AnalysisResult;
}

const MONTHS = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const DAYS_OF_WEEK = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];

export const DateAnalysis: React.FC<DateAnalysisProps> = ({ result }) => {
  const { targetDate, historicalMatches, allRecords, statistics, digitCount } = result;
  const month = targetDate.month;
  const day = targetDate.day;

  const maxFreq = Math.max(...statistics.positionStats.map(ps => ps.topDigits[0]?.count || 0), 1);

  return (
    <div className="space-y-6">
      {/* Header de fecha */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-cyan-600/20 border border-blue-500/20 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-sm text-slate-400 mb-1">Analizando fecha</p>
            <h2 className="text-3xl font-bold text-white">
              {String(day).padStart(2,'0')} de {MONTHS[month - 1]}
            </h2>
            <p className="text-slate-400 mt-1">Todos los años disponibles en el historial</p>
          </div>
          <div className="flex gap-4">
            <div className="text-center bg-slate-800/50 rounded-xl px-5 py-3">
              <p className="text-3xl font-bold font-mono text-blue-400">{historicalMatches.length}</p>
              <p className="text-xs text-slate-400 mt-1">Sorteos en esta fecha</p>
            </div>
            <div className="text-center bg-slate-800/50 rounded-xl px-5 py-3">
              <p className="text-3xl font-bold font-mono text-purple-400">{allRecords.length.toLocaleString()}</p>
              <p className="text-xs text-slate-400 mt-1">Total histórico</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabla histórica de misma fecha */}
      <Card glow="blue">
        <CardHeader>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              Resultados Históricos — {String(day).padStart(2,'0')}/{String(month).padStart(2,'0')}
            </h3>
            <Badge variant="info">{historicalMatches.length} registros</Badge>
          </div>
        </CardHeader>
        <CardBody className="p-0">
          {historicalMatches.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <svg className="w-12 h-12 mx-auto mb-3 opacity-40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p>No hay registros para esta fecha exacta</p>
              <p className="text-sm mt-1">Los modelos usarán el historial global</p>
            </div>
          ) : (
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-slate-800 border-b border-slate-700/50">
                  <tr>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">#</th>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">Año</th>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">Fecha</th>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">Resultado</th>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">Dígitos</th>
                    <th className="text-left px-6 py-3 text-slate-400 font-medium">Día</th>
                  </tr>
                </thead>
                <tbody>
                  {historicalMatches.map((rec, idx) => (
                    <tr key={idx} className="border-b border-slate-700/30 hover:bg-slate-700/20 transition-colors">
                      <td className="px-6 py-3 text-slate-500 font-mono">{idx + 1}</td>
                      <td className="px-6 py-3">
                        <Badge variant="info">{rec.year}</Badge>
                      </td>
                      <td className="px-6 py-3 text-slate-300 font-mono">{rec.dateStr}</td>
                      <td className="px-6 py-3">
                        <span className="font-mono text-lg font-bold text-white tracking-widest bg-slate-700/40 px-3 py-1 rounded-lg">
                          {rec.result}
                        </span>
                      </td>
                      <td className="px-6 py-3">
                        <div className="flex gap-1">
                          {rec.digits.map((d, i) => (
                            <span key={i} className="w-7 h-7 flex items-center justify-center rounded-md bg-blue-500/20 text-blue-300 font-mono font-bold text-sm">
                              {d}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-3 text-slate-400 text-xs">{DAYS_OF_WEEK[rec.dayOfWeek]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>

      {/* Frecuencia por posición */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Global */}
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              Frecuencia por Posición (Global)
            </h3>
          </CardHeader>
          <CardBody className="space-y-4">
            {statistics.positionStats.map((ps) => (
              <div key={ps.position}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400 font-medium">Posición {ps.position + 1}</span>
                  <div className="flex gap-1">
                    {ps.topDigits.slice(0, 3).map((td) => (
                      <span key={td.digit} className="text-xs font-mono font-bold text-purple-300 bg-purple-500/20 px-1.5 py-0.5 rounded">
                        {td.digit}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({length: 10}, (_, i) => {
                    const stat = ps.topDigits.find(t => +t.digit === i);
                    const h = stat ? (stat.count / maxFreq) * 100 : 0;
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
                        <div className="w-full bg-slate-700/40 rounded-sm" style={{ height: 40 }}>
                          <div
                            className="w-full bg-gradient-to-t from-purple-600 to-purple-400 rounded-sm transition-all duration-500"
                            style={{ height: `${h}%`, marginTop: `${100-h}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-500">{i}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </CardBody>
        </Card>

        {/* Por fecha */}
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              Frecuencia por Posición (Esta Fecha)
            </h3>
          </CardHeader>
          <CardBody className="space-y-4">
            {historicalMatches.length < 2 ? (
              <div className="text-center py-8 text-slate-500 text-sm">
                Se necesitan al menos 2 registros de esta fecha para análisis específico.
              </div>
            ) : (
              Array.from({ length: digitCount }, (_, p) => {
                const posFreq: Record<string,number> = {};
                for (const rec of historicalMatches) {
                  const d = rec.digits[p];
                  if (d) posFreq[d] = (posFreq[d] || 0) + 1;
                }
                const maxCount = Math.max(...Object.values(posFreq), 1);
                const topDigits = Object.entries(posFreq).sort((a,b) => b[1]-a[1]);
                return (
                  <div key={p}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-slate-400 font-medium">Posición {p + 1}</span>
                      <div className="flex gap-1">
                        {topDigits.slice(0,3).map(([d]) => (
                          <span key={d} className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/20 px-1.5 py-0.5 rounded">{d}</span>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-0.5">
                      {Array.from({length:10}, (_,i) => {
                        const c = posFreq[String(i)] || 0;
                        const h = (c / maxCount) * 100;
                        return (
                          <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
                            <div className="w-full bg-slate-700/40 rounded-sm" style={{ height: 40 }}>
                              <div
                                className="w-full bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-sm transition-all duration-500"
                                style={{ height: `${h}%`, marginTop: `${100-h}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-slate-500">{i}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            )}
          </CardBody>
        </Card>
      </div>

      {/* Dígitos más frecuentes globalmente */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            Ranking Global de Dígitos
          </h3>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {statistics.overallHotDigits.map((item, idx) => (
              <div key={item.digit} className={`rounded-xl p-3 border text-center ${
                idx === 0 ? 'border-amber-500/40 bg-amber-500/10' :
                idx < 3 ? 'border-blue-500/30 bg-blue-500/10' :
                'border-slate-700/50 bg-slate-700/20'
              }`}>
                <div className="text-2xl font-bold font-mono text-white mb-1">{item.digit}</div>
                <div className="text-xs text-slate-400">{item.count} apariciones</div>
                <ProgressBar value={item.percentage * 10} color={idx === 0 ? 'amber' : 'blue'} height="xs" className="mt-2" />
                <div className="text-xs text-slate-500 mt-1">{item.percentage.toFixed(1)}%</div>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Stats de suma */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-white">Estadísticas de Suma de Dígitos</h3>
        </CardHeader>
        <CardBody>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Media', value: statistics.sumStats.mean.toFixed(1), color: 'text-blue-400' },
              { label: 'Mediana', value: statistics.sumStats.median.toFixed(1), color: 'text-purple-400' },
              { label: 'Desv. Estándar', value: statistics.sumStats.stdDev.toFixed(1), color: 'text-cyan-400' },
              { label: 'Moda', value: statistics.sumStats.mode.toString(), color: 'text-amber-400' },
            ].map((s) => (
              <div key={s.label} className="text-center bg-slate-700/30 rounded-xl p-4">
                <p className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</p>
                <p className="text-xs text-slate-400 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-blue-500" />
              <span className="text-slate-400">Pares: {statistics.evenOddBalance.even.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-purple-500" />
              <span className="text-slate-400">Impares: {statistics.evenOddBalance.odd.toLocaleString()}</span>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};
