import React from 'react';
import type { CrossReferenceResult } from '../types';
import { Card, CardHeader, CardBody } from './ui/Card';
import { Badge } from './ui/Badge';
import { ProgressBar } from './ui/ProgressBar';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell,
} from 'recharts';

interface CrossReferencePanelProps {
  result: CrossReferenceResult;
  digitCount: number;
}

const DIGIT_GRADIENTS = [
  { bg: 'bg-gradient-to-br from-blue-600 to-blue-400', shadow: 'shadow-blue-500/40' },
  { bg: 'bg-gradient-to-br from-purple-600 to-purple-400', shadow: 'shadow-purple-500/40' },
  { bg: 'bg-gradient-to-br from-cyan-600 to-cyan-400', shadow: 'shadow-cyan-500/40' },
  { bg: 'bg-gradient-to-br from-emerald-600 to-emerald-400', shadow: 'shadow-emerald-500/40' },
  { bg: 'bg-gradient-to-br from-amber-600 to-amber-400', shadow: 'shadow-amber-500/40' },
  { bg: 'bg-gradient-to-br from-red-600 to-red-400', shadow: 'shadow-red-500/40' },
];

const RANK_COLORS = ['#f59e0b', '#94a3b8', '#cd7c4a', '#6366f1', '#06b6d4', '#10b981', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

export const CrossReferencePanel: React.FC<CrossReferencePanelProps> = ({ result, digitCount }) => {
  // Datos para radar de pesos de metodología
  const radarData = [
    { subject: 'Frecuencia', A: result.breakdown.frequencyWeight * 100 },
    { subject: 'Recencia', A: result.breakdown.recencyWeight * 100 },
    { subject: 'Consenso', A: result.breakdown.consensusWeight * 100 },
    { subject: 'Patrón', A: result.breakdown.patternWeight * 100 },
    { subject: 'Fecha', A: result.breakdown.dateContextWeight * 100 },
  ];

  // Datos para barras de candidatos
  const candidateData = result.topCandidates.slice(0, 8).map((c, i) => ({
    name: c.number,
    score: c.score,
    votes: c.votes,
    fill: RANK_COLORS[i],
  }));

  // Datos por posición para cada dígito
  const positionCharts = Array.from({ length: digitCount }, (_, p) => {
    const posKey = `pos_${p}`;
    const scores = result.digitScores[posKey] || {};
    return Object.entries(scores)
      .map(([d, s]) => ({ digit: d, score: s }))
      .sort((a, b) => +a.digit - +b.digit);
  });

  const confLevel = result.overallConfidence >= 75 ? 'success' :
    result.overallConfidence >= 60 ? 'info' :
    result.overallConfidence >= 45 ? 'warning' : 'danger';

  return (
    <div className="space-y-6">
      {/* PREDICCIÓN FINAL - HERO */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-purple-950 border border-blue-500/20 p-8">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl" />
        </div>

        <div className="relative text-center space-y-6">
          <div>
            <Badge variant="info" size="md">🎯 Predicción Final — Referencia Cruzada Multi-Método</Badge>
            <h2 className="text-2xl font-bold text-white mt-3">Combinación Óptima</h2>
            <p className="text-slate-400 text-sm mt-1">{result.methodology}</p>
          </div>

          {/* Dígitos principales */}
          <div className="flex items-center justify-center gap-4 py-4">
            {result.finalDigits.slice(0, digitCount).map((d, i) => (
              <div key={i} className="flex flex-col items-center gap-2">
                <div className={`w-20 h-20 rounded-2xl ${DIGIT_GRADIENTS[i % DIGIT_GRADIENTS.length].bg} ${DIGIT_GRADIENTS[i % DIGIT_GRADIENTS.length].shadow} shadow-xl flex items-center justify-center text-white font-black text-4xl font-mono`}>
                  {d}
                </div>
                <span className="text-xs text-slate-500">Pos {i + 1}</span>
              </div>
            ))}
          </div>

          {/* Número completo */}
          <div className="inline-block bg-slate-800/60 rounded-2xl px-8 py-4 border border-slate-600/30">
            <p className="text-5xl font-black font-mono tracking-widest text-white">
              {result.finalPrediction}
            </p>
          </div>

          {/* Métricas */}
          <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="bg-slate-800/50 rounded-xl p-3">
              <div className={`text-2xl font-bold font-mono ${
                confLevel === 'success' ? 'text-emerald-400' :
                confLevel === 'info' ? 'text-blue-400' :
                confLevel === 'warning' ? 'text-amber-400' : 'text-red-400'
              }`}>
                {result.overallConfidence}%
              </div>
              <div className="text-xs text-slate-400 mt-0.5">Confianza</div>
            </div>
            <div className="bg-slate-800/50 rounded-xl p-3">
              <div className="text-2xl font-bold font-mono text-purple-400">{result.consensusScore}%</div>
              <div className="text-xs text-slate-400 mt-0.5">Consenso</div>
            </div>
            <div className="bg-slate-800/50 rounded-xl p-3">
              <div className="text-2xl font-bold font-mono text-cyan-400">{Object.keys(result.modelVotes).length}</div>
              <div className="text-xs text-slate-400 mt-0.5">Modelos</div>
            </div>
          </div>

          <ProgressBar value={result.overallConfidence} color="gradient" height="md" className="max-w-sm mx-auto" />
        </div>
      </div>

      {/* Top candidatos */}
      <Card glow="blue">
        <CardHeader>
          <h3 className="font-semibold text-white flex items-center gap-2">
            <span className="text-xl">🏆</span>
            Top Candidatos por Puntaje Ponderado
          </h3>
        </CardHeader>
        <CardBody>
          <div className="space-y-3 mb-6">
            {result.topCandidates.slice(0, 8).map((c, i) => (
              <div key={c.number} className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${
                i === 0 ? 'border-amber-500/40 bg-amber-500/10' :
                i < 3 ? 'border-blue-500/20 bg-blue-500/5' :
                'border-slate-700/30 bg-slate-700/10'
              }`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                  i === 0 ? 'bg-amber-500 text-white' :
                  i === 1 ? 'bg-slate-400 text-white' :
                  i === 2 ? 'bg-amber-700 text-white' :
                  'bg-slate-700 text-slate-300'
                }`}>
                  {i + 1}
                </div>
                <span className="font-mono text-xl font-bold text-white tracking-widest">{c.number}</span>
                <div className="flex-1">
                  <ProgressBar value={c.score} color={i === 0 ? 'amber' : 'blue'} height="xs" />
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-white">{c.score}</div>
                  <div className="text-xs text-slate-400">{c.votes} votos</div>
                </div>
              </div>
            ))}
          </div>

          {/* Bar chart candidatos */}
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={candidateData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12, fontFamily: 'JetBrains Mono, monospace' }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                labelStyle={{ color: '#e2e8f0', fontFamily: 'monospace' }}
                itemStyle={{ color: '#94a3b8' }}
              />
              <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                {candidateData.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardBody>
      </Card>

      {/* Scores por posición */}
      <div className={`grid gap-4 ${digitCount <= 3 ? 'md:grid-cols-3' : digitCount <= 4 ? 'md:grid-cols-4' : 'md:grid-cols-3'}`}>
        {positionCharts.map((data, p) => (
          <Card key={p}>
            <CardHeader>
              <h4 className="text-sm font-semibold text-white">Posición {p + 1}</h4>
            </CardHeader>
            <CardBody className="p-3">
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={data} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="digit" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                  <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: 6 }}
                    labelStyle={{ color: '#e2e8f0' }}
                  />
                  <Bar dataKey="score" radius={[3, 3, 0, 0]}>
                    {data.map((entry, i) => (
                      <Cell
                        key={i}
                        fill={entry.digit === result.finalDigits[p] ? '#3b82f6' : '#334155'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div className="text-center mt-2">
                <span className="text-xs text-slate-400">Ganador: </span>
                <span className="text-sm font-bold font-mono text-blue-400">{result.finalDigits[p]}</span>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Radar metodología */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card glow="purple">
          <CardHeader>
            <h3 className="font-semibold text-white">Pesos de Metodología</h3>
          </CardHeader>
          <CardBody>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, 40]} tick={{ fill: '#64748b', fontSize: 9 }} />
                <Radar name="Peso" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
            <div className="space-y-2 mt-2">
              {[
                { label: 'Frecuencia histórica', value: result.breakdown.frequencyWeight },
                { label: 'Recencia de datos', value: result.breakdown.recencyWeight },
                { label: 'Consenso modelos', value: result.breakdown.consensusWeight },
                { label: 'Patrones detectados', value: result.breakdown.patternWeight },
                { label: 'Contexto fecha', value: result.breakdown.dateContextWeight },
              ].map((b) => (
                <div key={b.label} className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 w-36 flex-shrink-0">{b.label}</span>
                  <ProgressBar value={b.value * 100} color="purple" height="xs" className="flex-1" />
                  <span className="text-xs font-mono text-purple-300 w-10 text-right">{Math.round(b.value * 100)}%</span>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        {/* Votos de modelos */}
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white">Confianza Individual por Modelo</h3>
          </CardHeader>
          <CardBody className="space-y-2 max-h-80 overflow-y-auto">
            {Object.entries(result.modelVotes)
              .sort((a, b) => b[1] - a[1])
              .map(([modelId, conf]) => (
                <div key={modelId} className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 w-40 flex-shrink-0 truncate capitalize">
                    {modelId.replace(/_/g, ' ')}
                  </span>
                  <ProgressBar
                    value={conf}
                    color={conf >= 70 ? 'green' : conf >= 60 ? 'blue' : conf >= 50 ? 'amber' : 'red'}
                    height="xs"
                    className="flex-1"
                  />
                  <span className="text-xs font-mono text-slate-300 w-9 text-right">{conf}%</span>
                </div>
              ))}
          </CardBody>
        </Card>
      </div>

      {/* Disclaimer */}
      <div className="rounded-xl bg-slate-800/40 border border-slate-700/30 p-4">
        <p className="text-xs text-slate-500 text-center leading-relaxed">
          ⚠️ <strong className="text-slate-400">Aviso importante:</strong> Este sistema es una herramienta de análisis estadístico educativo.
          La lotería es un juego de azar y ningún modelo puede predecir resultados con certeza.
          Los porcentajes de confianza reflejan la consistencia estadística de los modelos, no garantías de acierto.
          Juega responsablemente.
        </p>
      </div>
    </div>
  );
};
