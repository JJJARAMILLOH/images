import { useState } from 'react';
import type { ModelPrediction } from '../types';
import { Badge } from './ui/Badge';
import { ProgressBar } from './ui/ProgressBar';

interface PredictionsPanelProps {
  predictions: ModelPrediction[];
  digitCount: number;
}

function getCategoryBadge(cat: string): 'blue' | 'purple' | 'cyan' | 'success' | 'warning' | 'info' | 'danger' {
  const map: Record<string, 'blue' | 'purple' | 'cyan' | 'success' | 'warning' | 'info' | 'danger'> = {
    'Estadístico': 'blue',
    'Probabilístico': 'purple',
    'Secuencial': 'cyan',
    'Series Temporales': 'warning',
    'Aprendizaje Automático': 'success',
    'Correlación': 'info',
    'Matemático': 'cyan',
    'Simulación': 'purple',
    'Teoría de la Información': 'info',
    'Regresión': 'warning',
    'Análisis Contextual': 'success',
  };
  return map[cat] || 'info';
}

function getConfidenceColor(conf: number): 'green' | 'amber' | 'red' | 'blue' {
  if (conf >= 70) return 'green';
  if (conf >= 60) return 'blue';
  if (conf >= 50) return 'amber';
  return 'red';
}

const DIGIT_COLORS = [
  'from-blue-600 to-blue-400',
  'from-purple-600 to-purple-400',
  'from-cyan-600 to-cyan-400',
  'from-emerald-600 to-emerald-400',
  'from-amber-600 to-amber-400',
  'from-red-600 to-red-400',
];

export const PredictionsPanel: React.FC<PredictionsPanelProps> = ({ predictions, digitCount }) => {
  const [filter, setFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'confidence' | 'name' | 'category'>('confidence');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = ['all', ...Array.from(new Set(predictions.map(p => p.modelCategory)))];

  const filtered = predictions
    .filter(p => filter === 'all' || p.modelCategory === filter)
    .sort((a, b) => {
      if (sortBy === 'confidence') return b.confidence - a.confidence;
      if (sortBy === 'name') return a.modelName.localeCompare(b.modelName);
      return a.modelCategory.localeCompare(b.modelCategory);
    });

  const avgConf = Math.round(predictions.reduce((a, p) => a + p.confidence, 0) / predictions.length);

  return (
    <div className="space-y-6">
      {/* Stats summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Modelos Ejecutados', value: predictions.length, icon: '🤖', color: 'text-blue-400' },
          { label: 'Confianza Promedio', value: `${avgConf}%`, icon: '📊', color: 'text-purple-400' },
          { label: 'Categorías', value: categories.length - 1, icon: '🏷️', color: 'text-cyan-400' },
          { label: 'Alta Confianza (≥70%)', value: predictions.filter(p => p.confidence >= 70).length, icon: '⭐', color: 'text-amber-400' },
        ].map((s) => (
          <div key={s.label} className="rounded-xl bg-slate-800/60 border border-slate-700/50 p-4 text-center">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</div>
            <div className="text-xs text-slate-400 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                filter === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-700/50 text-slate-400 hover:text-white hover:bg-slate-600/50'
              }`}
            >
              {cat === 'all' ? 'Todos' : cat}
            </button>
          ))}
        </div>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
          className="bg-slate-700/50 border border-slate-600/50 text-slate-300 text-xs rounded-lg px-3 py-1.5 outline-none"
        >
          <option value="confidence">Ordenar: Confianza</option>
          <option value="name">Ordenar: Nombre</option>
          <option value="category">Ordenar: Categoría</option>
        </select>
      </div>

      {/* Model cards */}
      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map((model, idx) => {
          const isExpanded = expandedId === model.modelId;
          const confColor = getConfidenceColor(model.confidence);
          return (
            <div
              key={model.modelId}
              className={`rounded-xl border transition-all duration-300 cursor-pointer ${
                isExpanded
                  ? 'border-blue-500/40 bg-slate-800/80'
                  : 'border-slate-700/50 bg-slate-800/40 hover:border-slate-600/70 hover:bg-slate-800/60'
              }`}
              onClick={() => setExpandedId(isExpanded ? null : model.modelId)}
            >
              <div className="p-4">
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-500">#{idx + 1}</span>
                    <div>
                      <h4 className="font-semibold text-sm text-white">{model.modelName}</h4>
                      <Badge variant={getCategoryBadge(model.modelCategory)} className="mt-0.5">
                        {model.modelCategory}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className={`text-xl font-bold font-mono ${
                      confColor === 'green' ? 'text-emerald-400' :
                      confColor === 'blue' ? 'text-blue-400' :
                      confColor === 'amber' ? 'text-amber-400' : 'text-red-400'
                    }`}>
                      {model.confidence}%
                    </div>
                    <div className="text-xs text-slate-500">confianza</div>
                  </div>
                </div>

                {/* Prediction */}
                <div className="flex items-center justify-center gap-2 my-3 py-3 bg-slate-900/40 rounded-xl">
                  {model.digits.slice(0, digitCount).map((d, i) => (
                    <div
                      key={i}
                      className={`w-10 h-10 rounded-xl bg-gradient-to-br ${DIGIT_COLORS[i % DIGIT_COLORS.length]} flex items-center justify-center text-white font-bold text-lg font-mono shadow-lg`}
                    >
                      {d}
                    </div>
                  ))}
                </div>

                {/* Confidence bar */}
                <ProgressBar
                  value={model.confidence}
                  color={confColor}
                  height="sm"
                />

                {/* Expanded */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-700/50 space-y-3">
                    <p className="text-xs text-slate-400 leading-relaxed">{model.details}</p>
                    {model.supporting.length > 0 && (
                      <div>
                        <p className="text-xs text-slate-500 mb-1.5">Números de soporte:</p>
                        <div className="flex flex-wrap gap-1.5">
                          {model.supporting.map((s, i) => (
                            <span key={i} className="font-mono text-xs text-slate-300 bg-slate-700/50 px-2 py-0.5 rounded">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
