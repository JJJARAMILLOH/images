import React from 'react';
import type { AnalysisResult } from '../types';
import { Card, CardHeader, CardBody } from './ui/Card';
import { Badge } from './ui/Badge';
import { ProgressBar } from './ui/ProgressBar';

interface StatisticsPanelProps {
  result: AnalysisResult;
}

export const StatisticsPanel: React.FC<StatisticsPanelProps> = ({ result }) => {
  const { statistics, allRecords, digitCount } = result;

  const totalDigits = allRecords.length * digitCount;
  const evenPct = totalDigits > 0 ? (statistics.evenOddBalance.even / totalDigits) * 100 : 50;

  // Top 15 números más frecuentes
  const numFreq: Record<string, number> = {};
  for (const rec of allRecords) {
    numFreq[rec.result] = (numFreq[rec.result] || 0) + 1;
  }
  const topNumbers = Object.entries(numFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15);
  const maxNumFreq = topNumbers[0]?.[1] || 1;

  // Gaps top 10
  const topGaps = Object.entries(statistics.gaps)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  // Números sin aparecer
  const allPossible = Math.pow(10, digitCount);
  const appeared = Object.keys(numFreq).length;
  const neverAppeared = allPossible - appeared;

  return (
    <div className="space-y-6">
      {/* KPIs principales */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total de Sorteos', value: allRecords.length.toLocaleString(), sub: 'en el historial', color: 'text-blue-400', icon: '📋' },
          { label: 'Números Únicos', value: appeared.toLocaleString(), sub: `de ${allPossible.toLocaleString()} posibles`, color: 'text-purple-400', icon: '🔢' },
          { label: 'Sin Aparecer', value: neverAppeared.toLocaleString(), sub: 'números vírgenes', color: 'text-amber-400', icon: '❄️' },
          { label: 'Años Cubiertos', value: new Set(allRecords.map(r => r.year)).size, sub: 'años de datos', color: 'text-cyan-400', icon: '📅' },
        ].map((kpi) => (
          <div key={kpi.label} className="rounded-xl bg-slate-800/60 border border-slate-700/50 p-5 text-center">
            <div className="text-2xl mb-2">{kpi.icon}</div>
            <div className={`text-3xl font-bold font-mono ${kpi.color}`}>{kpi.value}</div>
            <div className="text-xs text-slate-400 mt-1">{kpi.label}</div>
            <div className="text-xs text-slate-600 mt-0.5">{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Balance par/impar */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-white">⚖️ Balance Par / Impar</h3>
        </CardHeader>
        <CardBody>
          <div className="flex items-center gap-4 mb-3">
            <div className="flex-1">
              <div className="flex justify-between mb-1">
                <span className="text-sm text-blue-300">Pares</span>
                <span className="text-sm font-mono text-slate-300">{evenPct.toFixed(1)}%</span>
              </div>
              <div className="h-4 bg-slate-700 rounded-full overflow-hidden flex">
                <div className="bg-blue-500 transition-all duration-700" style={{ width: `${evenPct}%` }} />
                <div className="bg-purple-500 flex-1" />
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-xs text-slate-500">{statistics.evenOddBalance.even.toLocaleString()} pares</span>
                <span className="text-xs text-slate-500">{statistics.evenOddBalance.odd.toLocaleString()} impares</span>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Top 15 números */}
      <Card glow="blue">
        <CardHeader>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-white">🔥 Números Más Frecuentes</h3>
            <Badge variant="info">{topNumbers.length} mostrados</Badge>
          </div>
        </CardHeader>
        <CardBody>
          <div className="space-y-2">
            {topNumbers.map(([num, count], i) => (
              <div key={num} className="flex items-center gap-3">
                <span className={`w-6 text-xs font-bold text-center ${
                  i === 0 ? 'text-amber-400' : i < 3 ? 'text-slate-300' : 'text-slate-500'
                }`}>{i + 1}</span>
                <span className="font-mono text-base font-bold text-white w-16">{num}</span>
                <ProgressBar
                  value={(count / maxNumFreq) * 100}
                  color={i === 0 ? 'amber' : i < 3 ? 'blue' : 'purple'}
                  height="sm"
                  className="flex-1"
                />
                <span className="text-xs font-mono text-slate-400 w-8 text-right">{count}x</span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Números fríos (mayor gap) */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white">🧊 Números Más Fríos (Mayor Ausencia)</h3>
          </CardHeader>
          <CardBody>
            <div className="space-y-2">
              {topGaps.map(([num, days], i) => (
                <div key={num} className="flex items-center gap-3">
                  <span className="text-xs text-slate-500 w-5">{i + 1}</span>
                  <span className="font-mono text-sm font-bold text-white w-14">{num}</span>
                  <ProgressBar value={Math.min(100, days / 3)} color="cyan" height="xs" className="flex-1" />
                  <span className="text-xs font-mono text-cyan-400 w-16 text-right">{days} días</span>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        {/* Ciclos detectados */}
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white">🔄 Ciclos Detectados</h3>
          </CardHeader>
          <CardBody>
            {statistics.cycles.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-sm">No se detectaron ciclos significativos</div>
            ) : (
              <div className="space-y-3">
                {statistics.cycles.map((cycle, i) => (
                  <div key={cycle} className="flex items-center gap-3 p-3 bg-slate-700/30 rounded-xl">
                    <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                      i === 0 ? 'bg-purple-500 text-white' : 'bg-slate-600 text-slate-300'
                    }`}>{i + 1}</span>
                    <div>
                      <div className="text-sm font-bold text-white">Lag: {cycle} sorteos</div>
                      <div className="text-xs text-slate-400">Patrón de auto-correlación detectado</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-slate-700/30">
              <h4 className="text-sm font-semibold text-slate-300 mb-2">Estadísticas de Suma</h4>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { l: 'Media suma', v: statistics.sumStats.mean.toFixed(1) },
                  { l: 'Mediana', v: statistics.sumStats.median.toFixed(1) },
                  { l: 'Desv. Est.', v: statistics.sumStats.stdDev.toFixed(1) },
                  { l: 'Moda', v: statistics.sumStats.mode.toString() },
                ].map((s) => (
                  <div key={s.l} className="bg-slate-700/20 rounded-lg p-2 text-center">
                    <div className="text-base font-bold font-mono text-purple-400">{s.v}</div>
                    <div className="text-xs text-slate-500">{s.l}</div>
                  </div>
                ))}
              </div>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Números calientes y fríos globales */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card glow="amber">
          <CardHeader>
            <h3 className="font-semibold text-white">🔥 Números Calientes (Top 10)</h3>
          </CardHeader>
          <CardBody>
            <div className="flex flex-wrap gap-2">
              {statistics.hotNumbers.map((num, i) => (
                <div key={num} className={`flex items-center gap-2 px-3 py-2 rounded-xl border ${
                  i === 0 ? 'border-amber-500/60 bg-amber-500/20' :
                  i < 3 ? 'border-amber-500/30 bg-amber-500/10' :
                  'border-slate-700/50 bg-slate-700/20'
                }`}>
                  <span className={`text-xs ${i === 0 ? 'text-amber-300' : 'text-slate-500'}`}>#{i + 1}</span>
                  <span className="font-mono font-bold text-white">{num}</span>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="font-semibold text-white">❄️ Números Fríos (Bottom 10)</h3>
          </CardHeader>
          <CardBody>
            <div className="flex flex-wrap gap-2">
              {statistics.coldNumbers.map((num, i) => (
                <div key={num} className="flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-700/40 bg-slate-800/40">
                  <span className="text-xs text-slate-600">#{i + 1}</span>
                  <span className="font-mono font-bold text-slate-300">{num}</span>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Por posición detail */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-white">📍 Top 5 Dígitos por Posición</h3>
        </CardHeader>
        <CardBody>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/50">
                  <th className="text-left py-2 px-3 text-slate-400 font-medium">Rango</th>
                  {Array.from({ length: digitCount }, (_, p) => (
                    <th key={p} className="text-left py-2 px-3 text-slate-400 font-medium">Posición {p + 1}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[0, 1, 2, 3, 4].map((rank) => (
                  <tr key={rank} className="border-b border-slate-700/20 hover:bg-slate-700/10">
                    <td className="py-2 px-3">
                      <Badge variant={rank === 0 ? 'warning' : rank < 3 ? 'info' : 'default'}>
                        #{rank + 1}
                      </Badge>
                    </td>
                    {statistics.positionStats.map((ps, pi) => {
                      const td = ps.topDigits[rank];
                      return (
                        <td key={pi} className="py-2 px-3">
                          {td && (
                            <div className="flex items-center gap-2">
                              <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-sm ${
                                rank === 0 ? 'bg-blue-500/30 text-blue-300' : 'bg-slate-700/50 text-slate-300'
                              }`}>{td.digit}</span>
                              <span className="text-xs text-slate-500">{td.percentage.toFixed(0)}%</span>
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};
