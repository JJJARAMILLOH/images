import React from 'react';
import { cn } from '../../utils/cn';

interface ProgressBarProps {
  value: number;  // 0-100
  color?: 'blue' | 'purple' | 'cyan' | 'green' | 'amber' | 'red' | 'gradient';
  height?: 'xs' | 'sm' | 'md';
  showLabel?: boolean;
  label?: string;
  className?: string;
  animated?: boolean;
}

const colors = {
  blue: 'bg-blue-500',
  purple: 'bg-purple-500',
  cyan: 'bg-cyan-500',
  green: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-red-500',
  gradient: 'bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500',
};

const heights = {
  xs: 'h-1',
  sm: 'h-1.5',
  md: 'h-2.5',
};

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  color = 'blue',
  height = 'sm',
  showLabel = false,
  label,
  className,
  animated = false,
}) => {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className={cn('w-full', className)}>
      {(showLabel || label) && (
        <div className="flex justify-between mb-1">
          {label && <span className="text-xs text-slate-400">{label}</span>}
          {showLabel && <span className="text-xs font-mono text-slate-300">{pct.toFixed(0)}%</span>}
        </div>
      )}
      <div className={cn('w-full bg-slate-700/50 rounded-full overflow-hidden', heights[height])}>
        <div
          className={cn(
            'h-full rounded-full transition-all duration-700 ease-out',
            colors[color],
            animated && 'animate-pulse'
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};
