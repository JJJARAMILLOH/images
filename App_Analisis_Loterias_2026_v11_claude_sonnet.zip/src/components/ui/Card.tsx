
import { cn } from '../../utils/cn';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  glow?: 'none' | 'blue' | 'purple' | 'cyan' | 'green' | 'amber';
}

const glowStyles = {
  none: '',
  blue: 'shadow-blue-500/10 hover:shadow-blue-500/20',
  purple: 'shadow-purple-500/10 hover:shadow-purple-500/20',
  cyan: 'shadow-cyan-500/10 hover:shadow-cyan-500/20',
  green: 'shadow-emerald-500/10 hover:shadow-emerald-500/20',
  amber: 'shadow-amber-500/10 hover:shadow-amber-500/20',
};

export const Card: React.FC<CardProps> = ({ children, className, glow = 'none' }) => (
  <div className={cn(
    'rounded-2xl border border-slate-700/50 bg-slate-800/60 backdrop-blur-sm shadow-xl transition-shadow duration-300',
    glowStyles[glow],
    className
  )}>
    {children}
  </div>
);

export const CardHeader: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => (
  <div className={cn('px-6 py-4 border-b border-slate-700/50', className)}>{children}</div>
);

export const CardBody: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => (
  <div className={cn('px-6 py-5', className)}>{children}</div>
);
