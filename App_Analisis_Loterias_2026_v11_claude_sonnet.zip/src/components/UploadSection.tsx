import React, { useCallback, useState } from 'react';
import { cn } from '../utils/cn';
import type { ParsedCSV } from '../types';
import { parseCSV } from '../utils/csvParser';

interface UploadSectionProps {
  onDataLoaded: (data: ParsedCSV) => void;
  currentData: ParsedCSV | null;
}

export const UploadSection: React.FC<UploadSectionProps> = ({ onDataLoaded, currentData }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const processFile = useCallback((file: File) => {
    if (!file.name.endsWith('.csv') && !file.name.endsWith('.txt')) {
      setError('Por favor sube un archivo CSV o TXT válido.');
      return;
    }
    setIsLoading(true);
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = parseCSV(content);
        if (parsed.records.length === 0) {
          setError('No se pudieron extraer registros válidos del CSV. Verifique el formato.');
        } else {
          onDataLoaded(parsed);
          if (parsed.errors.length > 0) {
            setError(`Datos cargados con ${parsed.errors.length} advertencia(s). Primera: ${parsed.errors[0]}`);
          }
        }
      } catch (err) {
        setError(`Error procesando archivo: ${err instanceof Error ? err.message : 'desconocido'}`);
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
      setError('Error leyendo el archivo.');
      setIsLoading(false);
    };
    reader.readAsText(file, 'UTF-8');
  }, [onDataLoaded]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  }, [processFile]);

  return (
    <div className="space-y-6">
      {/* Zona de carga */}
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={cn(
          'relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 cursor-pointer group',
          isDragging
            ? 'border-blue-400 bg-blue-500/10 scale-[1.01]'
            : 'border-slate-600 hover:border-blue-500/60 hover:bg-slate-700/30',
        )}
      >
        <input
          type="file"
          accept=".csv,.txt"
          onChange={handleFileInput}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        <div className="space-y-4">
          <div className={cn(
            'w-20 h-20 mx-auto rounded-2xl flex items-center justify-center transition-all duration-300',
            isDragging ? 'bg-blue-500/30 scale-110' : 'bg-slate-700/60 group-hover:bg-blue-500/20',
          )}>
            {isLoading ? (
              <svg className="w-9 h-9 text-blue-400 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
              </svg>
            ) : (
              <svg className={cn('w-9 h-9 transition-colors', isDragging ? 'text-blue-300' : 'text-slate-400 group-hover:text-blue-400')} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
              </svg>
            )}
          </div>
          <div>
            <p className="text-lg font-semibold text-slate-200">
              {isLoading ? 'Procesando archivo...' : isDragging ? '¡Suelta el archivo aquí!' : 'Arrastra tu CSV aquí'}
            </p>
            <p className="text-sm text-slate-400 mt-1">o haz clic para seleccionar • Formatos: CSV, TXT</p>
          </div>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-4 flex gap-3">
          <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <p className="text-sm text-red-300">{error}</p>
        </div>
      )}

      {/* Info si hay datos cargados */}
      {currentData && (
        <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/30 p-5 space-y-3">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-300 font-semibold">Datos cargados exitosamente</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Registros', value: currentData.totalRecords.toLocaleString() },
              { label: 'Dígitos', value: currentData.digitCount },
              { label: 'Desde', value: currentData.dateRange.min.toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }) },
              { label: 'Hasta', value: currentData.dateRange.max.toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' }) },
            ].map((item) => (
              <div key={item.label} className="text-center">
                <p className="text-2xl font-bold font-mono text-white">{item.value}</p>
                <p className="text-xs text-slate-400 mt-0.5">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Formato esperado */}
      <div className="rounded-xl bg-slate-800/40 border border-slate-700/30 p-5 space-y-3">
        <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
          <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          Formatos de CSV soportados
        </h3>
        <div className="grid md:grid-cols-3 gap-3">
          {[
            { format: 'DD/MM/YYYY', example: '15/06/2023, 723' },
            { format: 'YYYY-MM-DD', example: '2023-06-15, 4521' },
            { format: 'DD-Mon-YYYY', example: '15-Jun-2023, 0891' },
          ].map((f) => (
            <div key={f.format} className="bg-slate-900/50 rounded-lg p-3">
              <p className="text-xs font-mono text-blue-300 mb-1">{f.format}</p>
              <p className="text-xs text-slate-500">{f.example}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500">
          La app auto-detecta columnas de fecha y resultado. Compatible con 3-6 dígitos.
        </p>
      </div>
    </div>
  );
};
