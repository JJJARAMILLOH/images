// ============================================================
// LOTOPRO 2026 — APP PRINCIPAL
// Análisis Predictivo Avanzado de Lotería
// 18 Modelos Estadísticos + Referencia Cruzada Multi-Método
// ============================================================

import { useState, useCallback, useMemo } from 'react';
import type { ParsedCSV, AnalysisResult, TabId } from './types';
import { runAllModels } from './utils/models';
import { crossReference } from './utils/crossReference';
import { buildGlobalStatistics } from './utils/statistics';
import { UploadSection } from './components/UploadSection';
import { DateAnalysis } from './components/DateAnalysis';
import { PredictionsPanel } from './components/PredictionsPanel';
import { CrossReferencePanel } from './components/CrossReferencePanel';
import { StatisticsPanel } from './components/StatisticsPanel';
import { ChartsPanel } from './components/ChartsPanel';

// ─── Tabs config ─────────────────────────────────────────────
const TABS: Array<{ id: TabId; label: string; icon: string; requiresData: boolean; requiresAnalysis: boolean }> = [
  { id: 'upload', label: 'Datos', icon: '📂', requiresData: false, requiresAnalysis: false },
  { id: 'date-analysis', label: 'Análisis Fecha', icon: '📅', requiresData: true, requiresAnalysis: true },
  { id: 'predictions', label: '18 Modelos', icon: '🤖', requiresData: true, requiresAnalysis: true },
  { id: 'cross-reference', label: 'Predicción Final', icon: '🎯', requiresData: true, requiresAnalysis: true },
  { id: 'charts', label: 'Gráficos', icon: '📊', requiresData: true, requiresAnalysis: true },
  { id: 'statistics', label: 'Estadísticas', icon: '📈', requiresData: true, requiresAnalysis: true },
];

const MONTHS_ES = [
  { v: 1, l: 'Enero' }, { v: 2, l: 'Febrero' }, { v: 3, l: 'Marzo' },
  { v: 4, l: 'Abril' }, { v: 5, l: 'Mayo' }, { v: 6, l: 'Junio' },
  { v: 7, l: 'Julio' }, { v: 8, l: 'Agosto' }, { v: 9, l: 'Septiembre' },
  { v: 10, l: 'Octubre' }, { v: 11, l: 'Noviembre' }, { v: 12, l: 'Diciembre' },
];

export default function App() {
  const [csvData, setCsvData] = useState<ParsedCSV | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>('upload');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);
  const [selectedDay, setSelectedDay] = useState<number>(new Date().getDate());
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Days available for selected month
  const daysInMonth = useMemo(() => {
    const d = new Date(2024, selectedMonth, 0).getDate();
    return Array.from({ length: d }, (_, i) => i + 1);
  }, [selectedMonth]);

  const handleDataLoaded = useCallback((data: ParsedCSV) => {
    setCsvData(data);
    setAnalysisResult(null);
    setGlobalError(null);
    setActiveTab('upload');
  }, []);

  const runAnalysis = useCallback(() => {
    if (!csvData) return;
    setIsAnalyzing(true);
    setGlobalError(null);

    // Defer to next tick to allow UI to update
    setTimeout(() => {
      try {
        const allRecords = csvData.records;
        const digitCount = csvData.digitCount;
        const month = selectedMonth;
        const day = selectedDay;
        const dateKey = `${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;

        // Filtrar registros de EXACTAMENTE esa fecha (misma fecha, todos los años)
        const historicalMatches = allRecords.filter((r) => r.monthDay === dateKey);

        // Modelos
        const models = runAllModels(allRecords, historicalMatches, digitCount, month, day);

        // Referencia cruzada
        const crossRef = crossReference(models, allRecords, historicalMatches, digitCount);

        // Estadísticas globales
        const statistics = buildGlobalStatistics(allRecords, historicalMatches, digitCount);

        const result: AnalysisResult = {
          targetDate: { month, day },
          dateKey,
          historicalMatches,
          allRecords,
          models,
          crossReference: crossRef,
          statistics,
          digitCount,
        };

        setAnalysisResult(result);
        setActiveTab('cross-reference');
      } catch (err) {
        setGlobalError(`Error en el análisis: ${err instanceof Error ? err.message : String(err)}`);
      } finally {
        setIsAnalyzing(false);
      }
    }, 50);
  }, [csvData, selectedMonth, selectedDay]);

  return (
    <div className="min-h-screen bg-slate-950 text-white" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      {/* ─── HEADER ──────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white font-black text-lg shadow-lg shadow-blue-500/30">
                🎯
              </div>
              <div>
                <h1 className="text-base font-bold text-white leading-none">LotoPro 2026</h1>
                <p className="text-xs text-slate-400">Análisis Predictivo Avanzado</p>
              </div>
            </div>

            {/* Status */}
            {csvData && (
              <div className="hidden md:flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-300">{csvData.totalRecords.toLocaleString()} registros</span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/15 border border-blue-500/20">
                  <span className="text-blue-300">{csvData.digitCount} dígitos</span>
                </div>
                {analysisResult && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/20">
                    <span className="text-purple-300">18 modelos activos</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* ─── HERO GRADIENT BG ────────────────────────────────── */}
      <div className="relative">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -left-40 w-80 h-80 bg-blue-700/8 rounded-full blur-3xl" />
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-700/8 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-8">
          {/* ─── DATE SELECTOR + ANALYZE ──────────────────── */}
          {csvData && (
            <div className="mb-8 rounded-2xl bg-slate-900/80 border border-slate-700/50 p-6">
              <div className="flex flex-col md:flex-row md:items-end gap-5">
                <div>
                  <h2 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                    <span className="text-blue-400">📅</span>
                    Selecciona la fecha a analizar
                  </h2>
                  <div className="flex gap-3">
                    <div>
                      <label className="text-xs text-slate-500 block mb-1.5">Mes</label>
                      <select
                        value={selectedMonth}
                        onChange={(e) => {
                          setSelectedMonth(+e.target.value);
                          setSelectedDay(Math.min(selectedDay, new Date(2024, +e.target.value, 0).getDate()));
                        }}
                        className="bg-slate-800 border border-slate-600/60 text-white rounded-xl px-4 py-2.5 text-sm outline-none focus:border-blue-500/60 transition-colors"
                      >
                        {MONTHS_ES.map((m) => (
                          <option key={m.v} value={m.v}>{m.l}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-slate-500 block mb-1.5">Día</label>
                      <select
                        value={selectedDay}
                        onChange={(e) => setSelectedDay(+e.target.value)}
                        className="bg-slate-800 border border-slate-600/60 text-white rounded-xl px-4 py-2.5 text-sm outline-none focus:border-blue-500/60 transition-colors"
                      >
                        {daysInMonth.map((d) => (
                          <option key={d} value={d}>{String(d).padStart(2, '0')}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">
                    La app mostrará resultados históricos del <strong className="text-slate-300">{String(selectedDay).padStart(2,'0')}/{String(selectedMonth).padStart(2,'0')}</strong> de todos los años en el historial
                  </p>
                </div>

                <button
                  onClick={runAnalysis}
                  disabled={isAnalyzing}
                  className={`flex items-center gap-3 px-8 py-3 rounded-xl font-bold text-sm transition-all duration-200 ${
                    isAnalyzing
                      ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 hover:-translate-y-0.5'
                  }`}
                >
                  {isAnalyzing ? (
                    <>
                      <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                      </svg>
                      Analizando 18 modelos...
                    </>
                  ) : (
                    <>
                      <span>🚀</span>
                      Ejecutar Análisis Completo
                    </>
                  )}
                </button>

                {analysisResult && (
                  <div className="md:ml-auto flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/25">
                    <span className="text-emerald-400">✓</span>
                    <div>
                      <div className="text-sm font-bold text-emerald-300">
                        Predicción: <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{analysisResult.crossReference.finalPrediction}</span>
                      </div>
                      <div className="text-xs text-emerald-600">Confianza: {analysisResult.crossReference.overallConfidence}%</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ─── GLOBAL ERROR ──────────────────────────────── */}
          {globalError && (
            <div className="mb-6 rounded-xl bg-red-500/10 border border-red-500/30 p-4 flex gap-3">
              <svg className="w-5 h-5 text-red-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <p className="text-sm text-red-300">{globalError}</p>
            </div>
          )}

          {/* ─── TABS ──────────────────────────────────────── */}
          <div className="flex gap-1 mb-6 bg-slate-900/60 rounded-xl p-1 border border-slate-800/50 overflow-x-auto">
            {TABS.map((tab) => {
              const isDisabled = (tab.requiresData && !csvData) || (tab.requiresAnalysis && !analysisResult);
              return (
                <button
                  key={tab.id}
                  onClick={() => !isDisabled && setActiveTab(tab.id)}
                  disabled={isDisabled}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200 flex-shrink-0 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md shadow-blue-900/50'
                      : isDisabled
                      ? 'text-slate-600 cursor-not-allowed'
                      : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {tab.id === 'cross-reference' && analysisResult && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  )}
                </button>
              );
            })}
          </div>

          {/* ─── TAB CONTENT ────────────────────────────────── */}
          <div className="pb-12">
            {activeTab === 'upload' && (
              <UploadSection onDataLoaded={handleDataLoaded} currentData={csvData} />
            )}

            {activeTab === 'date-analysis' && analysisResult && (
              <DateAnalysis result={analysisResult} />
            )}

            {activeTab === 'predictions' && analysisResult && (
              <PredictionsPanel
                predictions={analysisResult.models}
                digitCount={analysisResult.digitCount}
              />
            )}

            {activeTab === 'cross-reference' && analysisResult && (
              <CrossReferencePanel
                result={analysisResult.crossReference}
                digitCount={analysisResult.digitCount}
              />
            )}

            {activeTab === 'charts' && analysisResult && (
              <ChartsPanel result={analysisResult} />
            )}

            {activeTab === 'statistics' && analysisResult && (
              <StatisticsPanel result={analysisResult} />
            )}

            {/* Estado vacío */}
            {!csvData && activeTab !== 'upload' && (
              <EmptyState onGoToUpload={() => setActiveTab('upload')} />
            )}
            {csvData && !analysisResult && activeTab !== 'upload' && (
              <AnalysisNeededState onAnalyze={runAnalysis} isAnalyzing={isAnalyzing} />
            )}
          </div>
        </div>
      </div>

      {/* ─── FOOTER ──────────────────────────────────────────── */}
      <footer className="border-t border-slate-800/50 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-xs text-slate-600">
            LotoPro 2026 • 18 modelos estadísticos + referencia cruzada multi-método
          </p>
          <p className="text-xs text-slate-600">
            ⚠️ Solo para análisis educativo — los resultados no garantizan aciertos
          </p>
        </div>
      </footer>
    </div>
  );
}

// ─── Componentes auxiliares ──────────────────────────────────

function EmptyState({ onGoToUpload }: { onGoToUpload: () => void }) {
  return (
    <div className="text-center py-20">
      <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-slate-800 flex items-center justify-center text-4xl">
        📂
      </div>
      <h3 className="text-xl font-semibold text-slate-300 mb-2">No hay datos cargados</h3>
      <p className="text-slate-500 mb-6">Primero sube tu archivo CSV con el historial de sorteos</p>
      <button
        onClick={onGoToUpload}
        className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm transition-colors"
      >
        Ir a Cargar Datos
      </button>
    </div>
  );
}

function AnalysisNeededState({ onAnalyze, isAnalyzing }: { onAnalyze: () => void; isAnalyzing: boolean }) {
  return (
    <div className="text-center py-20">
      <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-blue-600/20 to-purple-600/20 border border-blue-500/20 flex items-center justify-center text-4xl">
        🚀
      </div>
      <h3 className="text-xl font-semibold text-slate-300 mb-2">Listo para analizar</h3>
      <p className="text-slate-500 mb-6">Selecciona una fecha y ejecuta el análisis completo con los 18 modelos</p>
      <button
        onClick={onAnalyze}
        disabled={isAnalyzing}
        className="px-8 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-sm transition-all shadow-lg"
      >
        {isAnalyzing ? '⏳ Analizando...' : '🚀 Ejecutar Análisis'}
      </button>
    </div>
  );
}
