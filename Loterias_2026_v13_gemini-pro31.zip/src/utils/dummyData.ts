export interface LotteryRecord {
  date: string; // YYYY-MM-DD
  result: string; // 4 digits
}

export const generateDummyData = (): LotteryRecord[] => {
  const records: LotteryRecord[] = [];
  const startDate = new Date(2000, 0, 1);
  const endDate = new Date(2025, 11, 31);
  
  // Generate around 7000 records
  let currentDate = startDate;
  while (currentDate <= endDate) {
    // skip some days randomly to make it realistic
    if (Math.random() > 0.2) {
      const year = currentDate.getFullYear();
      const month = String(currentDate.getMonth() + 1).padStart(2, '0');
      const day = String(currentDate.getDate()).padStart(2, '0');
      
      // specific overrides for the screenshot matching
      let result = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
      
      if (month === '06' && day === '07') {
        if (year === 2025) result = '5445';
        if (year === 2024) result = '9450';
        if (year === 2023) result = '4254';
        if (year === 2022) result = '2762';
        if (year === 2021) result = '4474';
        if (year === 2020) result = '9414';
        if (year === 2019) result = '9715';
        if (year === 2018) result = '1912';
      }

      records.push({
        date: `${year}-${month}-${day}`,
        result
      });
    }
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  return records.reverse(); // Newest first
};
