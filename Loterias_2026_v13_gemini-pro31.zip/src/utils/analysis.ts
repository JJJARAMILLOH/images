import { LotteryRecord } from './dummyData';

export const getFrequencies = (data: LotteryRecord[]) => {
  const counts: Record<string, number> = {};
  data.forEach(record => {
    counts[record.result] = (counts[record.result] || 0) + 1;
  });
  
  return Object.entries(counts)
    .map(([numero, apariciones]) => ({ numero, apariciones }))
    .sort((a, b) => b.apariciones - a.apariciones)
    .slice(0, 100);
};

export const calculateTrendLine = (data: number[]) => {
  if (data.length === 0) return [];
  const n = data.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += data[i];
    sumXY += i * data[i];
    sumX2 += i * i;
  }
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return data.map((_, i) => slope * i + intercept);
};

export const getDayOfWeekStr = (dateStr: string) => {
  // Correctly parse date without timezone shift
  const [year, month, day] = dateStr.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  const days = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  return days[date.getDay()];
};

export const AI_MODELS = [
  "Red Neuronal LSTM", "XGBoost Regressor", "Random Forest", "Support Vector Machine (SVM)",
  "Markov Chain", "ARIMA Temporal", "Transformer Model", "Deep Belief Network",
  "K-Nearest Neighbors", "Gradient Boosting", "Naive Bayes", "Elastic Net",
  "Decision Tree", "Linear Regression", "AdaBoost", "Gaussian Process",
  "Ridge Regression", "Lasso Regression"
];

// Helper to generate a consistent pseudo-random prediction based on some seed
export const generateAIPredictions = (seed: string) => {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  return AI_MODELS.map((model, index) => {
    const modelHash = hash * (index + 1);
    const prediction = Math.abs(modelHash % 10000).toString().padStart(4, '0');
    // Probability between 45% and 95%
    const probability = 45 + Math.abs((modelHash * 13) % 50) + Math.random() * 5;
    return {
      model,
      prediction,
      probability: parseFloat(probability.toFixed(2))
    };
  }).sort((a, b) => b.probability - a.probability);
};
