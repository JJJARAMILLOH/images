import fs from 'fs';
import unzipper from 'unzipper';
import axios from 'axios';
import { pipeline } from 'stream/promises';

async function downloadAndExtract() {
  const url = 'https://github.com/JJJARAMILLOH/images/raw/main/Loto_Analytics_Pro.zip';
  console.log(`Downloading ${url}...`);

  try {
    const response = await axios({
      method: 'GET',
      url: url,
      responseType: 'stream'
    });

    console.log('Extracting to current directory...');
    await pipeline(
      response.data,
      unzipper.Extract({ path: '.' })
    );
    console.log('Extraction complete!');
  } catch (error) {
    console.error('Error:', error.message);
  }
}

downloadAndExtract();