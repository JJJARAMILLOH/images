import https from 'https';
import fs from 'fs';
import path from 'path';
import AdmZip from 'adm-zip';

const url = 'https://raw.githubusercontent.com/JJJARAMILLOH/images/main/Loterias_2026_v19_gemini-pro31.zip';
const zipPath = path.join(process.cwd(), 'repo.zip');

const file = fs.createWriteStream(zipPath);

https.get(url, (response) => {
  response.pipe(file);
  file.on('finish', () => {
    file.close();
    console.log('Downloaded zip file.');
    
    try {
      const zip = new AdmZip(zipPath);
      zip.extractAllTo(process.cwd(), true);
      console.log('Unzipped successfully.');
    } catch (err) {
      console.error('Error unzipping:', err.message);
    }
  });
}).on('error', (err) => {
  console.error('Download error:', err.message);
});
