import https from 'https';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const url = 'https://raw.githubusercontent.com/JJJARAMILLOH/images/main/Loterias_2026_v17_gemini-pro31.zip';
const zipPath = path.join(process.cwd(), 'repo.zip');

const file = fs.createWriteStream(zipPath);

https.get(url, (response) => {
  response.pipe(file);
  file.on('finish', () => {
    file.close();
    console.log('Downloaded zip file.');
    
    // Unzip the file
    try {
      execSync(`unzip -o repo.zip -d extracted`, { stdio: 'inherit' });
      console.log('Unzipped successfully.');
      
      // List contents
      const files = execSync('find extracted -type f').toString();
      console.log('Files:', files);
      
    } catch (err) {
      console.error('Error unzipping:', err.message);
    }
  });
}).on('error', (err) => {
  console.error('Download error:', err.message);
});
