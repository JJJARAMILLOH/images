import React, { useState, useMemo } from 'react';
import { Upload, ChevronDown, Award, Sparkles, Brain, BarChart3, Clock, Calendar, Hash } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { parseCsvFile, LotteryResult, getTrendLineAndPrediction, dayOfWeekMap, generateMockPredictions, padTo4 } from './utils';
import { parse, isValid, format } from 'date-fns';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Generate some initial mock data if no file is uploaded
const MOCK_DATA = Array.from({ length: 1500 }).map((_, i) => {
    const d = new Date(2023, 0, 1);
    d.setDate(d.getDate() + i);
    // Add some pseudo-random but somewhat realistic looking results
    let rand = Math.floor(Math.abs(Math.sin(i * 0.1) * 5000 + Math.cos(i * 0.3) * 5000));
    
    // Ensure we have some data for '534'
    if (i % 20 === 0) rand = Math.floor(Math.random() * 10) * 1000 + 534;

    return {
        date: format(d, 'yyyy-MM-dd'),
        result: padTo4(rand % 10000)
    };
});

// Custom Tooltip for charts
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 border border-slate-700 p-3 rounded-lg shadow-xl">
        <p className="text-slate-300 text-sm mb-1">{label}</p>
        <p className="text-white font-mono font-bold">
          Resultado : {payload[0].value}
        </p>
        {payload[1] && (
            <p className="text-pink-400 font-mono text-xs mt-1">
              Tendencia : {payload[1].value.toFixed(2)}
            </p>
        )}
      </div>
    );
  }
  return null;
};

export default function App() {
  const [data, setData] = useState<LotteryResult[]>(MOCK_DATA);
  const [isDragging, setIsDragging] = useState(false);
  
  // Filters
  const [terminationFilter, setTerminationFilter] = useState('534');
  const [dateFilter, setDateFilter] = useState('06-10'); // Default as in screenshot
  const [dayFilter, setDayFilter] = useState('Miércoles'); // Default as in screenshot

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      parseCsvFile(file, (parsed) => {
        setData(parsed);
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      parseCsvFile(file, (parsed) => {
        setData(parsed);
      });
    }
  };

  // 1. Top Histórico
  const topHistorico = useMemo(() => {
    const counts: Record<string, number> = {};
    data.forEach(item => {
        counts[item.result] = (counts[item.result] || 0) + 1;
    });
    return Object.entries(counts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([numero, apariciones]) => ({ numero, apariciones }));
  }, [data]);

  // 2. Últimos 100 Resultados
  const ultimos100 = useMemo(() => {
    const last100 = data.slice(-100);
    const numericData = last100.map(d => parseInt(d.result, 10));
    const { trendLine, prediction } = getTrendLineAndPrediction(numericData);
    
    return {
        chartData: last100.map((d, i) => ({
            name: d.date,
            value: parseInt(d.result, 10),
            trend: trendLine[i]
        })),
        prediction: Math.round(prediction)
    };
  }, [data]);

  // 3. Eventos para Fecha Exacta (MM-DD)
  const eventosFecha = useMemo(() => {
    if (!dateFilter || dateFilter.length < 5) return { table: [], chartData: [], prediction: 0 };
    
    const filtered = data.filter(d => d.date.includes(dateFilter));
    const numericData = filtered.map(d => parseInt(d.result, 10));
    const { trendLine, prediction } = getTrendLineAndPrediction(numericData);
    
    return {
        table: filtered.slice(-5).reverse(), // Last 5 for table
        chartData: filtered.map((d, i) => ({
            name: d.date,
            value: parseInt(d.result, 10),
            trend: trendLine[i]
        })),
        prediction: Math.round(prediction)
    };
  }, [data, dateFilter]);

  // 4. Resultados para Día de la Semana
  const eventosDia = useMemo(() => {
    if (!dayFilter) return { table: [], chartData: [], prediction: 0 };
    
    const targetDay = dayOfWeekMap[dayFilter];
    const filtered = data.filter(d => {
        const parsedDate = parse(d.date, 'yyyy-MM-dd', new Date());
        return isValid(parsedDate) && parsedDate.getDay() === targetDay;
    });
    
    const last100 = filtered.slice(-100);
    const numericData = last100.map(d => parseInt(d.result, 10));
    const { trendLine, prediction } = getTrendLineAndPrediction(numericData);

    return {
        table: filtered.slice(-5).reverse(),
        chartData: last100.map((d, i) => ({
            name: d.date,
            value: parseInt(d.result, 10),
            trend: trendLine[i]
        })),
        prediction: Math.round(prediction)
    };
  }, [data, dayFilter]);

  // 5. Eventos para Terminación (3 Cifras) - FIX APPLIED HERE
  const eventosTerminacion = useMemo(() => {
    if (!terminationFilter || terminationFilter.length !== 3) return { table: [], chartData: [], prediction: 0, hasData: false };
    
    const filtered = data.filter(d => d.result.endsWith(terminationFilter));
    const numericData = filtered.map(d => parseInt(d.result, 10));
    const { trendLine, prediction } = getTrendLineAndPrediction(numericData);
    
    return {
        hasData: true,
        table: filtered.slice(-5).reverse(),
        chartData: filtered.map((d, i) => ({
            name: d.date,
            value: parseInt(d.result, 10),
            trend: trendLine[i]
        })),
        prediction: Math.round(prediction)
    };
  }, [data, terminationFilter]);

  // AI Models
  const aiPredictions = useMemo(() => {
     return generateMockPredictions(data.length > 0 ? data[data.length-1].result : '1234');
  }, [data]);

  return (
    <div className="flex h-screen bg-[#060B14] text-slate-300 font-sans overflow-hidden">
      
      {/* SIDEBAR */}
      <aside className="w-72 bg-[#0B1221] border-r border-slate-800 flex flex-col h-full z-10 shadow-2xl flex-shrink-0">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2 text-pink-500 font-bold text-xl tracking-wider">
            <Sparkles className="w-5 h-5" />
            LOTTOPRO
          </div>
          <p className="text-xs text-slate-500 mt-2 leading-tight">Motor Avanzado de Predicción y Análisis</p>
        </div>

        <div className="p-6 flex-1 overflow-y-auto">
          <div className="mb-8">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Datos Históricos (CSV)</h3>
            <label 
                className={cn(
                    "flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-xl cursor-pointer transition-all",
                    isDragging ? "border-pink-500 bg-pink-500/10" : "border-slate-700 bg-slate-800/30 hover:bg-slate-800/50 hover:border-slate-600"
                )}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
            >
              <Upload className="w-6 h-6 text-slate-400 mb-2" />
              <span className="text-xs font-medium text-slate-300">Subir archivo CSV</span>
              <input type="file" className="hidden" accept=".csv" onChange={handleFileUpload} />
            </label>
            <p className="text-xs text-emerald-400 mt-3 font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              {data.length} registros cargados
            </p>
          </div>

          <div>
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Filtros de Análisis</h3>
            
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 flex items-center gap-1.5">
                    <Hash className="w-3.5 h-3.5" />
                    Terminación (3 Cifras)
                </label>
                <input 
                    type="text" 
                    maxLength={3}
                    placeholder="Ej. 123"
                    value={terminationFilter}
                    onChange={(e) => setTerminationFilter(e.target.value.replace(/\D/g, ''))}
                    className="w-full bg-[#131C2F] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-pink-500 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    Fecha Exacta (MM-DD)
                </label>
                <input 
                    type="text" 
                    placeholder="Ej. 06-10"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="w-full bg-[#131C2F] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-pink-500 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-slate-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    Día de la Semana
                </label>
                <div className="relative">
                  <select 
                      value={dayFilter}
                      onChange={(e) => setDayFilter(e.target.value)}
                      className="w-full bg-[#131C2F] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-pink-500 appearance-none transition-colors"
                  >
                    {Object.keys(dayOfWeekMap).map(day => (
                        <option key={day} value={day}>{day}</option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 overflow-y-auto p-6 md:p-8">
        <div className="max-w-7xl mx-auto space-y-6">
          
          {/* ROW 1: Top Histórico & Últimos 100 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1" title="Top Histórico (Frecuencia)" icon={<BarChart3 className="w-4 h-4" />}>
               <table className="w-full text-sm mt-2">
                 <thead>
                   <tr className="text-left text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-800">
                     <th className="pb-3 font-semibold">Número</th>
                     <th className="pb-3 font-semibold text-right">Apariciones</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-800/50">
                   {topHistorico.map((row, i) => (
                     <tr key={i} className="group hover:bg-slate-800/30 transition-colors">
                       <td className="py-3 font-mono text-white font-medium flex items-center gap-2">
                         <span className="text-slate-500 text-xs w-3">{i+1}</span>
                         {row.numero}
                       </td>
                       <td className="py-3 text-right text-slate-400">{row.apariciones}</td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </Card>

            <Card className="lg:col-span-2" title="Últimos 100 Resultados y Tendencia" icon={<BarChart3 className="w-4 h-4" />}
                action={<Badge>Tendencia Sugerida: {ultimos100.prediction}</Badge>}
            >
              <div className="h-64 mt-4 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={ultimos100.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="name" stroke="#475569" fontSize={10} tickMargin={10} minTickGap={30} />
                    <YAxis stroke="#475569" fontSize={10} domain={['dataMin - 1000', 'dataMax + 1000']} tickFormatter={(v) => padTo4(v)} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="value" stroke="#06B6D4" strokeWidth={1.5} dot={{ r: 2, fill: '#06B6D4', strokeWidth: 0 }} activeDot={{ r: 4, fill: '#fff' }} label={{ position: 'top', fill: '#cbd5e1', fontSize: 10 }} />
                    <Line type="linear" dataKey="trend" stroke="#F43F5E" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          {/* ROW 2: Eventos MM-DD */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1" title={`Eventos para ${dateFilter}`} icon={<Calendar className="w-4 h-4" />}>
               <table className="w-full text-sm mt-2">
                 <thead>
                   <tr className="text-left text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-800">
                     <th className="pb-3 font-semibold">Fecha</th>
                     <th className="pb-3 font-semibold text-right">Resultado</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-800/50">
                   {eventosFecha.table.map((row, i) => (
                     <tr key={i} className="group hover:bg-slate-800/30 transition-colors">
                       <td className="py-3 text-slate-400 text-xs">{row.date}</td>
                       <td className="py-3 text-right font-mono text-pink-500 font-bold">{row.result}</td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </Card>

            <Card className="lg:col-span-2" title={`Evolución y Tendencia para ${dateFilter}`} icon={<BarChart3 className="w-4 h-4" />}
                action={<Badge color="pink">Predicción Tendencia: {eventosFecha.prediction}</Badge>}
            >
              <div className="h-64 mt-4 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={eventosFecha.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="name" stroke="#475569" fontSize={10} tickMargin={10} />
                    <YAxis stroke="#475569" fontSize={10} domain={['auto', 'auto']} tickFormatter={(v) => padTo4(v)} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4, fill: '#1E1B4B', stroke: '#3B82F6', strokeWidth: 2 }} activeDot={{ r: 6 }} label={{ position: 'top', fill: '#cbd5e1', fontSize: 10 }} />
                    <Line type="linear" dataKey="trend" stroke="#F43F5E" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>

          {/* ROW 3: Eventos Día */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1" title={`Resultados para ${dayFilter}`} icon={<Calendar className="w-4 h-4" />}>
               <table className="w-full text-sm mt-2">
                 <thead>
                   <tr className="text-left text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-800">
                     <th className="pb-3 font-semibold">Fecha</th>
                     <th className="pb-3 font-semibold text-right">Resultado</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-800/50">
                   {eventosDia.table.map((row, i) => (
                     <tr key={i} className="group hover:bg-slate-800/30 transition-colors">
                       <td className="py-3 text-slate-400 text-xs">{row.date}</td>
                       <td className="py-3 text-right font-mono text-emerald-400 font-bold">{row.result}</td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </Card>

            <Card className="lg:col-span-2" title={`Últimos 100 ${dayFilter} y Tendencia`} icon={<BarChart3 className="w-4 h-4" />}
                action={<Badge color="emerald">Sug. Día: {eventosDia.prediction}</Badge>}
            >
              <div className="h-64 mt-4 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={eventosDia.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                    <XAxis dataKey="name" stroke="#475569" fontSize={10} tickMargin={10} minTickGap={30} />
                    <YAxis stroke="#475569" fontSize={10} domain={['dataMin - 1000', 'dataMax + 1000']} tickFormatter={(v) => padTo4(v)} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="value" stroke="#10B981" strokeWidth={1.5} dot={{ r: 2, fill: '#10B981', strokeWidth: 0 }} activeDot={{ r: 4, fill: '#fff' }} label={{ position: 'top', fill: '#cbd5e1', fontSize: 10 }} />
                    <Line type="linear" dataKey="trend" stroke="#F43F5E" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>
          
          {/* ROW FIX: Eventos Terminación - Only show if input is valid (3 digits) */}
          {eventosTerminacion.hasData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <Card className="lg:col-span-1" title={`Eventos Terminación: ${terminationFilter}`} icon={<Hash className="w-4 h-4" />}>
                   <table className="w-full text-sm mt-2">
                     <thead>
                       <tr className="text-left text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-800">
                         <th className="pb-3 font-semibold">Fecha</th>
                         <th className="pb-3 font-semibold text-right">Resultado</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-800/50">
                       {eventosTerminacion.table.length > 0 ? eventosTerminacion.table.map((row, i) => (
                         <tr key={i} className="group hover:bg-slate-800/30 transition-colors">
                           <td className="py-3 text-slate-400 text-xs">{row.date}</td>
                           <td className="py-3 text-right font-mono text-amber-400 font-bold">{row.result}</td>
                         </tr>
                       )) : (
                           <tr><td colSpan={2} className="py-8 text-center text-slate-500 text-xs">No hay resultados que terminen en {terminationFilter}</td></tr>
                       )}
                     </tbody>
                   </table>
                </Card>
    
                <Card className="lg:col-span-2" title={`Evolución y Tendencia Terminación ${terminationFilter}`} icon={<BarChart3 className="w-4 h-4" />}
                    action={<Badge color="amber">Sug. Terminación: {eventosTerminacion.prediction}</Badge>}
                >
                  <div className="h-64 mt-4 w-full">
                    {eventosTerminacion.chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={eventosTerminacion.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                            <XAxis dataKey="name" stroke="#475569" fontSize={10} tickMargin={10} minTickGap={30} />
                            <YAxis stroke="#475569" fontSize={10} domain={['dataMin - 1000', 'dataMax + 1000']} tickFormatter={(v) => padTo4(v)} />
                            <Tooltip content={<CustomTooltip />} />
                            <Line type="monotone" dataKey="value" stroke="#F59E0B" strokeWidth={1.5} dot={{ r: 3, fill: '#1E1B4B', stroke: '#F59E0B', strokeWidth: 1.5 }} activeDot={{ r: 5 }} label={{ position: 'top', fill: '#cbd5e1', fontSize: 10 }} />
                            <Line type="linear" dataKey="trend" stroke="#F43F5E" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
                          </LineChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full flex items-center justify-center text-slate-600">Insuficientes datos</div>
                    )}
                  </div>
                </Card>
              </div>
          )}

          {/* AI MODELS SECTION */}
          <div className="pt-6">
             <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                    <Brain className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                    <h2 className="text-lg font-bold text-white">Análisis con Modelos de IA Avanzados</h2>
                    <p className="text-xs text-slate-400">Evaluación algorítmica de probabilidades y predicción predictiva.</p>
                </div>
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2" title="Rendimiento y Predicciones por Modelo" icon={<Award className="w-4 h-4" />}>
                   <table className="w-full text-sm mt-4">
                     <thead>
                       <tr className="text-left text-[10px] text-slate-500 uppercase tracking-wider border-b border-slate-800">
                         <th className="pb-3 font-semibold">Modelo IA</th>
                         <th className="pb-3 font-semibold text-center">Predicción</th>
                         <th className="pb-3 font-semibold text-right">Confianza</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-800/50">
                       {aiPredictions.map((row, i) => (
                         <tr key={i} className="group hover:bg-slate-800/30 transition-colors">
                           <td className="py-3.5 text-slate-200 font-medium text-xs">{row.model}</td>
                           <td className="py-3.5 text-center">
                               <span className="bg-[#1A2235] border border-slate-700 px-3 py-1 rounded text-indigo-300 font-mono text-xs shadow-sm">
                                   {row.prediction}
                               </span>
                           </td>
                           <td className="py-3.5 text-right flex items-center justify-end gap-3">
                               <span className="text-emerald-400 font-mono text-xs font-semibold">{row.conf}</span>
                               <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                   <div className="h-full bg-emerald-500" style={{ width: row.conf }}></div>
                               </div>
                           </td>
                         </tr>
                       ))}
                     </tbody>
                   </table>
                </Card>
                
                <Card className="lg:col-span-1 border-indigo-500/30 bg-gradient-to-b from-[#0F172A] to-[#0A0F1A]" title="" headerless>
                    <div className="flex flex-col items-center justify-center p-4">
                        <div className="w-12 h-12 bg-amber-500/10 rounded-full flex items-center justify-center mb-3">
                           <Award className="w-6 h-6 text-amber-400" />
                        </div>
                        <h3 className="text-base font-bold text-white">Sistema Profesional</h3>
                        <p className="text-[10px] text-slate-400 uppercase tracking-widest mt-1">Multi-Confluencia Top 3</p>
                        
                        <div className="w-full mt-8 space-y-4">
                            <div className="bg-[#131C2F] border border-slate-700/50 p-4 rounded-xl relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/5 rounded-bl-full -z-10 group-hover:bg-amber-500/10 transition-colors"></div>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                                            <span className="text-xs font-bold text-amber-400"># ORO</span>
                                        </div>
                                        <div className="text-3xl font-mono font-bold text-white">{aiPredictions[0].prediction}</div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-amber-400 font-mono font-bold text-lg">{aiPredictions[0].conf}</div>
                                        <div className="text-[10px] text-slate-500">Probabilidad</div>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-[#131C2F] border border-slate-700/50 p-4 rounded-xl relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-slate-400/5 rounded-bl-full -z-10 group-hover:bg-slate-400/10 transition-colors"></div>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="flex items-center gap-1.5 mb-1">
                                            <span className="w-2 h-2 rounded-full bg-slate-300"></span>
                                            <span className="text-xs font-bold text-slate-300"># PLATA</span>
                                        </div>
                                        <div className="text-3xl font-mono font-bold text-white">{aiPredictions[1].prediction}</div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-slate-300 font-mono font-bold text-lg">{aiPredictions[1].conf}</div>
                                        <div className="text-[10px] text-slate-500">Probabilidad</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
             </div>
          </div>
          
          <div className="h-8"></div> {/* Bottom padding */}
        </div>
      </main>
    </div>
  );
}

// UI Components

function Card({ 
    title, 
    children, 
    className, 
    icon, 
    action,
    headerless = false
}: { 
    title?: string, 
    children: React.ReactNode, 
    className?: string, 
    icon?: React.ReactNode,
    action?: React.ReactNode,
    headerless?: boolean
}) {
  return (
    <div className={cn("bg-[#0F172A] border border-slate-800 rounded-xl overflow-hidden shadow-lg flex flex-col", className)}>
      {!headerless && (
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-800/20">
            <h2 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                {icon && <span className="text-indigo-400">{icon}</span>}
                {title}
            </h2>
            {action && <div>{action}</div>}
        </div>
      )}
      <div className="p-5 flex-1 flex flex-col">
        {children}
      </div>
    </div>
  );
}

function Badge({ children, color = 'indigo' }: { children: React.ReactNode, color?: 'indigo' | 'pink' | 'emerald' | 'amber' }) {
    const colors = {
        indigo: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
        pink: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
        emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
        amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
    };
    
    return (
        <span className={cn("text-xs px-2.5 py-1 rounded-full border font-mono font-medium flex items-center gap-1.5", colors[color])}>
            <div className={cn("w-1.5 h-1.5 rounded-full", color === 'indigo' ? 'bg-indigo-400' : color === 'pink' ? 'bg-pink-400' : color === 'emerald' ? 'bg-emerald-400' : 'bg-amber-400')}></div>
            {children}
        </span>
    );
}