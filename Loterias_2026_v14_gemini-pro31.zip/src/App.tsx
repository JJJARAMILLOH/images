import React, { useState, useMemo, useEffect } from 'react';
import { Upload, Activity, Calendar, BarChart2, Filter, ChevronDown, Cpu, Award } from 'lucide-react';
import Papa from 'papaparse';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

import { LotteryRecord, generateDummyData } from './utils/dummyData';
import { getFrequencies, calculateTrendLine, getDayOfWeekStr, generateAIPredictions } from './utils/analysis';

const DAYS_OF_WEEK = [
  { value: '', label: 'Todos los días' },
  { value: 'Lunes', label: 'Lunes' },
  { value: 'Martes', label: 'Martes' },
  { value: 'Miércoles', label: 'Miércoles' },
  { value: 'Jueves', label: 'Jueves' },
  { value: 'Viernes', label: 'Viernes' },
  { value: 'Sábado', label: 'Sábado' },
  { value: 'Domingo', label: 'Domingo' }
];

function App() {
  const [data, setData] = useState<LotteryRecord[]>([]);
  const [filterSuffix, setFilterSuffix] = useState('020');
  const [filterDate, setFilterDate] = useState('06-07');
  const [filterDay, setFilterDay] = useState('');
  
  useEffect(() => {
    setData(generateDummyData());
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      complete: (results: Papa.ParseResult<any>) => {
        // Assume CSV has headers or columns Date and Result
        const parsedData = results.data
          .filter((row: any) => row.length >= 2 && row[0] && row[1])
          .map((row: any) => {
            let rawDate = row[0].toString().trim();
            if (/^\d{2}[\/\-]\d{2}[\/\-]\d{4}$/.test(rawDate)) {
              const parts = rawDate.split(/[\/\-]/);
              rawDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
            return {
              date: rawDate,
              result: row[1].toString().trim().padStart(4, '0')
            };
          });
        if (parsedData.length > 0) {
          parsedData.sort((a, b) => b.date.localeCompare(a.date));
          setData(parsedData);
        }
      },
      header: false
    });
  };

  // Process top historical
  const topHist = useMemo(() => getFrequencies(data), [data]);

  // Process last 100 results overall
  const last100 = useMemo(() => {
    const recent = [...data].slice(0, 100).reverse();
    const values = recent.map(r => parseInt(r.result, 10));
    const trend = calculateTrendLine(values);
    return recent.map((r, i) => ({
      date: r.date.substring(5), // MM-DD
      value: values[i],
      trend: trend[i]
    }));
  }, [data]);

  // Specific Date Filter (MM-DD)
  const specificDateEvents = useMemo(() => {
    if (!filterDate) return [];
    const cleanFilter = filterDate.trim();
    return data.filter(r => r.date.includes(cleanFilter)).sort((a, b) => b.date.localeCompare(a.date));
  }, [data, filterDate]);

  const specificDateChartData = useMemo(() => {
    const asc = [...specificDateEvents].reverse();
    const values = asc.map(r => parseInt(r.result, 10));
    const trend = calculateTrendLine(values);
    return asc.map((r, i) => ({
      year: r.date.substring(0, 4),
      value: values[i],
      trend: trend[i]
    }));
  }, [specificDateEvents]);

  // Day of Week Filter
  const dayEvents = useMemo(() => {
    if (!filterDay) return [];
    return data.filter(r => getDayOfWeekStr(r.date) === filterDay).sort((a, b) => b.date.localeCompare(a.date));
  }, [data, filterDay]);

  const dayChartData = useMemo(() => {
    const recent = [...dayEvents].slice(0, 100).reverse();
    const values = recent.map(r => parseInt(r.result, 10));
    const trend = calculateTrendLine(values);
    return recent.map((r, i) => ({
      date: r.date.substring(5),
      value: values[i],
      trend: trend[i]
    }));
  }, [dayEvents]);

  // AI & Multi-Confluence based on filters
  const aiSeed = filterDay ? `day-${filterDay}` : filterDate ? `date-${filterDate}` : 'general';
  const aiPredictions = useMemo(() => generateAIPredictions(aiSeed), [aiSeed]);
  const top3 = aiPredictions.slice(0, 3);

  return (
    <div className="min-h-screen bg-[#0b1121] text-slate-300 font-sans flex flex-col md:flex-row">
      {/* Sidebar */}
      <div className="w-full md:w-72 bg-[#0d1527] border-r border-slate-800 p-6 flex flex-col gap-8 shrink-0">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2 mb-2">
            <Activity className="text-orange-500" />
            LOTTOPRO
          </h1>
          <p className="text-xs text-slate-500">Motor Avanzado de Predicción y Análisis</p>
        </div>

        <div className="space-y-3 border-t border-slate-800 pt-6">
          <h2 className="text-xs font-semibold text-slate-400 tracking-wider">DATOS HISTÓRICOS (CSV)</h2>
          <label className="border-2 border-dashed border-slate-700 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-orange-500/50 transition-colors bg-[#111827]">
            <Upload className="w-6 h-6 text-slate-500 mb-2" />
            <span className="text-sm text-slate-400">Subir archivo CSV</span>
            <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
          </label>
          {data.length > 0 && (
            <div className="text-xs text-emerald-400 flex items-center gap-1">
              <Activity className="w-3 h-3" />
              {data.length} registros cargados
            </div>
          )}
        </div>

        <div className="space-y-4 border-t border-slate-800 pt-6">
          <h2 className="text-xs font-semibold text-slate-400 tracking-wider">FILTROS DE ANÁLISIS</h2>
          
          <div className="space-y-1">
            <label className="text-xs text-slate-500 flex items-center gap-1">
              <span className="text-slate-600">#</span> Terminación (3 Cifras)
            </label>
            <input 
              type="text" 
              value={filterSuffix}
              onChange={(e) => setFilterSuffix(e.target.value)}
              className="w-full bg-[#0b1121] border border-slate-800 rounded px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-orange-500/50"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-500 flex items-center gap-1">
              <Calendar className="w-3 h-3" /> Fecha Exacta (MM-DD)
            </label>
            <input 
              type="text" 
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              placeholder="MM-DD"
              className="w-full bg-[#0b1121] border border-slate-800 rounded px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-orange-500/50"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-500 flex items-center gap-1">
              <Filter className="w-3 h-3" /> Día de la Semana
            </label>
            <div className="relative">
              <select 
                value={filterDay}
                onChange={(e) => setFilterDay(e.target.value)}
                className="w-full bg-[#0b1121] border border-slate-800 rounded px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-orange-500/50 appearance-none"
              >
                {DAYS_OF_WEEK.map(day => (
                  <option key={day.value} value={day.value}>{day.label}</option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 absolute right-3 top-2.5 text-slate-500 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-7xl mx-auto space-y-6">
          
          {/* Top Row: Histórico y Últimos 100 */}
          <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6">
            
            {/* Top Frecuencia */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
              <div className="p-4 border-b border-slate-800 flex items-center gap-2 text-sm font-semibold text-slate-200">
                <BarChart2 className="w-4 h-4 text-blue-400" />
                Top Histórico (Frecuencia)
              </div>
              <div className="flex-1 overflow-auto p-0 custom-scrollbar">
                <table className="w-full text-sm table-fixed">
                  <colgroup>
                    <col style={{ width: '55%' }} />
                    <col style={{ width: '45%' }} />
                  </colgroup>
                  <thead className="sticky top-0 bg-[#111827] text-xs text-slate-500">
                    <tr>
                      <th className="px-4 py-3 text-left font-medium">NÚMERO</th>
                      <th className="px-4 py-3 text-right font-medium">APARICIONES</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50">
                    {topHist.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="px-4 py-3 flex items-center gap-3">
                          <span className="text-slate-600 w-4">{idx + 1}.</span>
                          <span className="font-bold text-slate-200">{item.numero}</span>
                        </td>
                        <td className="px-4 py-3 text-right text-slate-400">{item.apariciones}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Últimos 100 y Tendencia */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
              <div className="p-4 border-b border-slate-800 flex items-center gap-2 text-sm font-semibold text-slate-200">
                <Activity className="w-4 h-4 text-cyan-400" />
                Últimos 100 Resultados y Tendencia
              </div>
              <div className="flex-1 p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={last100} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="date" stroke="#475569" fontSize={10} tickMargin={10} minTickGap={20} />
                    <YAxis stroke="#475569" fontSize={10} domain={[0, 9999]} tickCount={5} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b' }}
                      itemStyle={{ color: '#e2e8f0' }}
                    />
                    <Line type="monotone" dataKey="value" stroke="#0ea5e9" strokeWidth={1} dot={{ r: 2, fill: '#0ea5e9' }} activeDot={{ r: 4 }} name="Resultado" label={{ position: 'top', fontSize: 9, fill: '#7dd3fc', offset: 8 }} />
                    <Line type="linear" dataKey="trend" stroke="#ef4444" strokeWidth={2} strokeDasharray="4 4" dot={false} name="Tendencia Sugerida" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Segunda Fila: Eventos MM-DD */}
          {filterDate && (
            <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
              <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
                <div className="p-4 border-b border-slate-800 flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <Calendar className="w-4 h-4 text-pink-500" />
                  Eventos para {filterDate}
                </div>
                <div className="flex-1 overflow-auto p-0 custom-scrollbar">
                  <table className="w-full text-sm table-fixed">
                    <colgroup>
                      <col style={{ width: '55%' }} />
                      <col style={{ width: '45%' }} />
                    </colgroup>
                    <thead className="sticky top-0 bg-[#111827] text-xs text-slate-500">
                      <tr>
                        <th className="px-2 py-3 text-left font-medium">FECHA</th>
                        <th className="px-2 py-3 text-right font-medium">RESULTADO</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {specificDateEvents.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/30">
                          <td className="px-2 py-2 text-slate-300 text-xs">{item.date}</td>
                          <td className="px-2 py-2 text-right font-bold text-pink-500">{item.result}</td>
                        </tr>
                      ))}
                      {specificDateEvents.length === 0 && (
                        <tr><td colSpan={2} className="px-2 py-8 text-center text-slate-500 text-xs">No hay datos para esta fecha</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                    <Activity className="w-4 h-4 text-pink-500" />
                    Evolución y Tendencia para {filterDate}
                  </div>
                  <div className="flex items-center gap-2 bg-pink-500/10 text-pink-400 px-3 py-1 rounded-full text-xs font-semibold border border-pink-500/20">
                    <Award className="w-3 h-3" />
                    Predicción Tendencia: {specificDateChartData.length > 0 ? specificDateChartData[specificDateChartData.length-1].trend.toFixed(0) : '----'}
                  </div>
                </div>
                <div className="flex-1 p-4">
                  {specificDateChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={specificDateChartData} margin={{ top: 20, right: 15, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                        <XAxis dataKey="year" stroke="#475569" fontSize={10} tickMargin={10} />
                        <YAxis stroke="#475569" fontSize={10} domain={[0, 9999]} tickCount={5} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b' }}
                          itemStyle={{ color: '#e2e8f0' }}
                        />
                        <Line type="monotone" dataKey="value" stroke="#ec4899" strokeWidth={2} dot={{ r: 4, fill: '#ec4899' }} activeDot={{ r: 6 }} name="Resultado" label={{ position: 'top', fontSize: 10, fill: '#f9a8d4', fontWeight: 'bold', offset: 10 }} />
                        <Line type="linear" dataKey="trend" stroke="#ef4444" strokeWidth={2} strokeDasharray="4 4" dot={false} name="Tendencia Sugerida" />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-slate-500">Sin datos suficientes</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tercera Fila: Eventos Día de la Semana */}
          {filterDay && (
            <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
              <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
                <div className="p-4 border-b border-slate-800 flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <Calendar className="w-4 h-4 text-emerald-500" />
                  Resultados para {filterDay}
                </div>
                <div className="flex-1 overflow-auto p-0 custom-scrollbar">
                  <table className="w-full text-sm table-fixed">
                    <colgroup>
                      <col style={{ width: '55%' }} />
                      <col style={{ width: '45%' }} />
                    </colgroup>
                    <thead className="sticky top-0 bg-[#111827] text-xs text-slate-500">
                      <tr>
                        <th className="px-2 py-3 text-left font-medium">FECHA</th>
                        <th className="px-2 py-3 text-right font-medium">RESULTADO</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {dayEvents.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/30">
                          <td className="px-2 py-2 text-slate-300 text-xs">{item.date}</td>
                          <td className="px-2 py-2 text-right font-bold text-emerald-500">{item.result}</td>
                        </tr>
                      ))}
                      {dayEvents.length === 0 && (
                        <tr><td colSpan={2} className="px-2 py-8 text-center text-slate-500 text-xs">No hay datos para este día</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
                <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                    <Activity className="w-4 h-4 text-emerald-500" />
                    Últimos 100 {filterDay}s y Tendencia
                  </div>
                  <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-xs font-semibold border border-emerald-500/20">
                    <Award className="w-3 h-3" />
                    Sug. Día: {dayChartData.length > 0 ? dayChartData[dayChartData.length-1].trend.toFixed(0) : '----'}
                  </div>
                </div>
                <div className="flex-1 p-4">
                  {dayChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={dayChartData} margin={{ top: 20, right: 15, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                        <XAxis dataKey="date" stroke="#475569" fontSize={10} tickMargin={10} minTickGap={20} />
                        <YAxis stroke="#475569" fontSize={10} domain={[0, 9999]} tickCount={5} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b' }}
                          itemStyle={{ color: '#e2e8f0' }}
                        />
                        <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={1} dot={{ r: 2, fill: '#10b981' }} activeDot={{ r: 4 }} name="Resultado" label={{ position: 'top', fontSize: 9, fill: '#6ee7b7', offset: 8 }} />
                        <Line type="linear" dataKey="trend" stroke="#ef4444" strokeWidth={2} strokeDasharray="4 4" dot={false} name="Tendencia Sugerida" />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-slate-500">Sin datos suficientes</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Cuarta Fila: Análisis con Modelos de IA Avanzados */}
          <div className="mt-8 space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
              <div className="p-2 bg-indigo-500/20 rounded-lg">
                <Cpu className="w-6 h-6 text-indigo-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Análisis con Modelos de IA Avanzados</h2>
                <p className="text-sm text-slate-400">Evaluación algorítmica de probabilidades y predicción predictiva.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Tabla de Modelos */}
              <div className="lg:col-span-2 bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-[500px]">
                <div className="p-4 border-b border-slate-800 flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <Cpu className="w-4 h-4 text-indigo-400" />
                  Rendimiento y Predicciones por Modelo
                </div>
                <div className="flex-1 overflow-auto p-0 custom-scrollbar">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-[#111827] text-xs text-slate-500 shadow-sm z-10">
                      <tr>
                        <th className="px-6 py-3 text-left font-medium">MODELO IA</th>
                        <th className="px-6 py-3 text-center font-medium">PREDICCIÓN</th>
                        <th className="px-6 py-3 text-right font-medium">CONFIANZA</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {aiPredictions.map((model, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                          <td className="px-6 py-3 text-slate-300 font-medium">{model.model}</td>
                          <td className="px-6 py-3 text-center">
                            <span className="bg-slate-800 text-indigo-400 px-3 py-1 rounded-md font-mono text-base font-bold tracking-widest border border-slate-700">
                              {model.prediction}
                            </span>
                          </td>
                          <td className="px-6 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <span className={model.probability >= 80 ? "text-emerald-400" : model.probability >= 60 ? "text-yellow-400" : "text-slate-400"}>
                                {model.probability}%
                              </span>
                              <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${model.probability >= 80 ? 'bg-emerald-500' : model.probability >= 60 ? 'bg-yellow-500' : 'bg-slate-500'}`} 
                                  style={{ width: `${model.probability}%` }}
                                ></div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Sistema Profesional Multi-Confluencia */}
              <div className="bg-gradient-to-b from-[#111827] to-[#0b1121] border border-slate-800 rounded-xl overflow-hidden flex flex-col relative">
                {/* Glow effect */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4/5 h-20 bg-indigo-500/20 blur-[50px] pointer-events-none"></div>
                
                <div className="p-6 border-b border-slate-800/50 flex flex-col items-center text-center relative z-10">
                  <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mb-3 shadow-lg border border-slate-700">
                    <Award className="w-6 h-6 text-yellow-500" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-1">Sistema Profesional</h3>
                  <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Multi-Confluencia Top 3</p>
                </div>
                
                <div className="flex-1 p-6 flex flex-col gap-4 relative z-10">
                  {/* ORO */}
                  <div className="bg-gradient-to-r from-yellow-500/10 to-transparent border border-yellow-500/30 rounded-xl p-5 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-yellow-500/10 rounded-full blur-2xl -mr-10 -mt-10 group-hover:bg-yellow-500/20 transition-all"></div>
                    <div className="flex justify-between items-center relative z-10">
                      <div>
                        <div className="text-yellow-500 text-xs font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-yellow-500"></span> ORO
                        </div>
                        <div className="text-3xl font-mono font-bold text-white tracking-widest">{top3[0]?.prediction}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-yellow-400">{top3[0]?.probability}%</div>
                        <div className="text-xs text-slate-400">Probabilidad</div>
                      </div>
                    </div>
                  </div>

                  {/* PLATA */}
                  <div className="bg-gradient-to-r from-slate-300/10 to-transparent border border-slate-400/30 rounded-xl p-5 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-slate-400/10 rounded-full blur-2xl -mr-10 -mt-10 group-hover:bg-slate-400/20 transition-all"></div>
                    <div className="flex justify-between items-center relative z-10">
                      <div>
                        <div className="text-slate-300 text-xs font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-slate-400"></span> PLATA
                        </div>
                        <div className="text-3xl font-mono font-bold text-white tracking-widest">{top3[1]?.prediction}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-slate-300">{top3[1]?.probability}%</div>
                        <div className="text-xs text-slate-400">Probabilidad</div>
                      </div>
                    </div>
                  </div>

                  {/* BRONCE */}
                  <div className="bg-gradient-to-r from-orange-500/10 to-transparent border border-orange-500/30 rounded-xl p-5 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl -mr-10 -mt-10 group-hover:bg-orange-500/20 transition-all"></div>
                    <div className="flex justify-between items-center relative z-10">
                      <div>
                        <div className="text-orange-400 text-xs font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-orange-500"></span> BRONCE
                        </div>
                        <div className="text-3xl font-mono font-bold text-white tracking-widest">{top3[2]?.prediction}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-orange-400">{top3[2]?.probability}%</div>
                        <div className="text-xs text-slate-400">Probabilidad</div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      
      {/* Global styles for custom scrollbar */}
      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #0f172a; 
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #334155; 
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #475569; 
        }
      `}} />
    </div>
  );
}

export default App;
