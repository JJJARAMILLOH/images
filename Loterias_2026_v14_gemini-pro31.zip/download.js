import fs from 'fs';
import https from 'https';
import AdmZip from 'adm-zip';

const url = 'https://raw.githubusercontent.com/JJJARAMILLOH/images/main/Loterias_2026_v13_gemini-pro31.zip';
const file = fs.createWriteStream('temp.zip');

await new Promise((resolve, reject) => {
  https.get(url, (response) => {
    response.pipe(file);
    file.on('finish', () => {
      file.close(resolve);
    });
  }).on('error', (err) => {
    fs.unlinkSync('temp.zip');
    reject(err);
  });
});

const zip = new AdmZip('temp.zip');
zip.extractAllTo('./extracted', true);
console.log('Extracted successfully');
