import React, { useState, useMemo } from 'react';
import { tabla1, tabla2 } from '../utils/masterTables';
import { cn } from './Layout';
import { useAppContext } from '../context/AppContext';
import { Palette, Activity, HelpCircle, AlertCircle, Trophy } from 'lucide-react';

const monthsConfig = [
  { id: 'jan26', index: 0, label: "Ene '26", colorClass: "bg-rose-200 text-rose-900 border-rose-400", bgDot: "bg-rose-400", buttonClass: "bg-rose-500/20 text-rose-400 shadow", textHover: "hover:text-rose-400" },
  { id: 'feb26', index: 1, label: "Feb '26", colorClass: "bg-orange-200 text-orange-900 border-orange-400", bgDot: "bg-orange-400", buttonClass: "bg-orange-500/20 text-orange-400 shadow", textHover: "hover:text-orange-400" },
  { id: 'mar26', index: 2, label: "Mar '26", colorClass: "bg-yellow-200 text-yellow-900 border-yellow-400", bgDot: "bg-yellow-400", buttonClass: "bg-yellow-500/20 text-yellow-400 shadow", textHover: "hover:text-yellow-400" },
  { id: 'apr26', index: 3, label: "Abr '26", colorClass: "bg-blue-200 text-blue-900 border-blue-400", bgDot: "bg-blue-400", buttonClass: "bg-blue-500/20 text-blue-400 shadow", textHover: "hover:text-blue-400" },
  { id: 'may26', index: 4, label: "May '26", colorClass: "bg-[#cce8cc] text-emerald-900 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]", bgDot: "bg-emerald-400", buttonClass: "bg-emerald-500/20 text-emerald-400 shadow", textHover: "hover:text-emerald-400" },
  { id: 'jun26', index: 5, label: "Jun '26", colorClass: "bg-lime-200 text-lime-900 border-lime-400", bgDot: "bg-lime-400", buttonClass: "bg-lime-500/20 text-lime-400 shadow", textHover: "hover:text-lime-400" },
  { id: 'jul26', index: 6, label: "Jul '26", colorClass: "bg-cyan-200 text-cyan-900 border-cyan-400", bgDot: "bg-cyan-400", buttonClass: "bg-cyan-500/20 text-cyan-400 shadow", textHover: "hover:text-cyan-400" },
  { id: 'aug26', index: 7, label: "Ago '26", colorClass: "bg-sky-200 text-sky-900 border-sky-400", bgDot: "bg-sky-400", buttonClass: "bg-sky-500/20 text-sky-400 shadow", textHover: "hover:text-sky-400" },
  { id: 'sep26', index: 8, label: "Sep '26", colorClass: "bg-indigo-200 text-indigo-900 border-indigo-400", bgDot: "bg-indigo-400", buttonClass: "bg-indigo-500/20 text-indigo-400 shadow", textHover: "hover:text-indigo-400" },
  { id: 'oct26', index: 9, label: "Oct '26", colorClass: "bg-violet-200 text-violet-900 border-violet-400", bgDot: "bg-violet-400", buttonClass: "bg-violet-500/20 text-violet-400 shadow", textHover: "hover:text-violet-400" },
  { id: 'nov26', index: 10, label: "Nov '26", colorClass: "bg-fuchsia-200 text-fuchsia-900 border-fuchsia-400", bgDot: "bg-fuchsia-400", buttonClass: "bg-fuchsia-500/20 text-fuchsia-400 shadow", textHover: "hover:text-fuchsia-400" },
  { id: 'dec26', index: 11, label: "Dic '26", colorClass: "bg-purple-200 text-purple-900 border-purple-400", bgDot: "bg-purple-400", buttonClass: "bg-purple-500/20 text-purple-400 shadow", textHover: "hover:text-purple-400" }
];

export const MasterTables: React.FC = () => {
  const { data } = useAppContext();
  
  // States for coloring options
  const [colorFilter, setColorFilter] = useState<string>('none');

  // Find winning numbers for specific months in 2026 to colorize
  const winningNumbers = useMemo(() => {
    const monthsData: Record<number, Set<string>> = {};
    for (let i = 0; i < 12; i++) {
      monthsData[i] = new Set<string>();
    }

    data.forEach(d => {
      const month = d.fecha.getMonth(); 
      const year = d.fecha.getFullYear();
      
      if (year === 2026 && month >= 0 && month <= 11) {
        monthsData[month].add(d.resultado);
      }
    });

    return monthsData;
  }, [data]);

  const getColorClass = (num: string) => {
    if (colorFilter === 'none') return 'bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500';
    
    // Reverse loop to prioritize latest months (Dec -> Jan)
    for (let i = 11; i >= 0; i--) {
      const config = monthsConfig[i];
      if (winningNumbers[i].has(num)) {
        if (colorFilter === config.id || colorFilter === 'all') {
          return `${config.colorClass} font-bold`;
        }
      }
    }

    // Default if color filter active but didn't win
    return 'bg-slate-800 text-slate-500 border-slate-700 opacity-60';
  };

  // Missing numbers analysis
  const missingAnalysis = useMemo(() => {
    if (colorFilter === 'none') return null;
    
    let activeSet = new Set<string>();
    if (colorFilter === 'all') {
      for (let i = 0; i < 12; i++) {
        winningNumbers[i].forEach(num => activeSet.add(num));
      }
    } else {
      const config = monthsConfig.find(m => m.id === colorFilter);
      if (config) {
        activeSet = winningNumbers[config.index];
      }
    }

    const allTablaNumbers = [...tabla1.flat(), ...tabla2.flat()];
    const uniqueTablaNumbers = new Set(allTablaNumbers);
    
    const missing: string[] = [];
    uniqueTablaNumbers.forEach(num => {
      if (!activeSet.has(num)) {
        missing.push(num);
      }
    });

    const effectiveness = ((activeSet.size / uniqueTablaNumbers.size) * 100).toFixed(1);

    return { missing, effectiveness, total: uniqueTablaNumbers.size, won: activeSet.size };
  }, [colorFilter, winningNumbers]);


  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto pb-20">
      
      <div className="flex flex-col border-b border-slate-800 pb-6 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Tablas Maestras</h2>
          <p className="text-slate-400 text-sm max-w-xl">
            Estos son los 216 números maestros estudiados matemáticamente. 
            Utiliza el análisis de colores para visualizar qué números ya salieron y cuáles están atrasados.
          </p>
        </div>
        
        <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700 flex flex-wrap items-center gap-1.5 overflow-x-auto">
          <button 
            onClick={() => setColorFilter('none')}
            className={cn("px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all", colorFilter === 'none' ? "bg-slate-700 text-white shadow" : "text-slate-400 hover:text-slate-200")}
          >
            Normal
          </button>
          
          {monthsConfig.map(config => (
            <button 
              key={config.id}
              onClick={() => setColorFilter(config.id)}
              className={cn("px-2.5 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5", colorFilter === config.id ? config.buttonClass : `text-slate-400 ${config.textHover}`)}
            >
              <div className={`w-2.5 h-2.5 rounded-full ${config.bgDot}`}></div>
              <span className="whitespace-nowrap">{config.label}</span>
            </button>
          ))}

          <button 
             onClick={() => setColorFilter('all')}
            className={cn("px-3 py-1.5 rounded-lg text-xs md:text-sm font-medium transition-all flex items-center gap-1.5 border-l border-slate-600 pl-3 ml-1", colorFilter === 'all' ? "bg-slate-600 text-white shadow" : "text-slate-400 hover:text-white")}
          >
            <Palette size={14} /> Todos
          </button>
        </div>
      </div>

      {missingAnalysis && (
         <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Activity className="text-emerald-400" /> Análisis de Atrasos y Efectividad
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Números Ganadores</p>
                    <p className="text-2xl font-bold text-white mt-1">{missingAnalysis.won} <span className="text-sm text-slate-500 font-normal">/ {missingAnalysis.total}</span></p>
                 </div>
                 <div className="bg-emerald-500/20 p-3 rounded-full text-emerald-400"><Trophy size={20}/></div>
              </div>
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Porcentaje de Efectividad</p>
                    <p className="text-2xl font-bold text-cyan-400 mt-1">{missingAnalysis.effectiveness}%</p>
                 </div>
                 <div className="bg-cyan-500/20 p-3 rounded-full text-cyan-400"><Activity size={20}/></div>
              </div>
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Números Faltantes (Potenciales)</p>
                    <p className="text-2xl font-bold text-amber-400 mt-1">{missingAnalysis.missing.length}</p>
                 </div>
                 <div className="bg-amber-500/20 p-3 rounded-full text-amber-400"><AlertCircle size={20}/></div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
               <h4 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
                 <HelpCircle size={16} className="text-amber-400"/> 
                 Los números atrasados son potenciales para próximos sorteos:
               </h4>
               <div className="flex flex-wrap gap-2 max-h-[150px] overflow-y-auto custom-scrollbar p-1">
                 {missingAnalysis.missing.slice(0, 50).map(m => (
                    <span key={m} className="px-2 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-md text-sm font-medium">
                      {m}
                    </span>
                 ))}
                 {missingAnalysis.missing.length > 50 && (
                   <span className="px-2 py-1 text-slate-500 text-sm">+{missingAnalysis.missing.length - 50} más...</span>
                 )}
                 {missingAnalysis.missing.length === 0 && (
                   <span className="text-emerald-400 text-sm">¡Todos los números de la tabla han salido!</span>
                 )}
               </div>
            </div>
         </div>
      )}

      {/* TABLA 1 */}
      <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-xl">
        <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-700">
           <h3 className="text-lg font-bold text-white tracking-wider">TABLA MAESTRA 1</h3>
        </div>
        <div className="p-6 overflow-x-auto custom-scrollbar">
           <div className="grid grid-cols-9 gap-1.5 min-w-[600px]">
             {tabla1.map((row, rIdx) => (
                row.map((num, cIdx) => (
                   <div 
                     key={`t1-${rIdx}-${cIdx}`} 
                     className={cn(
                       "flex items-center justify-center p-2 rounded border transition-all duration-300",
                       getColorClass(num)
                     )}
                   >
                     {num}
                   </div>
                ))
             ))}
           </div>
        </div>
      </div>

      {/* TABLA 2 */}
      <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-xl">
        <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-700">
           <h3 className="text-lg font-bold text-white tracking-wider">TABLA MAESTRA 2</h3>
        </div>
        <div className="p-6 overflow-x-auto custom-scrollbar">
           <div className="grid grid-cols-9 gap-1.5 min-w-[600px]">
             {tabla2.map((row, rIdx) => (
                row.map((num, cIdx) => (
                   <div 
                     key={`t2-${rIdx}-${cIdx}`} 
                     className={cn(
                       "flex items-center justify-center p-2 rounded border transition-all duration-300",
                       getColorClass(num)
                     )}
                   >
                     {num}
                   </div>
                ))
             ))}
           </div>
        </div>
      </div>

      <div className="text-center text-slate-500 text-sm mt-4">
        Nota: Según la regla, al ganar cualquiera de estos números, el siguiente en ganar suele ser el del lado derecho o izquierdo.
      </div>
    </div>
  );
};
