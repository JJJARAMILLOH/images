import React, { createContext, useContext, useState, ReactNode } from 'react';
import { LotteryResult } from '../utils/csvParser';

interface FilterState {
  numero: string;
  loteria: string;
  fechaStr: string;
}

interface AppContextType {
  data: LotteryResult[];
  setData: (data: LotteryResult[]) => void;
  filters: FilterState;
  setFilters: (filters: Partial<FilterState>) => void;
  loterias: string[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<LotteryResult[]>([]);
  const [filters, setFilterState] = useState<FilterState>({
    numero: '',
    loteria: '',
    fechaStr: ''
  });

  const setFilters = (newFilters: Partial<FilterState>) => {
    setFilterState(prev => ({ ...prev, ...newFilters }));
  };

  const loterias = Array.from(new Set(data.map(d => d.loteria))).sort();

  return (
    <AppContext.Provider value={{ data, setData, filters, setFilters, loterias }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
