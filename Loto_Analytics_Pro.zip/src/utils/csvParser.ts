import Papa from 'papaparse';

export interface LotteryResult {
  fecha: Date;
  fechaStr: string;
  resultado: string;
  loteria: string;
}

export const parseCSV = (file: File): Promise<LotteryResult[]> => {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const parsedData = results.data.map((row: any) => {
            // Find keys dynamically in case of different casing or spaces
            const keys = Object.keys(row);
            const fechaKey = keys.find(k => k.toLowerCase().includes('fecha')) || keys[0];
            const resultadoKey = keys.find(k => k.toLowerCase().includes('resultado') || k.toLowerCase().includes('numero')) || keys[1];
            const loteriaKey = keys.find(k => k.toLowerCase().includes('loteria') || k.toLowerCase().includes('lotería')) || keys[2];

            const dateStr = row[fechaKey];
            // Basic date parsing (assuming DD/MM/YYYY or YYYY-MM-DD)
            let parsedDate = new Date(dateStr);
            if (isNaN(parsedDate.getTime()) && dateStr) {
              const parts = dateStr.split(/[-/]/);
              if (parts.length === 3) {
                 // Try DD/MM/YYYY
                 parsedDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
              }
            }

            // Ensure result is 3 digits if it's longer (taking last 3) or pad it
            let resultStr = String(row[resultadoKey] || '').trim();
            if (resultStr.length > 3) {
              resultStr = resultStr.slice(-3);
            } else {
              resultStr = resultStr.padStart(3, '0');
            }

            return {
              fecha: isNaN(parsedDate.getTime()) ? new Date() : parsedDate,
              fechaStr: dateStr || '',
              resultado: resultStr,
              loteria: String(row[loteriaKey] || '').trim().toUpperCase(),
            };
          }).filter(item => item.resultado !== '000' || item.fechaStr); // basic filter
          resolve(parsedData);
        } catch (error) {
          reject(error);
        }
      },
      error: (error) => {
        reject(error);
      }
    });
  });
};
