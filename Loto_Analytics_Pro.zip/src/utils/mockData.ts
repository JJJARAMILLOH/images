import { LotteryResult } from './csvParser';
import { tabla1, tabla2 } from './masterTables';

const loteriasList = [
  'BOGOTA', 'MEDELLIN', 'SANTANDER', 'RISARALDA', 'VALLE', 'CAUCA', 
  'BOYACA', 'CUNDINAMARCA', 'CRUZ ROJA', 'HUILA', 'META', 'TOLIMA', 'QUINDIO'
];

export const generateMockData = (): LotteryResult[] => {
  const allNumbers = [...tabla1.flat(), ...tabla2.flat()];
  const data: LotteryResult[] = [];
  
  // Generate around 5000 records for the last 5 years
  const today = new Date();
  
  for (let i = 0; i < 5000; i++) {
    const randomDays = Math.floor(Math.random() * 365 * 5); // up to 5 years ago
    const date = new Date(today.getTime() - randomDays * 24 * 60 * 60 * 1000);
    
    // Formatting date as Mon-YY (e.g., may-23, abr-26)
    const month = date.toLocaleString('es-ES', { month: 'short' }).slice(0, 3).toLowerCase();
    const year = date.getFullYear().toString().slice(-2);
    
    data.push({
      fecha: date,
      fechaStr: `${month}-${year}`,
      resultado: allNumbers[Math.floor(Math.random() * allNumbers.length)],
      loteria: loteriasList[Math.floor(Math.random() * loteriasList.length)]
    });
  }
  
  // Force some specific data for testing colored months (Mar 2026, Apr 2026, May 2026)
  const colorsMonths = [
    { m: 'mar', y: '26', mNum: 2, yNum: 2026 },
    { m: 'abr', y: '26', mNum: 3, yNum: 2026 },
    { m: 'may', y: '26', mNum: 4, yNum: 2026 }
  ];
  
  colorsMonths.forEach(({ m, y, mNum, yNum }) => {
    for (let i = 0; i < 50; i++) {
      data.push({
        fecha: new Date(yNum, mNum, Math.floor(Math.random() * 28) + 1),
        fechaStr: `${m}-${y}`,
        resultado: allNumbers[Math.floor(Math.random() * allNumbers.length)],
        loteria: loteriasList[Math.floor(Math.random() * loteriasList.length)]
      });
    }
  });

  return data;
};
