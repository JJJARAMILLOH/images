import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { BarChart3, Table as TableIcon, Upload, Calendar, Hash, Building2 } from 'lucide-react';
import { parseCSV } from '../utils/csvParser';
import { generateMockData } from '../utils/mockData';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface LayoutProps {
  children: React.ReactNode;
  activeTab: 'dashboard' | 'tables';
  setActiveTab: (tab: 'dashboard' | 'tables') => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const { filters, setFilters, loterias, setData } = useAppContext();
  const [loading, setLoading] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      try {
        const parsed = await parseCSV(file);
        setData(parsed);
      } catch (error) {
        console.error("Error parsing CSV", error);
        alert("Error leyendo el archivo CSV");
      } finally {
        setLoading(false);
      }
    }
  };

  const loadMock = () => {
    setData(generateMockData());
  };

  return (
    <div className="flex h-screen bg-slate-900 text-slate-100 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-80 bg-slate-800 border-r border-slate-700 flex flex-col shadow-xl z-10">
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-400 tracking-tight">
            LotoAnalytics Pro
          </h1>
          <p className="text-xs text-slate-400 mt-1">Ciencia de Datos & Probabilidad</p>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
          
          {/* Navigation */}
          <div className="space-y-2">
            <h2 className="text-xs uppercase text-slate-500 font-semibold tracking-wider mb-3">Vistas</h2>
            <button
              onClick={() => setActiveTab('dashboard')}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200",
                activeTab === 'dashboard' ? "bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)] border border-emerald-500/20" : "text-slate-400 hover:bg-slate-700/50 hover:text-slate-200"
              )}
            >
              <BarChart3 size={18} />
              <span className="font-medium">Dashboard Analítico</span>
            </button>
            <button
              onClick={() => setActiveTab('tables')}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200",
                activeTab === 'tables' ? "bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)] border border-emerald-500/20" : "text-slate-400 hover:bg-slate-700/50 hover:text-slate-200"
              )}
            >
              <TableIcon size={18} />
              <span className="font-medium">Tablas Maestras</span>
            </button>
          </div>

          {/* Filters */}
          <div className="space-y-4">
            <h2 className="text-xs uppercase text-slate-500 font-semibold tracking-wider mb-3">Filtros de Análisis</h2>
            
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 flex items-center gap-1.5 ml-1">
                <Hash size={14} /> Número Maestro (3 cifras)
              </label>
              <input
                type="text"
                maxLength={3}
                placeholder="Ej: 017"
                value={filters.numero}
                onChange={(e) => setFilters({ numero: e.target.value.replace(/\D/g, '') })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-slate-600"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 flex items-center gap-1.5 ml-1">
                <Building2 size={14} /> Lotería
              </label>
              <select
                value={filters.loteria}
                onChange={(e) => setFilters({ loteria: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all appearance-none"
              >
                <option value="">Todas las loterías</option>
                {loterias.map(l => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 flex items-center gap-1.5 ml-1">
                <Calendar size={14} /> Fecha Específica (mes-aa)
              </label>
              <input
                type="text"
                placeholder="Ej: may-23"
                value={filters.fechaStr}
                onChange={(e) => setFilters({ fechaStr: e.target.value.toLowerCase() })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-slate-600"
              />
            </div>
            
            <button 
              onClick={() => setFilters({ numero: '', loteria: '', fechaStr: '' })}
              className="w-full py-2 mt-2 text-xs text-slate-400 hover:text-slate-200 transition-colors"
            >
              Limpiar filtros
            </button>
          </div>

          {/* Data Source */}
          <div className="space-y-4 pt-4 border-t border-slate-700">
             <h2 className="text-xs uppercase text-slate-500 font-semibold tracking-wider mb-3">Fuente de Datos</h2>
             <label className="w-full flex items-center justify-center space-x-2 px-4 py-3 rounded-lg border border-dashed border-slate-600 hover:border-emerald-500 hover:bg-emerald-500/5 transition-all cursor-pointer text-sm text-slate-300">
                <Upload size={16} />
                <span>Subir CSV</span>
                <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
             </label>
             <button onClick={loadMock} className="w-full py-2 text-xs text-emerald-400/80 hover:text-emerald-400 transition-colors text-center">
               Cargar datos de prueba
             </button>
          </div>

        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-[#0B1120] relative custom-scrollbar">
        {/* Decorative background gradient */}
        <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-emerald-500/5 to-transparent pointer-events-none" />
        
        <div className="p-8 relative z-10 max-w-7xl mx-auto">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
            </div>
          ) : (
            children
          )}
        </div>
      </main>
    </div>
  );
};
