import React, { useState, useMemo } from 'react';
import { tabla1, tabla2 } from '../utils/masterTables';
import { cn } from './Layout';
import { useAppContext } from '../context/AppContext';
import { Palette, Activity, HelpCircle, AlertCircle, Trophy } from 'lucide-react';

export const MasterTables: React.FC = () => {
  const { data } = useAppContext();
  
  // States for coloring options
  const [colorFilter, setColorFilter] = useState<'none' | 'mar26' | 'apr26' | 'may26' | 'all'>('none');

  // Find winning numbers for specific months in 2026 to colorize
  // Based on requirement: marzo 2026 (amarillo), abril 2026 (azul claro), mayo 2026 (verde claro elegante)
  const winningNumbers = useMemo(() => {
    const mar = new Set<string>();
    const apr = new Set<string>();
    const may = new Set<string>();

    data.forEach(d => {
      const month = d.fecha.getMonth(); // 0 = Jan, 2 = Mar, 3 = Apr, 4 = May
      const year = d.fecha.getFullYear();
      
      if (year === 2026) {
        if (month === 2) mar.add(d.resultado);
        if (month === 3) apr.add(d.resultado);
        if (month === 4) may.add(d.resultado);
      }
    });

    return { mar, apr, may };
  }, [data]);

  const getColorClass = (num: string) => {
    if (colorFilter === 'none') return 'bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500';
    
    // For "all", we prioritize the latest (May over April over March) or combine
    const isMay = winningNumbers.may.has(num);
    const isApr = winningNumbers.apr.has(num);
    const isMar = winningNumbers.mar.has(num);

    if (colorFilter === 'may26' || colorFilter === 'all') {
      if (isMay) return 'bg-[#cce8cc] text-emerald-900 border-emerald-400 font-bold shadow-[0_0_10px_rgba(16,185,129,0.2)]';
    }
    if (colorFilter === 'apr26' || (colorFilter === 'all' && isApr)) {
      if (isApr) return 'bg-blue-200 text-blue-900 border-blue-400 font-bold';
    }
    if (colorFilter === 'mar26' || (colorFilter === 'all' && isMar)) {
      if (isMar) return 'bg-yellow-200 text-yellow-900 border-yellow-400 font-bold';
    }

    // Default if color filter active but didn't win
    return 'bg-slate-800 text-slate-500 border-slate-700 opacity-60';
  };

  // Missing numbers analysis
  const missingAnalysis = useMemo(() => {
    if (colorFilter === 'none') return null;
    
    let activeSet = new Set<string>();
    if (colorFilter === 'mar26') activeSet = winningNumbers.mar;
    else if (colorFilter === 'apr26') activeSet = winningNumbers.apr;
    else if (colorFilter === 'may26') activeSet = winningNumbers.may;
    else if (colorFilter === 'all') {
      activeSet = new Set([...winningNumbers.mar, ...winningNumbers.apr, ...winningNumbers.may]);
    }

    const allTablaNumbers = [...tabla1.flat(), ...tabla2.flat()];
    const uniqueTablaNumbers = new Set(allTablaNumbers);
    
    const missing: string[] = [];
    uniqueTablaNumbers.forEach(num => {
      if (!activeSet.has(num)) {
        missing.push(num);
      }
    });

    const effectiveness = ((activeSet.size / uniqueTablaNumbers.size) * 100).toFixed(1);

    return { missing, effectiveness, total: uniqueTablaNumbers.size, won: activeSet.size };
  }, [colorFilter, winningNumbers]);


  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto pb-20">
      
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-slate-800 pb-6 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Tablas Maestras</h2>
          <p className="text-slate-400 text-sm max-w-xl">
            Estos son los 216 números maestros estudiados matemáticamente. 
            Utiliza el análisis de colores para visualizar qué números ya salieron y cuáles están atrasados.
          </p>
        </div>
        
        <div className="bg-slate-800/80 p-1.5 rounded-xl border border-slate-700 flex items-center gap-1">
          <button 
            onClick={() => setColorFilter('none')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all", colorFilter === 'none' ? "bg-slate-700 text-white shadow" : "text-slate-400 hover:text-slate-200")}
          >
            Normal
          </button>
          <button 
            onClick={() => setColorFilter('mar26')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2", colorFilter === 'mar26' ? "bg-yellow-500/20 text-yellow-400 shadow" : "text-slate-400 hover:text-yellow-400")}
          >
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div> Mar '26
          </button>
          <button 
             onClick={() => setColorFilter('apr26')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2", colorFilter === 'apr26' ? "bg-blue-500/20 text-blue-400 shadow" : "text-slate-400 hover:text-blue-400")}
          >
            <div className="w-2.5 h-2.5 rounded-full bg-blue-400"></div> Abr '26
          </button>
          <button 
             onClick={() => setColorFilter('may26')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2", colorFilter === 'may26' ? "bg-emerald-500/20 text-emerald-400 shadow" : "text-slate-400 hover:text-emerald-400")}
          >
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"></div> May '26
          </button>
          <button 
             onClick={() => setColorFilter('all')}
            className={cn("px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 border-l border-slate-600 pl-4 ml-2", colorFilter === 'all' ? "bg-slate-600 text-white shadow" : "text-slate-400")}
          >
            <Palette size={14} /> Todos
          </button>
        </div>
      </div>

      {missingAnalysis && (
         <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Activity className="text-emerald-400" /> Análisis de Atrasos y Efectividad
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Números Ganadores</p>
                    <p className="text-2xl font-bold text-white mt-1">{missingAnalysis.won} <span className="text-sm text-slate-500 font-normal">/ {missingAnalysis.total}</span></p>
                 </div>
                 <div className="bg-emerald-500/20 p-3 rounded-full text-emerald-400"><Trophy size={20}/></div>
              </div>
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Porcentaje de Efectividad</p>
                    <p className="text-2xl font-bold text-cyan-400 mt-1">{missingAnalysis.effectiveness}%</p>
                 </div>
                 <div className="bg-cyan-500/20 p-3 rounded-full text-cyan-400"><Activity size={20}/></div>
              </div>
              <div className="bg-slate-900 border border-slate-700 rounded-xl p-4 flex items-center justify-between">
                 <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Números Faltantes (Potenciales)</p>
                    <p className="text-2xl font-bold text-amber-400 mt-1">{missingAnalysis.missing.length}</p>
                 </div>
                 <div className="bg-amber-500/20 p-3 rounded-full text-amber-400"><AlertCircle size={20}/></div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-700 rounded-xl p-5">
               <h4 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
                 <HelpCircle size={16} className="text-amber-400"/> 
                 Los números atrasados son potenciales para próximos sorteos:
               </h4>
               <div className="flex flex-wrap gap-2 max-h-[150px] overflow-y-auto custom-scrollbar p-1">
                 {missingAnalysis.missing.slice(0, 50).map(m => (
                    <span key={m} className="px-2 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-md text-sm font-medium">
                      {m}
                    </span>
                 ))}
                 {missingAnalysis.missing.length > 50 && (
                   <span className="px-2 py-1 text-slate-500 text-sm">+{missingAnalysis.missing.length - 50} más...</span>
                 )}
                 {missingAnalysis.missing.length === 0 && (
                   <span className="text-emerald-400 text-sm">¡Todos los números de la tabla han salido!</span>
                 )}
               </div>
            </div>
         </div>
      )}

      {/* TABLA 1 */}
      <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-xl">
        <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-700">
           <h3 className="text-lg font-bold text-white tracking-wider">TABLA MAESTRA 1</h3>
        </div>
        <div className="p-6 overflow-x-auto custom-scrollbar">
           <div className="grid grid-cols-9 gap-1.5 min-w-[600px]">
             {tabla1.map((row, rIdx) => (
                row.map((num, cIdx) => (
                   <div 
                     key={`t1-${rIdx}-${cIdx}`} 
                     className={cn(
                       "flex items-center justify-center p-2 rounded border transition-all duration-300",
                       getColorClass(num)
                     )}
                   >
                     {num}
                   </div>
                ))
             ))}
           </div>
        </div>
      </div>

      {/* TABLA 2 */}
      <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden shadow-xl">
        <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-700">
           <h3 className="text-lg font-bold text-white tracking-wider">TABLA MAESTRA 2</h3>
        </div>
        <div className="p-6 overflow-x-auto custom-scrollbar">
           <div className="grid grid-cols-9 gap-1.5 min-w-[600px]">
             {tabla2.map((row, rIdx) => (
                row.map((num, cIdx) => (
                   <div 
                     key={`t2-${rIdx}-${cIdx}`} 
                     className={cn(
                       "flex items-center justify-center p-2 rounded border transition-all duration-300",
                       getColorClass(num)
                     )}
                   >
                     {num}
                   </div>
                ))
             ))}
           </div>
        </div>
      </div>

      <div className="text-center text-slate-500 text-sm mt-4">
        Nota: Según la regla, al ganar cualquiera de estos números, el siguiente en ganar suele ser el del lado derecho o izquierdo.
      </div>
    </div>
  );
};
