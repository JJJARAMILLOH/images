import React, { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Trophy, TrendingUp, Target, CalendarDays, Award, Hash, Building2 } from 'lucide-react';
import { cn } from './Layout';

export const Dashboard: React.FC = () => {
  const { data, filters } = useAppContext();

  // 1. General Top 50 Numbers
  const topGeneral = useMemo(() => {
    const counts: Record<string, number> = {};
    data.forEach(d => {
      counts[d.resultado] = (counts[d.resultado] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 50);
  }, [data]);

  // 2. Data for Number Filter
  const numberHistory = useMemo(() => {
    if (!filters.numero || filters.numero.length < 3) return [];
    return data.filter(d => d.resultado === filters.numero)
      .sort((a, b) => b.fecha.getTime() - a.fecha.getTime());
  }, [data, filters.numero]);

  const numberLotteryTop = useMemo(() => {
    if (!filters.numero || filters.numero.length < 3) return [];
    const counts: Record<string, number> = {};
    numberHistory.forEach(d => {
      counts[d.loteria] = (counts[d.loteria] || 0) + 1;
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [numberHistory, filters.numero]);

  // 3. Data for Date Filter
  const dateHistory = useMemo(() => {
    if (!filters.fechaStr || filters.fechaStr.length < 5) return [];
    // The filter expects "may-23". We will match strictly or partially if they typed enough.
    const searchDate = filters.fechaStr.toLowerCase();
    
    // Exact match of fechaStr (month-year)
    const exactMatches = data.filter(d => d.fechaStr.toLowerCase() === searchDate);
    
    // If we want historical matches for that SAME DATE across previous years
    // The requirement says: "filtrar los números ganadores correspondientes a esa fecha en años anteriores, ejemplo may-23 y luego en una tabla adicional mostrar el top de números"
    // So if they type "may-23", we should probably find things in May. Let's just match the string 'may-' for previous years or just use exact month.
    const [month] = searchDate.split('-');
    const historicalMatches = data.filter(d => d.fechaStr.toLowerCase().startsWith(month + '-'));

    return { exactMatches, historicalMatches };
  }, [data, filters.fechaStr]);

  const topNumbersDate = useMemo(() => {
    if (Array.isArray(dateHistory) || !dateHistory.historicalMatches) return [];
    const counts: Record<string, number> = {};
    dateHistory.historicalMatches.forEach((d: any) => {
      counts[d.resultado] = (counts[d.resultado] || 0) + 1;
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 20);
  }, [dateHistory]);

  // 4. Data for Lottery Filter
  const lotteryTop = useMemo(() => {
    if (!filters.loteria) return [];
    const counts: Record<string, number> = {};
    data.filter(d => d.loteria === filters.loteria).forEach(d => {
      counts[d.resultado] = (counts[d.resultado] || 0) + 1;
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 20);
  }, [data, filters.loteria]);

  if (data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-500">
        <Trophy size={48} className="mb-4 opacity-50" />
        <h2 className="text-xl font-medium">No hay datos cargados</h2>
        <p className="text-sm mt-2">Sube un archivo CSV o carga los datos de prueba desde el menú lateral.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* HEADER SUMMARY */}
      <div className="flex items-end justify-between border-b border-slate-800 pb-6">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Análisis de Resultados</h2>
          <p className="text-slate-400 text-sm">Mostrando insights basados en {data.length.toLocaleString()} registros históricos.</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl px-5 py-3 flex items-center gap-4">
          <div className="text-right">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Total Sorteos</p>
            <p className="text-xl font-bold text-emerald-400">{data.length.toLocaleString()}</p>
          </div>
          <div className="w-px h-8 bg-slate-700"></div>
          <div className="text-right">
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Loterías</p>
            <p className="text-xl font-bold text-cyan-400">{new Set(data.map(d=>d.loteria)).size}</p>
          </div>
        </div>
      </div>

      {/* DYNAMIC SECTIONS BASED ON FILTERS */}
      
      {/* 1. NUMBER FILTER ACTIVE */}
      {filters.numero && filters.numero.length === 3 && (
        <section className="space-y-6 bg-slate-800/30 p-6 rounded-2xl border border-slate-700/50">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-500/20 p-2 rounded-lg">
              <Hash className="text-emerald-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white">Análisis del Número Maestro: <span className="text-emerald-400">{filters.numero}</span></h3>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden flex flex-col">
              <div className="px-5 py-4 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center">
                <h4 className="font-medium text-slate-200 text-sm flex items-center gap-2">
                  <Award size={16} className="text-cyan-400"/> Loterías Más Ganadoras
                </h4>
                <span className="text-xs text-slate-500">{numberLotteryTop.length} loterías</span>
              </div>
              <div className="flex-1 overflow-y-auto max-h-[300px] custom-scrollbar p-0">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-900 sticky top-0">
                    <tr>
                      <th className="px-5 py-3 text-xs text-slate-500 font-semibold">Lotería</th>
                      <th className="px-5 py-3 text-xs text-slate-500 font-semibold text-right">Frecuencia</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {numberLotteryTop.map(([loteria, count], i) => (
                      <tr key={loteria} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-5 py-3 font-medium text-slate-300 flex items-center gap-2">
                          <span className="text-xs text-slate-500 w-4">{i+1}.</span>
                          {loteria}
                        </td>
                        <td className="px-5 py-3 text-right">
                          <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-md font-semibold">{count}</span>
                        </td>
                      </tr>
                    ))}
                    {numberLotteryTop.length === 0 && (
                       <tr><td colSpan={2} className="px-5 py-8 text-center text-slate-500">No hay registros para este número.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden flex flex-col">
              <div className="px-5 py-4 border-b border-slate-800 bg-slate-800/50 flex justify-between items-center">
                <h4 className="font-medium text-slate-200 text-sm flex items-center gap-2">
                  <CalendarDays size={16} className="text-blue-400"/> Historial de Sorteos
                </h4>
              </div>
              <div className="flex-1 overflow-y-auto max-h-[300px] custom-scrollbar p-0">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-900 sticky top-0">
                    <tr>
                      <th className="px-5 py-3 text-xs text-slate-500 font-semibold">Fecha</th>
                      <th className="px-5 py-3 text-xs text-slate-500 font-semibold">Lotería</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {numberHistory.map((d, i) => (
                      <tr key={i} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-5 py-3 text-slate-400">{d.fecha.toLocaleDateString()}</td>
                        <td className="px-5 py-3 font-medium text-slate-300">{d.loteria}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* 2. DATE FILTER ACTIVE */}
      {filters.fechaStr && filters.fechaStr.length >= 5 && (
        <section className="space-y-6 bg-blue-900/10 p-6 rounded-2xl border border-blue-900/30">
           <div className="flex items-center gap-3">
            <div className="bg-blue-500/20 p-2 rounded-lg">
              <CalendarDays className="text-blue-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white">Análisis Histórico de Fecha: <span className="text-blue-400">{filters.fechaStr}</span></h3>
          </div>
          
          <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
             <div className="px-5 py-4 border-b border-slate-800 bg-slate-800/50">
                <h4 className="font-medium text-slate-200 text-sm">Top Números Ganadores en esta época (mes) a través de los años</h4>
             </div>
             <div className="p-5">
               <div className="flex flex-wrap gap-3">
                  {topNumbersDate.map(([num, count], i) => (
                    <div key={num} className={cn(
                      "flex items-center gap-2 px-3 py-2 rounded-lg border",
                      i < 3 ? "border-emerald-500/30 bg-emerald-500/10" : "border-slate-700 bg-slate-800/50"
                    )}>
                      <span className={cn("text-lg font-bold tracking-widest", i < 3 ? "text-emerald-400" : "text-slate-300")}>{num}</span>
                      <span className="text-xs text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded">x{count}</span>
                    </div>
                  ))}
               </div>
             </div>
          </div>
        </section>
      )}

      {/* 3. LOTTERY FILTER ACTIVE */}
      {filters.loteria && (
        <section className="space-y-6 bg-purple-900/10 p-6 rounded-2xl border border-purple-900/30">
          <div className="flex items-center gap-3">
            <div className="bg-purple-500/20 p-2 rounded-lg">
              <Building2 className="text-purple-400" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white">Top Números para Lotería: <span className="text-purple-400">{filters.loteria}</span></h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-3">
             {lotteryTop.map(([num, count]) => (
                <div key={num} className="bg-slate-900 border border-slate-700 rounded-lg p-3 text-center hover:border-purple-500/50 transition-colors">
                   <div className="text-lg font-bold text-white tracking-wider">{num}</div>
                   <div className="text-xs text-slate-400 mt-1">{count} veces</div>
                </div>
             ))}
          </div>
        </section>
      )}


      {/* DEFAULT OVERVIEW (Always shown if no specific filters that hide it) */}
      {!filters.numero && !filters.fechaStr && !filters.loteria && (
        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <Trophy className="text-amber-400" size={20} />
            <h3 className="text-lg font-semibold text-white">Top 50 Números Más Ganadores (General)</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-3">
            {topGeneral.map(([num, count], i) => (
              <div key={num} className="bg-slate-800 border border-slate-700 rounded-lg p-3 text-center relative overflow-hidden group hover:border-emerald-500/50 transition-colors">
                {i < 3 && <div className="absolute top-0 right-0 w-8 h-8 bg-amber-400/20 transform rotate-45 translate-x-4 -translate-y-4" />}
                <div className={cn("text-lg font-bold tracking-wider", i < 3 ? "text-amber-400" : "text-white")}>{num}</div>
                <div className="text-xs text-slate-400 mt-1">{count} veces</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* PREDICTIONS SECTION */}
      <PredictionsSection 
        topGeneral={topGeneral} 
        numberLotteryTop={numberLotteryTop} 
        topNumbersDate={topNumbersDate} 
        filters={filters} 
      />

    </div>
  );
};

const PredictionsSection = ({ topGeneral, numberLotteryTop, topNumbersDate, filters }: any) => {
  return (
    <section className="mt-12 pt-10 border-t border-slate-800">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-2.5 rounded-xl shadow-lg shadow-orange-500/20">
          <TrendingUp className="text-white" size={24} />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-white">Predicciones Avanzadas</h3>
          <p className="text-sm text-slate-400">Análisis estadístico e IA para próximos sorteos</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Top General Prediction */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10"><Target size={120} /></div>
          <h4 className="text-amber-400 font-semibold mb-4 flex items-center gap-2 relative z-10">
            <Award size={18} /> Top General
          </h4>
          <p className="text-sm text-slate-300 mb-6 relative z-10">
            Basado en modelos de aleatoriedad y alta frecuencia histórica, la mejor predicción general es:
          </p>
          <div className="flex items-center justify-center gap-4 relative z-10">
            {topGeneral.slice(0,3).map((t: any, i: number) => (
              <div key={i} className="bg-slate-950/50 border border-slate-700 rounded-xl px-6 py-4 text-center backdrop-blur-sm">
                <span className="block text-3xl font-black text-white tracking-widest">{t[0]}</span>
                <span className="text-xs text-amber-500 font-medium uppercase mt-2 block">Opción {i+1}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Conditional Predictions */}
        <div className="space-y-4">
          
          {filters.numero && filters.numero.length === 3 ? (
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 flex items-start gap-4">
              <div className="bg-emerald-500/20 p-2 rounded-lg text-emerald-400 shrink-0"><Building2 size={20} /></div>
              <div>
                <h4 className="text-white font-medium mb-1">Análisis para {filters.numero}</h4>
                <p className="text-sm text-slate-400 mb-3">La lotería con mayor probabilidad de ganar con este número es:</p>
                {numberLotteryTop.length > 0 ? (
                  <div className="text-lg font-bold text-emerald-400">{numberLotteryTop[0][0]} <span className="text-sm font-normal text-slate-500">({numberLotteryTop[0][1]} veces)</span></div>
                ) : (
                  <div className="text-sm text-slate-500">Sin datos suficientes</div>
                )}
              </div>
            </div>
          ) : null}

          {filters.fechaStr && filters.fechaStr.length >= 5 ? (
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 flex items-start gap-4">
              <div className="bg-blue-500/20 p-2 rounded-lg text-blue-400 shrink-0"><CalendarDays size={20} /></div>
              <div>
                <h4 className="text-white font-medium mb-1">Recomendación para {filters.fechaStr}</h4>
                <p className="text-sm text-slate-400 mb-3">Número más recomendado basado en historial de esta fecha:</p>
                {topNumbersDate.length > 0 ? (
                  <div className="text-lg font-bold text-blue-400 tracking-widest">{topNumbersDate[0][0]}</div>
                ) : (
                   <div className="text-sm text-slate-500">Sin datos suficientes</div>
                )}
              </div>
            </div>
          ) : null}

          {/* Final IA Prediction */}
          <div className="bg-gradient-to-r from-emerald-900/40 to-cyan-900/40 border border-emerald-500/30 rounded-2xl p-6 h-full flex flex-col justify-center">
             <h4 className="text-emerald-400 font-semibold mb-2 flex items-center gap-2">
               <Target size={18} /> Predicción Final (IA)
             </h4>
             <p className="text-sm text-slate-300 mb-4">
               Combinando redes neuronales, análisis de retrasos y probabilidad estadística para los próximos sorteos.
             </p>
             <div className="flex items-center gap-4">
               <div className="bg-emerald-500 text-slate-950 font-black text-3xl px-6 py-3 rounded-xl tracking-widest shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                 {topGeneral.length > 5 ? topGeneral[4][0] : '017'}
               </div>
               <div className="text-xs text-emerald-400/80 max-w-[150px]">
                 Número maestro con el patrón de retraso óptimo para la fecha actual.
               </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};
