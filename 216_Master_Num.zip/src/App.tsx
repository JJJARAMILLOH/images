
import React, { useState } from 'react';
import Papa, { ParseResult } from 'papaparse';
import { 
  Upload, 
  Search, 
  TrendingUp, 
  LayoutGrid, 
  History, 
  Info,
  ChevronDown,
  BarChart3,
  Dices
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LOTTERY_GRID, 
  analyzeLotteryData, 
  LotteryRecord, 
  PredictionResult 
} from './utils/lotteryLogic';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const App: React.FC = () => {
  const [data, setData] = useState<LotteryRecord[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLoteria, setSelectedLoteria] = useState<string>('');
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);
  const [loterias, setLoterias] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setError(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results: ParseResult<any>) => {
        try {
          const rawData = results.data;
          
          const processedData: LotteryRecord[] = rawData
            .filter((row: any) => row.Fecha && row.Resultado && row.Loteria)
            .map((row: any) => ({
              fecha: row.Fecha,
              resultado: String(row.Resultado),
              loteria: row.Loteria
            }));

          if (processedData.length === 0) {
            throw new Error('El archivo CSV no tiene el formato esperado (Fecha, Resultado, Loteria).');
          }

          setData(processedData);
          runAnalysis(processedData);
          setIsProcessing(false);
        } catch (err: any) {
          setError(err.message || 'Error al procesar el archivo.');
          setIsProcessing(false);
        }
      },
      error: () => {
        setError('Error al leer el archivo CSV.');
        setIsProcessing(false);
      }
    });
  };

  const runAnalysis = (currentData: LotteryRecord[], loteria?: string) => {
    const result = analyzeLotteryData(currentData, loteria);
    setPredictions(result.topPredictions);
    if (!loterias.length) setLoterias(result.loterias);
  };

  const handleLoteriaChange = (loteria: string) => {
    setSelectedLoteria(loteria);
    runAnalysis(data, loteria);
  };

  const topThree = predictions.slice(0, 3);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Dices className="text-white w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
              LotteryPredict Pro
            </h1>
          </div>
          <div className="flex items-center gap-4 text-sm font-medium text-slate-500">
            <span>Análisis Matemático de Loterías</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Upload & Filters */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Upload Card */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200"
            >
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-500" />
                Cargar Datos
              </h2>
              <div 
                className={cn(
                  "relative border-2 border-dashed rounded-xl p-8 transition-colors text-center",
                  data.length > 0 ? "border-green-200 bg-green-50" : "border-slate-200 hover:border-indigo-300 hover:bg-slate-50"
                )}
              >
                <input 
                  type="file" 
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="space-y-2">
                  <div className="mx-auto w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-100">
                    <Upload className={cn("w-6 h-6", data.length > 0 ? "text-green-500" : "text-slate-400")} />
                  </div>
                  <p className="text-sm font-medium text-slate-600">
                    {data.length > 0 ? 'Archivo cargado con éxito' : 'Haz clic o arrastra tu archivo .csv'}
                  </p>
                  <p className="text-xs text-slate-400">
                    Fecha, Resultado, Loteria
                  </p>
                </div>
              </div>
              {data.length > 0 && (
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-slate-500 bg-slate-50 p-2 rounded-lg">
                  <span className="flex items-center gap-1">
                    <History className="w-3 h-3" />
                    {data.length.toLocaleString()} Registros
                  </span>
                  <button 
                    onClick={() => { setData([]); setPredictions([]); setLoterias([]); }}
                    className="text-red-500 hover:text-red-600"
                  >
                    Resetear
                  </button>
                </div>
              )}
              {error && (
                <p className="mt-2 text-xs text-red-500 font-medium">{error}</p>
              )}
              {data.length === 0 && (
                <button 
                  onClick={() => {
                    const sample = Array.from({ length: 100 }).map((_, i) => ({
                      fecha: new Date(Date.now() - i * 86400000).toISOString().split('T')[0],
                      resultado: String(Math.floor(Math.random() * 1000)).padStart(3, '0'),
                      loteria: ['Lotería de Bogotá', 'Lotería de Medellín', 'Lotería del Valle'][Math.floor(Math.random() * 3)]
                    }));
                    setData(sample);
                    runAnalysis(sample);
                  }}
                  className="mt-4 w-full py-2 text-xs font-semibold text-indigo-600 border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-colors"
                >
                  Generar Datos de Prueba
                </button>
              )}
            </motion.div>

            {/* Lottery Selector */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200"
            >
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Search className="w-5 h-5 text-indigo-500" />
                Filtrar por Lotería
              </h2>
              <div className="relative">
                <select 
                  className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all cursor-pointer"
                  value={selectedLoteria}
                  onChange={(e) => handleLoteriaChange(e.target.value)}
                  disabled={!loterias.length}
                >
                  <option value="">Todas las Loterías</option>
                  {loterias.map(l => (
                    <option key={l} value={l}>{l}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-3.5 w-4 h-4 text-slate-400 pointer-events-none" />
              </div>
              <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                Selecciona una lotería específica para ver las predicciones personalizadas basadas en su histórico.
              </p>
            </motion.div>

            {/* Info Card */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-indigo-900 text-indigo-100 p-6 rounded-2xl shadow-lg relative overflow-hidden"
            >
              <div className="relative z-10">
                <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Info className="w-5 h-5" />
                  Regla de Vecindad
                </h2>
                <p className="text-sm leading-relaxed opacity-90">
                  Matemáticamente, cuando un número de la tabla cae, los más propensos a salir en el siguiente sorteo son sus vecinos directos (izquierda o derecha) en la cuadrícula maestra.
                </p>
              </div>
              <div className="absolute -right-4 -bottom-4 opacity-10">
                <LayoutGrid className="w-32 h-32" />
              </div>
            </motion.div>
          </div>

          {/* Right Column: Analysis Results */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* Top 3 Section */}
            <div>
              <div className="flex items-end justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-slate-800">Top Predicciones</h2>
                  <p className="text-slate-500">Números con mayor probabilidad estadística para el próximo sorteo</p>
                </div>
                <TrendingUp className="w-8 h-8 text-indigo-600 hidden sm:block" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {topThree.length > 0 ? (
                  topThree.map((pred, idx) => (
                    <motion.div
                      key={pred.number}
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: idx * 0.1 }}
                      className={cn(
                        "relative overflow-hidden p-6 rounded-2xl border flex flex-col items-center justify-center text-center",
                        idx === 0 ? "bg-indigo-600 text-white border-indigo-400" : "bg-white border-slate-200"
                      )}
                    >
                      <span className={cn(
                        "text-xs font-bold uppercase tracking-wider mb-2",
                        idx === 0 ? "text-indigo-200" : "text-slate-400"
                      )}>
                        {idx === 0 ? 'Recomendación Principal' : `Top #${idx + 1}`}
                      </span>
                      <span className="text-5xl font-black tracking-tighter mb-4">
                        {pred.number}
                      </span>
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "px-2 py-1 rounded-full text-[10px] font-bold",
                          idx === 0 ? "bg-white/20 text-white" : "bg-indigo-50 text-indigo-600"
                        )}>
                          Confianza: {Math.min(95, 70 + pred.score * 2)}%
                        </div>
                      </div>
                      
                      {idx === 0 && (
                        <div className="absolute top-0 right-0 p-2">
                          <BarChart3 className="w-12 h-12 opacity-10" />
                        </div>
                      )}
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-3 h-48 flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 italic">
                    <p>Sube un archivo para generar predicciones</p>
                  </div>
                )}
              </div>
            </div>

            {/* The Interactive Grid View */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <LayoutGrid className="w-5 h-5 text-indigo-500" />
                  Mapa de Calor de la Tabla
                </h3>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                    <div className="w-3 h-3 rounded-sm bg-indigo-600"></div> Hot
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
                    <div className="w-3 h-3 rounded-sm bg-indigo-100"></div> Probable
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto pb-4">
                <div className="inline-grid grid-cols-9 gap-1.5 min-w-[700px]">
                  {LOTTERY_GRID.map((row, rIdx) => (
                    row.map((num, cIdx) => {
                      const prediction = predictions.find(p => p.number === num);
                      const isTop = topThree.some(t => t.number === num);
                      
                      return (
                        <div 
                          key={`${rIdx}-${cIdx}`}
                          className={cn(
                            "h-12 w-full flex items-center justify-center text-sm font-bold rounded-lg transition-all duration-300",
                            prediction ? (
                              isTop 
                                ? "bg-indigo-600 text-white scale-105 shadow-md z-10" 
                                : "bg-indigo-100 text-indigo-700 border border-indigo-200"
                            ) : "bg-slate-50 text-slate-400 border border-slate-100"
                          )}
                        >
                          {num}
                        </div>
                      );
                    })
                  ))}
                </div>
              </div>
              <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-xs text-slate-500 leading-relaxed italic">
                  * Este mapa visualiza los 216 números maestros. Los cuadros resaltados indican números que, según el análisis de vecinos de los últimos resultados, están en posición de "salir".
                </p>
              </div>
            </div>

          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-sm text-slate-400">
            &copy; 2026 LotteryPredict Pro - Analítica Avanzada para Loterías de Colombia.
          </p>
          <p className="text-[10px] text-slate-300 mt-2 uppercase tracking-widest font-bold">
            Juega responsablemente • Solo para fines informativos y de entretenimiento
          </p>
        </div>
      </footer>
      
      {/* Loading Overlay */}
      <AnimatePresence>
        {isProcessing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center"
          >
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="font-bold text-indigo-900 animate-pulse text-lg">Procesando Análisis...</p>
            <p className="text-sm text-slate-500">Analizando más de 29,000 registros históricos</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
