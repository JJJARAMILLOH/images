
export const LOTTERY_GRID = [
  ["017", "317", "417", "517", "437", "347", "734", "744", "474"],
  ["037", "471", "714", "741", "777", "444", "844", "044", "404"],
  ["415", "615", "505", "045", "054", "450", "954", "945", "549"],
  ["459", "516", "165", "538", "853", "385", "358", "999", "000"],
  ["111", "222", "333", "666", "888", "351", "352", "353", "354"],
  ["501", "015", "105", "510", "449", "499", "994", "822", "722"],
  ["622", "522", "880", "088", "808", "788", "878", "889", "988"],
  ["098", "170", "071", "710", "701", "278", "728", "287", "827"],
  ["872", "882", "884", "886", "688", "668", "866", "818", "100"],
  ["200", "400", "500", "950", "029", "023", "027", "910", "091"],
  ["901", "927", "555", "008", "004", "002", "213", "321", "123"],
  ["943", "539", "813", "879", "978", "758", "857", "785", "559"],
  ["562", "862", "962", "062", "982", "892", "289", "299", "929"],
  ["582", "926", "269", "296", "222", "999", "399", "599", "959"],
  ["960", "160", "050", "590", "509", "905", "409", "490", "094"],
  ["904", "061", "610", "083", "308", "830", "803", "444", "555"],
  ["666", "777", "888", "111", "333", "806", "807", "808", "809"],
  ["056", "560", "650", "065", "994", "944", "449", "377", "277"],
  ["177", "077", "335", "533", "353", "233", "323", "334", "433"],
  ["543", "625", "526", "265", "256", "723", "273", "732", "372"],
  ["327", "337", "339", "331", "133", "113", "311", "363", "655"],
  ["755", "955", "055", "405", "574", "578", "572", "465", "546"],
  ["456", "472", "000", "553", "559", "557", "768", "876", "678"],
  ["498", "084", "368", "324", "423", "203", "302", "230", "004"],
];

export interface LotteryRecord {
  fecha: string;
  resultado: string;
  loteria: string;
}

export interface PredictionResult {
  number: string;
  score: number;
  reason?: string;
}

export function findNeighbors(num: string): string[] {
  const neighbors: string[] = [];
  const cleanNum = num.slice(-3); // Always check last 3 digits
  
  for (let r = 0; r < LOTTERY_GRID.length; r++) {
    for (let c = 0; c < LOTTERY_GRID[r].length; c++) {
      if (LOTTERY_GRID[r][c] === cleanNum) {
        if (c > 0) neighbors.push(LOTTERY_GRID[r][c - 1]);
        if (c < LOTTERY_GRID[r].length - 1) neighbors.push(LOTTERY_GRID[r][c + 1]);
      }
    }
  }
  return [...new Set(neighbors)];
}

export function analyzeLotteryData(data: LotteryRecord[], targetLoteria?: string) {
  const filteredData = targetLoteria 
    ? data.filter(d => d.loteria.toLowerCase() === targetLoteria.toLowerCase())
    : data;

  // We sort by date (descending) to get the most recent ones
  const sorted = [...filteredData].sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
  
  const frequencyMap: Record<string, number> = {};
  
  // Use the last 50 results to find "active" predictions
  const recentResults = sorted.slice(0, 50);
  
  recentResults.forEach(record => {
    const neighbors = findNeighbors(record.resultado);
    neighbors.forEach(n => {
      frequencyMap[n] = (frequencyMap[n] || 0) + 1;
    });
  });

  const predictions: PredictionResult[] = Object.entries(frequencyMap)
    .map(([number, score]) => ({ number, score }))
    .sort((a, b) => b.score - a.score);

  return {
    topPredictions: predictions.slice(0, 10),
    loterias: [...new Set(data.map(d => d.loteria))].sort(),
    totalAnalyzed: filteredData.length
  };
}
