import React, { useState, useMemo } from 'react';
// @ts-ignore
import Papa from 'papaparse';
import { 
  Upload, 
  CheckCircle, 
  AlertCircle, 
  Filter, 
  Table as TableIcon,
  Info,
  TrendingUp,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Definición de las tablas maestras según la imagen
const TABLE_1_NUMBERS = [
  '017', '317', '417', '517', '437', '347', '734', '744', '474',
  '037', '471', '714', '741', '777', '444', '844', '044', '404',
  '415', '615', '505', '045', '054', '450', '954', '945', '549',
  '459', '516', '165', '538', '853', '385', '358', '999', '000',
  '111', '222', '333', '666', '888', '351', '352', '353', '354',
  '501', '015', '105', '510', '449', '499', '994', '822', '722',
  '622', '522', '880', '088', '808', '788', '878', '889', '988',
  '098', '170', '071', '710', '701', '278', '728', '287', '827',
  '872', '882', '884', '886', '688', '668', '866', '818', '100',
  '200', '400', '500', '950', '029', '023', '027', '910', '091',
  '901', '927', '555', '008', '004', '002', '213', '321', '123',
  '943', '539', '813', '879', '978', '758', '857', '785', '559'
];

const TABLE_2_NUMBERS = [
  '562', '862', '962', '062', '982', '892', '289', '299', '929',
  '582', '926', '269', '296', '222', '999', '399', '599', '959',
  '960', '160', '050', '590', '509', '905', '409', '490', '094',
  '904', '061', '610', '083', '308', '830', '803', '444', '555',
  '666', '777', '888', '111', '333', '806', '807', '808', '809',
  '056', '560', '650', '065', '994', '944', '449', '377', '277',
  '177', '077', '335', '533', '353', '233', '323', '334', '433',
  '543', '625', '526', '265', '256', '723', '273', '732', '372',
  '327', '337', '339', '331', '133', '113', '311', '363', '655',
  '755', '955', '055', '405', '574', '578', '572', '465', '546',
  '456', '472', '000', '553', '559', '557', '768', '876', '678',
  '498', '084', '368', '324', '423', '203', '302', '230', '004'
];

const MASTER_NUMBERS = [...TABLE_1_NUMBERS, ...TABLE_2_NUMBERS];

interface UserRecord {
  fecha: string;
  resultado: string;
  loteria: string;
}

interface MasterStats {
  filtered: UserRecord[];
  freq: Record<string, number>;
  top3: string[];
  vecinos: Set<string>;
  uniqueLoterias: string[];
  lastResult: string | null;
}

export default function MasterAnalyzer() {
  const [historyData, setHistoryData] = useState<UserRecord[]>([]);
  const [selectedLoteria, setSelectedLoteria] = useState<string>('TODAS');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);

    // @ts-ignore
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results: any) => {
        const data = results.data;
        if (!data || data.length === 0) {
          setError("El archivo está vacío o no tiene el formato correcto.");
          setUploading(false);
          return;
        }

        const processed: UserRecord[] = data.map((row: any) => {
          const keys = Object.keys(row);
          const fKey = keys.find(k => k.toLowerCase().includes('fecha')) || keys[0];
          const rKey = keys.find(k => k.toLowerCase().includes('resultado')) || keys[1];
          const lKey = keys.find(k => k.toLowerCase().includes('loteria')) || keys[2];

          const resStr = String(row[rKey] || '').replace(/[^\d]/g, '').trim();
          
          return {
            fecha: String(row[fKey] || ''),
            resultado: resStr.padStart(3, '0').slice(-3),
            loteria: String(row[lKey] || 'SIN NOMBRE').trim().toUpperCase()
          };
        }).filter((r: UserRecord) => r.resultado.length === 3 && !isNaN(parseInt(r.resultado)));

        if (processed.length === 0) {
          setError("No se encontraron resultados válidos de 3 cifras en el archivo.");
        } else {
          setHistoryData(processed);
          setSelectedLoteria('TODAS');
        }
        setUploading(false);
      },
      error: () => {
        setError("Error crítico al procesar el archivo CSV.");
        setUploading(false);
      }
    });
  };

  const stats: MasterStats = useMemo(() => {
    const uniqueLoterias = Array.from(new Set(historyData.map(d => d.loteria))).sort();
    
    const filtered = selectedLoteria === 'TODAS' 
      ? historyData 
      : historyData.filter(d => d.loteria === selectedLoteria);

    const freq: Record<string, number> = {};
    filtered.forEach(d => {
      freq[d.resultado] = (freq[d.resultado] || 0) + 1;
    });

    const lastResult = filtered.length > 0 ? filtered[0].resultado : null;

    // Top 3 basado en frecuencia
    const sorted = Object.entries(freq).sort((a, b) => b[1] - a[1]);
    const top3 = sorted.slice(0, 3).map(s => s[0]);

    // Vecinos según la premisa (izquierda o derecha en la matriz)
    const vecinos = new Set<string>();
    
    // Si tenemos un último resultado, sus vecinos son candidatos fuertes
    if (lastResult) {
      const idx1 = TABLE_1_NUMBERS.indexOf(lastResult);
      const idx2 = TABLE_2_NUMBERS.indexOf(lastResult);
      
      if (idx1 !== -1) {
        if (idx1 % 9 !== 0) vecinos.add(TABLE_1_NUMBERS[idx1 - 1]);
        if ((idx1 + 1) % 9 !== 0) vecinos.add(TABLE_1_NUMBERS[idx1 + 1]);
      } else if (idx2 !== -1) {
        if (idx2 % 9 !== 0) vecinos.add(TABLE_2_NUMBERS[idx2 - 1]);
        if ((idx2 + 1) % 9 !== 0) vecinos.add(TABLE_2_NUMBERS[idx2 + 1]);
      }
    }

    // También agregar vecinos del Top 3
    top3.forEach(n => {
      const idx1 = TABLE_1_NUMBERS.indexOf(n);
      const idx2 = TABLE_2_NUMBERS.indexOf(n);
      if (idx1 !== -1) {
        if (idx1 % 9 !== 0) vecinos.add(TABLE_1_NUMBERS[idx1 - 1]);
        if ((idx1 + 1) % 9 !== 0) vecinos.add(TABLE_1_NUMBERS[idx1 + 1]);
      } else if (idx2 !== -1) {
        if (idx2 % 9 !== 0) vecinos.add(TABLE_2_NUMBERS[idx2 - 1]);
        if ((idx2 + 1) % 9 !== 0) vecinos.add(TABLE_2_NUMBERS[idx2 + 1]);
      }
    });

    return { filtered, freq, top3, vecinos, uniqueLoterias, lastResult };
  }, [historyData, selectedLoteria]);

  const getCellStyles = (num: string) => {
    const count = stats.freq[num] || 0;
    const isLast = num === stats.lastResult;
    
    if (stats.top3.includes(num)) {
      return "bg-cyan-400 text-slate-900 border-2 border-white shadow-[0_0_15px_rgba(34,211,238,0.7)] font-black z-10 animate-pulse scale-105";
    }
    
    if (stats.vecinos.has(num)) {
      return "bg-emerald-500 text-white border border-emerald-300/50 font-bold shadow-[0_0_10px_rgba(16,185,129,0.4)]";
    }

    if (count > 0 || isLast) {
      return "bg-red-600 text-white border border-red-400/30 font-bold";
    }

    return "bg-[#fcd34d] text-slate-900 border border-slate-800/20";
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Panel Superior */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[100px] -mr-32 -mt-32"></div>
        
        <div className="relative z-10">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <h2 className="text-3xl font-black text-white flex items-center gap-3">
                <TableIcon className="text-blue-500" size={32} />
                Analizador Maestro <span className="text-blue-500">216</span>
              </h2>
              <p className="text-slate-400 mt-2 max-w-xl font-medium">
                Auditoría estratégica basada en la Matriz de los 216 números más frecuentes de Colombia.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <label className="group relative flex items-center gap-3 bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-2xl font-black cursor-pointer transition-all shadow-xl shadow-blue-900/30 active:scale-95">
                <Upload size={24} />
                <span>{uploading ? 'PROCESANDO...' : 'SUBIR HISTORIAL CSV'}</span>
                <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>

          {error && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 bg-red-500/10 border border-red-500/50 p-4 rounded-2xl flex items-center gap-3 text-red-400">
              <AlertCircle size={20} />
              <p className="text-sm font-bold">{error}</p>
            </motion.div>
          )}

          {historyData.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <div className="bg-slate-800/50 border border-slate-700/50 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Registros</p>
                <p className="text-2xl font-black text-white">{historyData.length}</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700/50 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Filtro Loteria</p>
                <div className="flex items-center gap-2 mt-1">
                  <Filter size={14} className="text-blue-400" />
                  <select 
                    value={selectedLoteria}
                    onChange={(e) => setSelectedLoteria(e.target.value)}
                    className="bg-transparent text-white font-bold text-sm focus:outline-none cursor-pointer w-full"
                  >
                    <option value="TODAS">TODAS</option>
                    {stats.uniqueLoterias.map(l => <option key={l} value={l} className="bg-slate-900">{l}</option>)}
                  </select>
                </div>
              </div>
              <div className="bg-blue-600/10 border border-blue-500/20 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Último Salido</p>
                <p className="text-2xl font-black text-blue-400">{stats.lastResult || '---'}</p>
              </div>
              <div className="bg-emerald-600/10 border border-emerald-500/20 p-4 rounded-2xl">
                <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Hits en Matriz</p>
                <p className="text-2xl font-black text-emerald-400">
                  {Object.keys(stats.freq).filter(n => MASTER_NUMBERS.includes(n)).length}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Grid de Tablas Maestras */}
      <div className="space-y-8">
        {/* Tabla 1 */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-white uppercase flex items-center gap-3">
              <div className="w-2 h-8 bg-blue-500 rounded-full"></div>
              Matriz Maestra Superior (108)
            </h3>
            <div className="hidden sm:flex gap-4 text-[10px] font-black uppercase">
               <div className="flex items-center gap-2 text-cyan-400"><div className="w-3 h-3 bg-cyan-400 rounded-sm"></div> Top Optional</div>
               <div className="flex items-center gap-2 text-emerald-400"><div className="w-3 h-3 bg-emerald-500 rounded-sm"></div> Vecinos</div>
               <div className="flex items-center gap-2 text-red-500"><div className="w-3 h-3 bg-red-600 rounded-sm"></div> Salidos</div>
            </div>
          </div>
          
          <div className="grid grid-cols-9 gap-1 max-w-4xl mx-auto border-2 border-slate-800 p-1 bg-slate-950 rounded-lg shadow-inner">
            {TABLE_1_NUMBERS.map((num, i) => (
              <div
                key={`t1-${i}`}
                className={`
                  aspect-[1.5/1] sm:h-12 flex items-center justify-center text-xs sm:text-sm font-black transition-all duration-300
                  ${getCellStyles(num)}
                  hover:scale-110 z-0 hover:z-20 cursor-default
                `}
              >
                {num}
                {stats.freq[num] > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-slate-900 rounded-full flex items-center justify-center text-[9px] font-black border border-slate-900 shadow-sm">
                    {stats.freq[num]}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Tabla 2 */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-white uppercase flex items-center gap-3">
              <div className="w-2 h-8 bg-purple-500 rounded-full"></div>
              Matriz Maestra Inferior (108)
            </h3>
          </div>
          
          <div className="grid grid-cols-9 gap-1 max-w-4xl mx-auto border-2 border-slate-800 p-1 bg-slate-950 rounded-lg shadow-inner">
            {TABLE_2_NUMBERS.map((num, i) => (
              <div
                key={`t2-${i}`}
                className={`
                  aspect-[1.5/1] sm:h-12 flex items-center justify-center text-xs sm:text-sm font-black transition-all duration-300
                  ${getCellStyles(num)}
                  hover:scale-110 z-0 hover:z-20 cursor-default
                `}
              >
                {num}
                {stats.freq[num] > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-slate-900 rounded-full flex items-center justify-center text-[9px] font-black border border-slate-900 shadow-sm">
                    {stats.freq[num]}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recomendaciones */}
      {historyData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-gradient-to-br from-blue-900/20 to-slate-900 border border-blue-500/30 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-4 bg-blue-600 rounded-2xl shadow-lg shadow-blue-600/20">
                <TrendingUp className="text-white" size={28} />
              </div>
              <div>
                <h4 className="text-2xl font-black text-white tracking-tight">Sugerencias Estratégicas</h4>
                <p className="text-blue-400/70 font-bold uppercase text-xs tracking-widest mt-1">Análisis de Madurez y Vecindad</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {stats.top3.length > 0 ? stats.top3.map((num, idx) => (
                <div key={num} className="bg-slate-950/60 p-6 rounded-2xl border border-slate-800 group hover:border-cyan-500/50 transition-all shadow-xl">
                  <div className="text-[10px] font-black text-slate-500 uppercase mb-3 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                    Prioridad #{idx + 1}
                  </div>
                  <div className="text-4xl font-black text-cyan-400 tracking-tighter group-hover:scale-110 transition-transform duration-500">{num}</div>
                  <div className="mt-4 pt-4 border-t border-slate-800 flex flex-wrap gap-2">
                    {(() => {
                      const neighborsArr: string[] = [];
                      const idx1 = TABLE_1_NUMBERS.indexOf(num);
                      const idx2 = TABLE_2_NUMBERS.indexOf(num);
                      if (idx1 !== -1) {
                        if (idx1 % 9 !== 0) neighborsArr.push(TABLE_1_NUMBERS[idx1 - 1]);
                        if ((idx1 + 1) % 9 !== 0) neighborsArr.push(TABLE_1_NUMBERS[idx1 + 1]);
                      } else if (idx2 !== -1) {
                        if (idx2 % 9 !== 0) neighborsArr.push(TABLE_2_NUMBERS[idx2 - 1]);
                        if ((idx2 + 1) % 9 !== 0) neighborsArr.push(TABLE_2_NUMBERS[idx2 + 1]);
                      }
                      return neighborsArr.map(v => (
                        <span key={v} className="text-[10px] px-2 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-md font-black">
                          {v} (V)
                        </span>
                      ));
                    })()}
                  </div>
                </div>
              )) : (
                <div className="col-span-3 py-12 text-center text-slate-600 font-bold italic">
                  Sube tu historial para generar sugerencias...
                </div>
              )}
            </div>
            
            <div className="mt-10 p-5 bg-slate-950/60 rounded-2xl border border-slate-800 flex items-start gap-4 shadow-inner">
              <Info className="text-blue-500 shrink-0 mt-1" size={20} />
              <div className="text-sm text-slate-400 leading-relaxed">
                <p className="font-bold text-white mb-1">Premisa de Salto Lateral:</p>
                Históricamente, los resultados de la Tabla Maestra tienden a "saltar" a sus casillas contiguas (izquierda o derecha). 
                Los números en <span className="text-emerald-400 font-black">VERDE</span> en la matriz son los candidatos inmediatos basados en los últimos sorteos de {selectedLoteria}.
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl flex flex-col">
            <div className="flex items-center gap-3 mb-8">
              <History className="text-blue-500" size={24} />
              <h4 className="text-lg font-black text-white uppercase tracking-widest">Actividad Reciente</h4>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto pr-2 custom-scrollbar max-h-[500px]">
              {historyData.slice(0, 50).map((record, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-800/40 rounded-xl border border-slate-700/30 hover:bg-slate-800/60 transition-colors">
                  <div className="flex items-center gap-4">
                    <span className={`w-2 h-2 rounded-full ${MASTER_NUMBERS.includes(record.resultado) ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-slate-600'}`}></span>
                    <div>
                      <p className="text-white font-black tracking-widest">{record.resultado}</p>
                      <p className="text-[10px] text-slate-500 font-bold">{record.fecha}</p>
                    </div>
                  </div>
                  <span className="text-[9px] font-black text-blue-400 bg-blue-500/10 px-2 py-1 rounded-md border border-blue-500/20">{record.loteria}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
